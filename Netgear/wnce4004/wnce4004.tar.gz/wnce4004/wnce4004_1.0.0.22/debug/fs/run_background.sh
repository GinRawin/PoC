#!/bin/sh


/bin/datalib &
/bin/config set dns_hijack=0
/bin/sleep 2
