#!/bin/sh

/greenhouse/busybox sh /setup_dev.sh /greenhouse/busybox /ghdev


