function clickUpgrade(form)
{
	if(form.mtenFWUpload.value=="")
	{
		alert("$in_upgrade");
		return false;
	}
	var filestr=form.mtenFWUpload.value;
	var file_format=filestr.substr(filestr.lastIndexOf(".")+1); 
	if(file_format.toUpperCase()!="IMG")
	{
		alert("$not_img");
		return false;
	}
	return true;
}

function check_if_show()
{
	var cf = document.forms[0];
	if (cf.enable.checked == true)
		cf.auto_check_for_upgrade.value=1;
	else
	{
		if(confirm("$upgrade_turnoff_auto"))
			cf.auto_check_for_upgrade.value=0;
		else
		{
			location.href="UPG_upgrade.htm";
			return false;
		}
	}
	cf.submit_flag.value="auto_upgrade_check";
	cf.action="/apply.cgi?/UPG_upgrade.htm timestamp="+ts;
	
	cf.submit();
}

function check_if_show_auto()
{
	var cf = document.forms[0];
	if (cf.enable.checked == true)
		cf.auto_check_for_upgrade.value=1;
	else
	{
		if(confirm("$upgrade_turnoff_auto"))
			cf.auto_check_for_upgrade.value=0;
		else
		{
			cf.enable.checked = true;
			return false;
		}
	}
	cf.submit();
}

function click_check()
{
	var cf=document.forms[0];
	cf.submit_flag.value="ping";
	cf.action="/apply.cgi?/Detecting_upgrade.htm timestamp="+ts;
	cf.submit();	
}

function clickUpgradeLanguage(form)
{
        if(form.filename.value=="")
        {
                alert("$in_upgrade");
                return false;
        }
    var filestr=form.filename.value;
    var file_format=filestr.substr(filestr.lastIndexOf("-")+1);
        if(file_format.toUpperCase()!="TABLE")
        {
                alert("$not_correct_file"+netgear_module+"-*-Language-table");
        	return false;
        }
        var win_file_name=filestr.substr(filestr.lastIndexOf("\\")+1);
        var unix_file_name=filestr.substr(filestr.lastIndexOf("/")+1);
        if(win_file_name == filestr && unix_file_name != filestr)
                file_name=unix_file_name;
        else if( win_file_name != filestr && unix_file_name == filestr)
                file_name=win_file_name;
        else if (win_file_name == filestr && unix_file_name == filestr)
                file_name=unix_file_name;
        else
        {
		alert("$not_correct_file"+netgear_module+"-*-Language-table");
                return false;
        }
        var file_array=file_name.split('-');
        if(file_array.length!=4)
        {
		alert("$not_correct_file"+netgear_module+"-*-Language-table");
                return false;
        }
        var file_module=file_array[0];
        if(file_module.toUpperCase()!=netgear_module.toUpperCase())
        {
		alert("$not_correct_file"+netgear_module+"-*-Language-table");
                return false;
        }
        var file_end=file_array[2];
        if(file_end.toUpperCase()!="LANGUAGE")
        {
		alert("$not_correct_file"+netgear_module+"-*-Language-table");
                return false;
        }
        return true;
}


