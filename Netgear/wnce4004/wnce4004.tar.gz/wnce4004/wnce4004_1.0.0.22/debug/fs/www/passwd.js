function checkpasswd(cf)
{
	for(i=0;i<cf.sysNewPasswd.value.length;i++)
	{       
		if(isValidChar_space(cf.sysNewPasswd.value.charCodeAt(i))==false)
		{
			alert("$password_error");
			return false;
		}
	}
	if (cf.sysNewPasswd.value.length == 33 || cf.sysConfirmPasswd.value.length == 33)
	{
		alert("$max_password_length");
		return false;
	}
	if(cf.sysNewPasswd.value != cf.sysConfirmPasswd.value)
	{ 
		alert("$newpas_notmatch");
		return false;	
	}
	if(cf.sysOldPasswd.value != "" && cf.sysNewPasswd.value == "")
	{
		alert("$password_null");
		return false;
	}
	return true;
}
