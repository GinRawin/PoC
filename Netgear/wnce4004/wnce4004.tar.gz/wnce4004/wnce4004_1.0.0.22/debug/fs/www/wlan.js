function key_value(cf)
{
	cf.passphraseStr.value=document.getElementsByName("passphraseStr")[0].value;
	cf.KEY1.value=document.getElementsByName("KEY1")[0].value;
	cf.KEY2.value=document.getElementsByName("KEY2")[0].value;
	cf.KEY3.value=document.getElementsByName("KEY3")[0].value;
	cf.KEY4.value=document.getElementsByName("KEY4")[0].value;
	getObj("textWpaPwdPhrase1").value=document.getElementsByName("sec_wpaphrase1")[0].value;
	getObj("textWpaPwdPhrase2").value=document.getElementsByName("sec_wpaphrase2")[0].value;
	getObj("textWpaPwdPhrase3").value=document.getElementsByName("sec_wpaphrase3")[0].value;
}
function sectype(wl_sectype)
{
    if(wl_sectype==2)
	wl_sectype="WEP";
	else if(wl_sectype==3)
	wl_sectype="WPA-PSK";
	else if(wl_sectype==4)
	wl_sectype="WPA2-PSK";
	//else if(wl_sectype==5)
	//wl_sectype="WPA/WPA2-PSK";
	else
	wl_sectype="NONE";
		
}

function match_security_mode(cf)
{    
    if(parent.ap_list_reset=="manual")
		location.href="ca_apclient_manual.htm";
	else
	{
		var each_info= parent.ap_list_reset;
		get_before=each_info[4].split('|');
	    each_info[4]=get_before[0];
		each_info[1]=xss_replace(each_info[1])
	    if(each_info[4]=="WPA/WPA2-PSK" || each_info[4]=="WPA-PSK" || each_info[4]=="WPA2-PSK")
			location.href="ca_apclient_wl_wpa.htm";
		else if(each_info[4]=="WEP")
			location.href="ca_apclient_wl_wep.htm";
		else
		{
            if(each_info[1] == "&nbsp;&nbsp;")
				location.href="ca_hidden_ssid.htm";
			else
			{
				cf.hidden_sec_ap_type.value=1;
				cf.wlan_ca_ap_wifi.value=each_info[1];
				cf.action="/apply.cgi?/wait_for_ca_connect.htm timestamp="+ts;
				cf.submit();  
			}
        }
   }
}

function retry_set_passphrase(cf)
{
	cf.submit_flag.value="retry_set_passph";
	cf.action="/apply.cgi?/ca_connect_rightpage.htm timestamp="+ts;
	var browser=eval ( '"' + top.location + '"' );
	
	if  ( lan_dhcp == 1 && dns_hijack != 1)
	{
		judge_browser_nochange(cf,browser);
	}
		if(cf.hidden_sec_ap_type.value==2)
	    {
			if(checkwep(cf)==false)
				return false;
	        cf.hidden_sec_ap_type.value=2;
			cf.ap_sec_wpaphrase_len.value=cf.ap_sec_phrase.length;
			cf.ap_sec_keylen.value=getObj("keylen_id").value;
			cf.ap_wepkey1.value=getObj("key1_id").value;
			cf.ap_wepkey2.value=getObj("key2_id").value;
			cf.ap_wepkey3.value=getObj("key3_id").value;
			cf.ap_wepkey4.value=getObj("key4_id").value;
			cf.ap_sec_phrase.value=getObj("weppassphrase_id").value;
	        cf.submit();
	    }
		else if (cf.hidden_sec_ap_type.value!=1)
		{        
	        if( checkpsk_ca_fixed(cf)== false)
	            return false;
			cf.hidden_wpa_ap_psk.value = cf.ap_sec_phrase.value;
	        cf.submit();
		}
}
//fix bug 34390:"continue" button doesn't work in IE9,so add a tag to instead of "parent.ap_list_reset"
function set_ap_security(cf,tag)
{  
	//var browser=eval ( '"' + top.location + '"' );
	//if  ( lan_dhcp == 1 && dns_hijack != 1)
	//{
	//	judge_browser(cf,browser);
	//}	
		if(tag == 1)
			cf.wlan_ca_ap_wifi.value=getObj('wifi').value;
		var ssid = document.forms[0].wlan_ca_ap_wifi.value.replace(/\\/g,"\\\\\\\\").replace(/`/g,"\\\\\\`").replace(/"/g,"\\\"");;    
		var space_flag=0;
		/*if (dns_hijack==1)
		{
			var len=ssid.length;
			if(len>28)
					ssid=ssid.substring(0,28);
			document.forms[0].wlan_ca_ap_wifi.value= ssid +"_EXT";
		}*/
		if(ssid == "")
	        {
	                alert("$ssid_null");
	                return false;
	        }
			for(i=0;i<ssid.length;i++)
	        {
	                if(isValidChar_space(ssid.charCodeAt(i))==false)
	                {
	                        alert(ssid + "$ssid_not_allowed");
	                        return false;
	                }
	        }
		    for(i=0;i<ssid.length;i++)
	        {
	            	if(ssid.charCodeAt(i)!=32)
	                	space_flag++;
	        }
			if(space_flag==0)
			{
				alert("$ssid_null");
	        	return false;
			}
		cf.wlan_ca_ap_wifi.value=ssid;
	document.forms[0].wlan_ap_wifi.value=document.forms[0].wlan_ap_wifi.value.replace(/&lt;/g,'<');
	document.forms[0].wlan_ap_wifi.value=document.forms[0].wlan_ap_wifi.value.replace(/&gt;/g,'>');
	document.forms[0].wlan_ca_ap_wifi.value=document.forms[0].wlan_ca_ap_wifi.value.replace(/&lt;/g,'<');
	document.forms[0].wlan_ca_ap_wifi.value=document.forms[0].wlan_ca_ap_wifi.value.replace(/&gt;/g,'>');
	cf.action="/apply.cgi?/wait_for_ca_connect.htm timestamp="+ts;
	if(tag == 1)
	{
		if(cf.hidden_sec_ap_type.value==2)
	    {
			if( checkwep(cf)== false)
				return false;
	        cf.hidden_sec_ap_type.value=2;
			cf.sec_auth.value=2;
			for(i=0;i<cf.passphraseStr.value.length;i++)
			{
				if(isValidChar_space(cf.passphraseStr.value.charCodeAt(i))==false)
				{
					alert("$notallowpassp");
					return false;
				}
			}
			//if(old_sectype==2 && dns_hijack==0)
				//alert(wep_same_security)
	        cf.submit();
	    }
		else if(cf.hidden_sec_ap_type.value!=1)
		{        
			if(cf.hidden_sec_ap_type.value==3)
				cf.ap_sec_wpaphrase.value=getObj("textWpaPwdPhrase1").value;
			else if(cf.hidden_sec_ap_type.value==4)
				cf.ap_sec_wpaphrase.value=getObj("textWpaPwdPhrase2").value;
			else if(cf.hidden_sec_ap_type.value==5)
				cf.ap_sec_wpaphrase.value=getObj("textWpaPwdPhrase3").value;
	        if( checkpsk_ca_manual(cf)== false)
	            return false;
			cf.hidden_wpa_ap_psk.value = cf.ap_sec_wpaphrase.value;
			
	        cf.submit();
		}
		else
			cf.submit();
    }
	else
	{
		cf.wlan_channel.value=parent.scan_channel;
		if(cf.hidden_sec_ap_type.value==2)
	    {			
			if( checkwep(cf)== false)
				return false;
	        cf.hidden_sec_ap_type.value=2;
			
			for(i=0;i<cf.passphraseStr.value.length;i++)
			{
				if(isValidChar_space(cf.passphraseStr.value.charCodeAt(i))==false)
				{
					alert("$notallowpassp");
					return false;
				}
			}
			//if(old_sectype==2 && dns_hijack==0)
				//alert(wep_same_security)
	        cf.submit();
	    }
		else if (cf.hidden_sec_ap_type.value!=1)
		{        
	        if( checkpsk_ca_fixed(cf)== false)
	            return false;
			cf.hidden_wpa_ap_psk.value = cf.ap_sec_phrase.value;			
	        cf.submit();
		}
		else
			cf.submit();
	}
}

function chgCh(from)
{  
    var cf = document.forms[0]; 
    if ( from == 2 )
    {
		if(cf.enable_ap_client.checked==true)
		setChannel(3,1);
		else
        setChannel(1,0);
    }
    else
    {
        setwlan_mode();
		if(cf.enable_ap_client.checked==true)
		{
		    if(cf.wlan_chan.selectedIndex==0)
			setChannel(3,0);
			else
			setChannel(3,1);
		}
		else
        setChannel(1,0);
    }
}
function chgChA(from)
{   
	var cf = document.forms[0];
	if (from == 2)
	{
		setAChannel(cf.w_channel_an);
	}
	else
	{
		setAwlan_mode();
		setAChannel(cf.w_channel_an);
	}
}
function setwlan_mode()
{
	var cf = document.forms[0];
	var index = getObj("coun_id").selectedIndex;
	var currentMode = getObj("mode_id").selectedIndex;

	if (index == 7 || index == 8) {
		getObj("mode_id").options.length = 2;
		getObj("mode_id").options[0].text = "Up to 54Mbps";
		getObj("mode_id").options[1].text = "Up to 145Mbps";
		getObj("mode_id").options[0].value = "1";
		getObj("mode_id").options[1].value = "2";
		if (currentMode <= 1)
			getObj("mode_id").selectedIndex = currentMode;
		else
			getObj("mode_id").selectedIndex = 1;
	} else {
		getObj("mode_id").options.length = 3;
		getObj("mode_id").options[0].text = "Up to 54Mbps";
		getObj("mode_id").options[1].text = "Up to 145Mbps";
		getObj("mode_id").options[2].text = "Up to 300Mbps";
		getObj("mode_id").options[0].value = "1";
		getObj("mode_id").options[1].value = "2";
		getObj("mode_id").options[2].value = "3";
		getObj("mode_id").selectedIndex = currentMode;
	}
	return;
}

function setChannel()
{
	var cf = document.forms[0];
	var index = cf.WRegion.selectedIndex;
	index=parseInt(index)+1;
	var chIndex = cf.w_channel.selectedIndex;
	var currentMode = cf.opmode.selectedIndex;
	var endChannel;

/* change it like before produce 20000, just 11 and 13
 *
	if ( currentMode == 2 && (index == 4 || index == 9 || index == 11 ))
		endChannel = 7;	
	else if ( currentMode == 2 )
		endChannel = 9;
	else
*/	
  
		endChannel = FinishChannel[index];
	if (FinishChannel[index]==14 && cf.opmode.selectedIndex!=0)
		cf.w_channel.options.length = endChannel - StartChannel[index];
	else
		cf.w_channel.options.length = endChannel - StartChannel[index] + 2;

	cf.w_channel.options[0].text = "$auto_mark";
	cf.w_channel.options[0].value = 0;

	for (var i = StartChannel[index]; i <= endChannel; i++) {
		if (i==14 && cf.opmode.selectedIndex!=0)
			continue;
		cf.w_channel.options[i - StartChannel[index] + 1].value = i;
		cf.w_channel.options[i - StartChannel[index] + 1].text = (i < 10)? "0" + i : i;
	}
	cf.w_channel.selectedIndex = ((chIndex > -1) && (chIndex < cf.w_channel.options.length)) ? chIndex : 0 
} 

function setAwlan_mode()
{
	var cf = document.forms[0];
	var index = cf.WRegion_an.selectedIndex;
	index=parseInt(index)+1;
	var currentMode = cf.opmode_an.selectedIndex;

	if (index == 8 || index == 15 || index == 16 || index == 1 || index == 18) {     //Israel,Middle East(Turkey/Egypt/Tunisia/Kuwait) Middle East(Saudi Arabia) Russia Africa
		cf.opmode_an.options.length = 2;
		cf.opmode_an.options[0].text = wlan_mode_54;
		cf.opmode_an.options[1].text = wlan_mode_130;
		cf.opmode_an.options[0].value = "1";
		cf.opmode_an.options[1].value = "2";
		if (currentMode <= 1)
			cf.opmode_an.selectedIndex = currentMode;
		else
			cf.opmode_an.selectedIndex = 1;
		cf.w_channel_an.disabled=false;
		cf.opmode_an.disabled=false;			
	}
	else if ( index == 13 ){		// Middle East(Algeria/Syria/Yemen), this country do not support HT20 HT40,grayout channel
		cf.opmode_an.options.length = 1;
		cf.opmode_an.options[0].text = wlan_mode_54;
		cf.opmode_an.options[0].value = "1";
		cf.w_channel_an.selectedIndex=0;
		cf.opmode_an.selectedIndex=0;
		cf.w_channel_an.disabled=true;
		//cf.opmode_an.disabled=true;
	}
	else{
		cf.opmode_an.options.length = 3;
		cf.opmode_an.options[0].text = wlan_mode_54;
		cf.opmode_an.options[1].text = wlan_mode_130;
		cf.opmode_an.options[2].text = wlan_mode_300;
		cf.opmode_an.options[0].value = "1";
		cf.opmode_an.options[1].value = "2";
		cf.opmode_an.options[2].value = "3";
		cf.opmode_an.selectedIndex = currentMode;
		cf.w_channel_an.disabled=false;
		cf.opmode_an.disabled=false;		
	}
	if(cf.security_type[1].checked == true)
	{
		var sel_opmode_an=document.getElementsByName("opmode_an");
		sel_opmode_an[0].remove(2);
		sel_opmode_an[0].remove(1);
		cf.opmode_an.options[0].selected=true;
	}
	return;
}
function setAChannel(channel)
{
	var cf = document.forms[0];
	var index = cf.WRegion_an.selectedIndex;
	/* to fix bug 27403 */
	var option_array=document.getElementById("select_channel_an").options;
	var select_region=parseInt(index,10);
	var old_region=parseInt(wl_get_countryA,10);
	index=parseInt(index)+1;
	var chIndex = channel.selectedIndex;
	var chValue = channel.options[chIndex].value;
	var currentMode = cf.opmode_an.selectedIndex;	
	var endChannel;
   	
	var AChannel = new Array(36, 40, 44, 48, 149, 153, 157, 161, 165);
	
	var BChannel = new Array(36, 40, 44, 48, 52, 56, 60, 64, 100, 104, 108, 112, 116, 120, 124, 128, 132, 136, 140, 149, 153, 157, 161, 165);
	if(index == 18)//Russia
	{									
		endChannel = 9;
		channel.options.length = 9;
		for( i = 0; i< endChannel; i++ )
		{
			channel.options[i].value = AChannel[i];
			channel.options[i].text = AChannel[i];
		}
	}
	else if(index == 2 || index == 3 || index == 4 || index == 7 || index == 11 || index == 12 || index == 19 || index == 20 || index == 22 )
	{//Asia,Australia,Canada,India,Malaysia,Mexico,Singapore,South America,United States
		if( currentMode != 2 )
		{
			endChannel = 9;
			channel.options.length = 9;
		}
		else
		{
			endChannel = 8;
			channel.options.length = 8;
		}
		for( i = 0; i< endChannel; i++ )
		{
			channel.options[i].value = AChannel[i];
			channel.options[i].text = AChannel[i];
		}
	}
	else if( index == 10 ) //Korea
	{
		endChannel = 8;
		channel.options.length = 8;
			
		for( i = 0; i< endChannel; i++ )
		{
			channel.options[i].value = AChannel[i];
			channel.options[i].text = AChannel[i];
		}
	}
/* this can be used when region is China*/
        else if( index == 5 )
        {//China
			channel.options.length = 4;
			channel.options[0].value = channel.options[0].text = 149;
            channel.options[1].value = channel.options[1].text = 153;
            channel.options[2].value = channel.options[2].text = 157;
            channel.options[3].value = channel.options[3].text = 161;
			if( currentMode != 2 )
			{
				channel.options.length = 5;
				channel.options[4].value = channel.options[4].text = 165;
			}
        }
		else if( index == 14)   //Middle East(Iran/Lebanon/Qatar)
		{
			channel.options.length = 5;
            channel.options[0].value = channel.options[0].text = 149;
            channel.options[1].value = channel.options[1].text = 153;
            channel.options[2].value = channel.options[2].text = 157;
            channel.options[3].value = channel.options[3].text = 161;
			channel.options[4].value = channel.options[4].text = 165;
		}
		else if( index == 16)   //Middle Eeast(Saudi Arabia)
		{
			endChannel = 9;
			channel.options.length = 9;
			for( i = 0; i< endChannel; i++ )
			{
				channel.options[i].value = AChannel[i];
				channel.options[i].text = AChannel[i];
			}
		}
		else if( index == 21)   //Taiwan
		{
			channel.options.length = 6;
			channel.options[0].value = channel.options[0].text = 60;
			channel.options[1].value = channel.options[1].text = 64;
			channel.options[2].value = channel.options[2].text = 149;
			channel.options[3].value = channel.options[3].text = 153;
			channel.options[4].value = channel.options[4].text = 157;
			channel.options[5].value = channel.options[5].text = 161;
			if( currentMode == 0 || currentMode == 1 )              //not 300Mbps
			{
				channel.options.length = 8;
				channel.options[0].value = channel.options[0].text = 56;
				channel.options[1].value = channel.options[1].text = 60;
				channel.options[2].value = channel.options[2].text = 64;
				channel.options[3].value = channel.options[3].text = 149;
				channel.options[4].value = channel.options[4].text = 153;
				channel.options[5].value = channel.options[5].text = 157;
				channel.options[6].value = channel.options[6].text = 161;
				channel.options[7].value = channel.options[7].text = 165;
			}
		}
	else
	{
		endChannel = 4;
		channel.options.length = 4;
		for( i = 0; i< endChannel; i++ )
		{
			channel.options[i].value = AChannel[i];
			channel.options[i].text = AChannel[i];
		}
	
	}
	
	/* to fix bug 27403 */
	if(select_region == old_region)
	{
		for(i=0;i<option_array.length;i++)
		{
			if(option_array[i].value == wla_get_channel)
			{
				channel.selectedIndex = i;
				break;
			}
		}
	}
	else
		channel.selectedIndex = ((chIndex > -1) && (chIndex < channel.options.length)) && ( chValue == channel.value )? chIndex : 0 ;	
}

function wladv_apply()
{
	var cf=document.forms[0];
	cf.time_stamp_dni.value=parent.index_ts;
/*
	if(getObj("enable_ap").checked == true)
		cf.hidden_ap_mode.value=1;
	else
		cf.hidden_ap_mode.value=0;
	if(getObj("ssid_broad").checked == true)
		cf.hidden_endis_ssid_broadcast.value=1;
	else
		cf.hidden_endis_ssid_broadcast.value=0;
	if(getObj('endis_id').checked==true)
		cf.hidden_endis_wps.value = 1;
	else
		cf.hidden_endis_wps.value = 0;
	if(getObj('keep_id').checked==true)
		cf.hidden_keep_exist.value=5;
	else
		cf.hidden_keep_exist.value=1;
*/
        if(cf.enable_ap.checked == true)
                cf.hidden_ap_mode.value=1;
        else
                cf.hidden_ap_mode.value=0;
        if(cf.endis_ssid_broadcast.checked == true)
                cf.hidden_endis_ssid_broadcast.value=1;
        else
                cf.hidden_endis_ssid_broadcast.value=0;
        if(cf.endis_wps.checked==true)
                cf.hidden_endis_wps.value = 1;
        else
                cf.hidden_endis_wps.value = 0;
        if(cf.keep_exist.checked==true)
                cf.hidden_keep_exist.value=5;
        else
                cf.hidden_keep_exist.value=1;

}

function check_wlan()
{
	var cf=document.forms[0];

	if( wps_progress_status == "2" || wps_progress_status == "3" || wps_progress_status == "start" )
	{
		alert("$wps_in_progress");
		return false;
	}

	if(cf.dut_type[1].checked == true)
		cf.hid_dut_type.value = 1;
	else
	{
		cf.hid_dut_type.value = 0;
		var ssid_bgn = document.forms[0].ssid.value.replace(/\\/g,"\\\\\\\\").replace(/`/g,"\\\\\\`").replace(/"/g,"\\\"");
		var space_flag=0;
		var haven_wpe=0;

		if(ssid_bgn == "")
		{
			alert("$ssid_null");
			return false;
		}
		for(i=0;i<ssid_bgn.length;i++)
		{
			if(isValidChar_space(ssid_bgn.charCodeAt(i))==false)
			{
				alert("$ssid_not_allowed");
				return false;
			}
		}
		for(i=0;i<ssid_bgn.length;i++)
		{
			if(ssid_bgn.charCodeAt(i)!=32)
				space_flag++;
		}
		if(space_flag==0)
		{
			alert("$ssid_null");
			return false;
		}	
		cf.hidden_wl_ssid.value = ssid_bgn;
		
		if(cf.ssid_bc.checked == true)
			cf.wl_enable_ssid_broadcast.value="1";
		else
		{
			if(confirm("$disable_ssid_broad") == false)
				return false;
			cf.wl_enable_ssid_broadcast.value="0";
		}
		
		cf.hid_dut_freq.value = cf.w_freq.value;
		if(cf.w_freq.value == 0)//2.4GHz b/g/n
		{
			cf.wl_WRegion.value = cf.WRegion.value;
			cf.wl_hidden_wlan_channel.value = cf.w_channel.value;
			cf.wl_hidden_wlan_mode.value = cf.opmode.value;	
			//if(getObj("keylen_id").value == "")
				//cf.hidden_sec_keylen.value = 5;
			//else
				//cf.hidden_sec_keylen.value = getObj("keylen_id").value;
		}
		else
		{
			cf.wl_WRegion.value = cf.WRegion_an.value;
			cf.wl_hidden_wlan_channel.value = cf.w_channel_an.value;
			cf.wl_hidden_wlan_mode.value = cf.opmode_an.value;		
		}

			if(cf.security_type[1].checked == true)
			{
				if( checkwep(cf)== false)
					return false;
				cf.wl_hidden_sec_type.value=2;
					for(i=0;i<cf.passphraseStr.value.length;i++)
					{
							if(isValidChar_space(cf.passphraseStr.value.charCodeAt(i))==false)
							{
									alert("$notallowpassp");
									return false;
							}
					}
				if(confirm("$wep_wpa_disable_wps") == false)
					return false;
			}
			else if(cf.security_type[2].checked == true)
			{
				if( checkpsk(cf.passphrase, cf.wl_sec_wpaphrase_len)== false)
					return false;
				if( cf.wl_hidden_wlan_mode.value != "1" )
					if(confirm("$wpa_tkip_pop_message") == false)
						return false;
				cf.wl_hidden_sec_type.value=3;
				cf.wl_hidden_wpa_psk.value = cf.passphrase.value.replace(/\\/g,"\\\\").replace(/`/g,"\\`").replace(/"/g,"\\\"");
				if(confirm("$wep_wpa_disable_wps") == false)
					return false;
				cf.wl_hidden_wlan_mode.value = "1";
			}
			else if(cf.security_type[3].checked == true)
			{
				if( checkpsk(cf.passphrase, cf.wl_sec_wpaphrase_len)== false)
					return false;
				cf.wl_hidden_sec_type.value=4;
				cf.wl_hidden_wpa_psk.value = cf.passphrase.value.replace(/\\/g,"\\\\").replace(/`/g,"\\`").replace(/"/g,"\\\"");
			}
			else if(cf.security_type[4].checked == true)
			{
				if( checkpsk(cf.passphrase, cf.wl_sec_wpaphrase_len)== false)
					return false;

				if( cf.wl_hidden_wlan_mode.value != "1" )
				{
					if(confirm("$wpa_mixed_pop_message") == false)
						return false;
				}
				cf.wl_hidden_sec_type.value=5;
				cf.wl_hidden_wpa_psk.value = cf.passphrase.value.replace(/\\/g,"\\\\").replace(/`/g,"\\`").replace(/"/g,"\\\"");
			}		
			else
			{
				if(confirm("$no_security") == false)
					return false;
				cf.wl_hidden_sec_type.value=1;
			}
		}	
	//top.enable_action=1;
	return true;	
}

function check_ca_wlan()
{
	var cf=document.forms[0];
	cf.time_stamp_dni.value=parent.index_ts;
	var ssid;
	if(cf.use_same_sec.checked == false)
	{
		    ssid = getObj("ESSID").value;
		    cf.hidden_enable_ap_transmit.value=0;
			if(ssid == "")
	        {
	                alert(ssid_null);
	                return false;
	        }
			for(i=0;i<ssid.length;i++)
	        {
	                if(isValidChar_space(ssid.charCodeAt(i))==false)
	                {
	                        alert(ssid + ssid_not_allowed);
	                        return false;
	                }
	        }
		    for(i=0;i<ssid.length;i++)
	        {
	            	if(ssid.charCodeAt(i)!=32)
	                	space_flag++;
	        }
			if(space_flag==0)
			{
				alert(ssid_null);
	        	return false;
			}		
			document.forms[0].hidden_wlan_ssid.value=getObj("ESSID").value;

			if(cf.use_same_sec.checked == true)
				cf.hidden_same_sec.value=1;
			else
				cf.hidden_same_sec.value=0;
			var space_flag=0
					
			if(getObj("type_id2").checked== true)
			{
				if( checkwep(cf)== false)
					return false;
				cf.hidden_sec_type.value=2;
			}
			else if(getObj("type_id3").checked == true)
			{
				if( checkpsk(cf)== false)
					return false;
				if(confirm(wpa_tkip_pop_message) == false)
					return false;
				cf.hidden_sec_type.value=3;
				cf.hidden_wpa_psk.value = getObj("textWpaPwdPhrase1").value;
			}
			else if(getObj("type_id4").checked == true)
			{
				if( checkpsk(cf)== false)
					return false;
				cf.hidden_sec_type.value=4;
				cf.hidden_wpa_psk.value = getObj("textWpaPwdPhrase2").value;
			}	
			else if(getObj("type_id5").checked == true)
			{
				if( checkpsk(cf)== false)
					return false;
				if(confirm(wpa_mixed_pop_message) == false)
					return false;
				cf.hidden_sec_type.value=5;
				cf.hidden_wpa_psk.value = getObj("textWpaPwdPhrase3").value;
			}	
			else
				cf.hidden_sec_type.value=1;


		
			cf.hidden_sec_auth.value = 2;
			if(getObj("wepenc").value == "")
				cf.hidden_sec_keylen.value = 5;
			else
				cf.hidden_sec_keylen.value = getObj("wepenc").value;
			    if(getObj("wepkeyno_id1").checked == true)
			        keyno_wep=1;
				else if(getObj("wepkeyno_id2").checked == true)
			        keyno_wep=2;
				else if(getObj("wepkeyno_id3").checked == true)
			        keyno_wep=3;
				else
					keyno_wep=4;
			cf.hidden_wepkeyno.value = keyno_wep;
			cf.hidden_wepkey1.value = getObj("key1_id").value;
			cf.hidden_wepkey2.value = getObj("key2_id").value;
			cf.hidden_wepkey3.value = getObj("key3_id").value;
			cf.hidden_wepkey4.value = getObj("key4_id").value;
			cf.hidden_wepkey1.value=document.getElementsByName("wepkey1")[0].value;
			cf.hidden_wepkey2.value=document.getElementsByName("wepkey2")[0].value;
			cf.hidden_wepkey3.value=document.getElementsByName("wepkey3")[0].value;
			cf.hidden_wepkey4.value=document.getElementsByName("wepkey4")[0].value;
			if(getObj("weppassphrase_id").value!="")
				cf.hidden_weppassphrase.value = getObj("weppassphrase_id").value;
	}
	else
	{
		if(old_sectype == 2)
		{
			cf.hidden_sec_type.value=2;	
			cf.hidden_wepkeyno.value = wl_temp_keyno;
		}
		else if(old_sectype == 3)
		{
			if(confirm(wpa_tkip_pop_message) == false)
                return false;
			cf.hidden_sec_type.value=3;
			cf.hidden_wpa_psk.value = get_wpa1;
		}
		else if(old_sectype == 4)
		{
			cf.hidden_sec_type.value=4;
			cf.hidden_wpa_psk.value = get_wpa2;
		}
		else if(old_sectype == 5)
		{
			if(confirm(wpa_mixed_pop_message) == false)
                return false;
			cf.hidden_sec_type.value=5;
			cf.hidden_wpa_psk.value = get_wpas;
		}
		else
			cf.hidden_sec_type.value=1;

		cf.hidden_sec_auth.value = 2;
		cf.hidden_sec_keylen.value = key_length;
		//cf.hidden_wepkeyno.value = 1;
		if(key_length == 5)
		{
			cf.hidden_wepkey1.value = wep_64_key1;
			cf.hidden_wepkey2.value = wep_64_key2;
			cf.hidden_wepkey3.value = wep_64_key3;
			cf.hidden_wepkey4.value = wep_64_key4;
		}
		else if(key_length == 13)
		{
                        cf.hidden_wepkey1.value = wep_128_key1;
                        cf.hidden_wepkey2.value = wep_128_key2;
                        cf.hidden_wepkey3.value = wep_128_key3;
                        cf.hidden_wepkey4.value = wep_128_key4;
		}
		document.forms[0].hidden_wlan_ssid.value=getObj("ESSID").value;
	}
	return true;	
}

function check_wlan_guest()
{
	var cf=document.forms[0];
	var ssid = document.forms[0].gssid.value.replace(/\\/g,"\\\\\\\\").replace(/`/g,"\\\\\\`").replace(/"/g,"\\\"");
	cf.s_gssid.value=ssid;
	var wl_ssid=document.forms[0].wlssid.value.replace(/\\/g,"\\\\\\\\").replace(/`/g,"\\\\\\`").replace(/"/g,"\\\"");
	var tag1 = 0;
	if(ssid == "")
	{
		alert("$ssid_null");
		return false;
	}
    if(ssid == wl_ssid)
    {
        alert("$ssid_not_allowed_same");
        return false;
    }
	for(i=0;i<ssid.length;i++)
	{
		if(isValidChar_space(ssid.charCodeAt(i))==false)
		{
			alert(ssid + "$ssid_not_allowed");
			return false;
		}
	}

	if(cf.enable_bssid.checked == true)
		cf.hidden_enable_guestNet.value=1;
	else
		cf.hidden_enable_guestNet.value=0;
	if(cf.enable_ssid_bc.checked == true)
		cf.hidden_enable_ssidbro.value=1;
	else
		cf.hidden_enable_ssidbro.value=0;
	
	if(cf.allow_access.checked == true)
		cf.hidden_allow_guest.value=1;
	else
		cf.hidden_allow_guest.value=0;

	cf.wl_hidden_wlan_mode.value = wl_simple_mode;
	
	if(wireless_sectype=="2" && cf.enable_bssid.checked == true && cf.security_type[1].checked == true)// to fix bug 30740
	{
		alert("$wep_just_one_ssid");
		return false;
	}

	if(cf.security_type[1].checked == true)
	{
		cf.hidden_guest_network_mode_flag.value=0;
		cf.wl_hidden_wlan_mode.value = "1";
		if( checkwep(cf)== false)
			return false;
		cf.hidden_sec_type.value=2;
		for(i=0;i<cf.passphraseStr.value.length;i++)
		{
			if(isValidChar_space(cf.passphraseStr.value.charCodeAt(i))==false)
			{
				alert("$notallowpassp");
				return false;
			}
		}
			alert("$wep_just_one_ssid");
	}
	else if(cf.security_type[2].checked == true)
	{
		if( checkpsk(cf.passphrase, cf.sec_wpaphrase_len)== false)
			return false;

		cf.hidden_guest_network_mode_flag.value=1;
		cf.wl_hidden_wlan_mode.value = "1";

		cf.hidden_sec_type.value=3;
		cf.hidden_wpa_psk.value = cf.passphrase.value.replace(/\\/g,"\\\\").replace(/`/g,"\\`").replace(/"/g,"\\\"");
	}
	else if(cf.security_type[3].checked == true)
	{
		cf.hidden_guest_network_mode_flag.value=0;
		if( checkpsk(cf.passphrase, cf.sec_wpaphrase_len)== false)
			return false;
		cf.hidden_sec_type.value=4;
		cf.hidden_wpa_psk.value = cf.passphrase.value.replace(/\\/g,"\\\\").replace(/`/g,"\\`").replace(/"/g,"\\\"");
	}	
	else if(cf.security_type[4].checked == true)
	{
		if( checkpsk(cf.passphrase, cf.sec_wpaphrase_len)== false)
			return false;
		
		if(wl_simple_mode != "1")
        {
			tag1 = 1;
			if(confirm("$wpa_mixed_pop_message") == false)
			{
				cf.hidden_guest_network_mode_flag.value=0;
				return false;
			}
		}
		cf.hidden_guest_network_mode_flag.value=2;
		cf.wl_hidden_wlan_mode.value = wl_simple_mode;

		cf.hidden_sec_type.value=5;
		cf.hidden_wpa_psk.value = cf.passphrase.value.replace(/\\/g,"\\\\").replace(/`/g,"\\`").replace(/"/g,"\\\"");
	}		
	else
		cf.hidden_sec_type.value=1;
		
	return true;
}
