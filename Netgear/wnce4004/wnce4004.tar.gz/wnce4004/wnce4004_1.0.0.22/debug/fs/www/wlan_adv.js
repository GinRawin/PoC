function checkadv(form)
{
        if( wps_progress_status == "2" || wps_progress_status == "3" || wps_progress_status == "start" )
        {
                alert("$wps_in_progress");
                return false;
        }

	if(form.rts.value == "")
	{	
		alert("$rts_range");
		return false;
	}
        if(!(form.rts.value > 0 && form.rts.value <= 2347))
        {
                alert("$rts_range");
                return false;
        }
	form.wl_rts.value = form.rts.value;

	if(form.frag.value == "")
	{
		alert("$fragmentation_range");
		return false;
	}
	if(!(form.frag.value > 255 && form.frag.value < 2347))
	{
		alert("$fragmentation_range");
		return false;
	}
	form.wl_frag.value = form.frag.value;

	if(form.enable_shortpreamble.selectedIndex == "2")
		form.wl_enable_shortpreamble.value = "2";
	else if(form.enable_shortpreamble.selectedIndex == "1")
                form.wl_enable_shortpreamble.value = "1";
	else if(form.enable_shortpreamble.selectedIndex == "0")
		form.wl_enable_shortpreamble.value = "0";

	//transmit power control
/*
	wlan_txctrl(form, form.tx_power_ctrl.value, country);

	if( form.enable_coexist.checked == true)
		form.hid_enable_coexist.value="0";
	else
		form.hid_enable_coexist.value="1";


	if(wps_protect_pin_flag == 1)
	{
		if(form.pin_enable.checked == true )
			form.endis_pin.value="0";
		else
			form.endis_pin.value="1";
		if(form.protect_enable.checked == true)
			form.hid_protect_enable.value="1";
		else
			form.hid_protect_enable.value="0";
			
		if( form.wps_fail_count.value.checkNum())
		{
			alert("$invalid_pin_connections_num");
			form.wps_fail_count.value.focus();
			return false;
		}
		form.wps_fail_count.value = parseInt(form.wps_fail_count.value, 10);
	}
	else
	{
		if(form.pin_disable.checked == true )
			form.endis_pin.value="1";
		else
			form.endis_pin.value="0";
	}

	if(form.wsc_config.checked == true)
		form.endis_wsc_config.value="5";
	else
		form.endis_wsc_config.value="1";
*/	
	form.submit();
	//return true;
}
