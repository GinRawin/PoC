cd /

/usr/sbin/httpd  -S -E /usr/sbin/ca.pem /usr/sbin/httpsd.pem

