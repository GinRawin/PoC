import time

# 设置文件路径
file_path = "/mnt/sdb/hjr/ac1450/81a99ea20515e1cd30f879a775440771910860a14305555f68a7d7700d5316a3/AC1450_V1.0.0.36_10.0.17/debug/fs/gh_nvram/ipv6_lan_length"

# 记录上次读取的文件内容
last_value = None

while True:
    try:
        # 读取文件内容
        with open(file_path, 'r') as file:
            current_value = file.read().strip()
        print(current_value)
        # 检查文件内容是否发生变化
        if current_value != last_value:
            print(f"File content changed: {current_value}")
            last_value = current_value

    except Exception as e:
        print(f"Error reading file: {e}")

    # 设置读取间隔时间 (可以根据需要调整)
    time.sleep(0.5)  # 每隔0.5秒读取一次
