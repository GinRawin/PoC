#!/bin/sh

# Usage: del_conntrack.sh service_type entry_num
# Format: "Service_Type Src_IP Min_Port Max_Port"

sType=$1
sItem=$2
sArg_old=$3
sArg_new=$4
proc_fs_name=conntrack_killer

# Port Forwarding function
port_forwarding_func()
{
	entry=`nvram get "$sType""$sItem"`

	to_dest=`echo $entry | awk -F, '{print $2}'`
	dport=`echo $entry | awk -F, '{print $1}'`

	Src_IP=`echo $to_dest | awk -F: '{print $1}'`
	Min_Port=`echo $dport | awk -F: '{print $1}'`
	Max_Port=`echo $dport | awk -F: '{print $2}'`

	echo $sType $Src_IP $Min_Port $Max_Port > /proc/$proc_fs_name
}

# Port Forwarding function
port_forwarding_all_func()
{
	num=1
	entry=`nvram get "$sType""$num"`
	while [ "$entry" != "" ]; do
   		to_dest=`echo $entry | awk -F, '{print $2}'`
   		dport=`echo $entry | awk -F, '{print $1}'`

		Src_IP=`echo $to_dest | awk -F: '{print $1}'`
		Min_Port=`echo $dport | awk -F: '{print $1}'`
		Max_Port=`echo $dport | awk -F: '{print $2}'`

		echo $sType $Src_IP $Min_Port $Max_Port > /proc/$proc_fs_name
		num=$((num+1))
		entry=`nvram get "$sType""$num"`
	done;
}
	
# Port Triggering function
port_triggering_func()
{
	entry=`nvram get "$sType""$sItem"`
	pTrigger_idv_en=`echo $entry | awk '{print $9}'`
	if [ "$pTrigger_idv_en" = "1" ]; then
		Src_IP=`echo $entry | awk '{print $3}'`
		Min_Port=`echo $entry | awk '{print $7}'`
		Max_Port=`echo $entry | awk '{print $8}'`
		if [ "$Src_IP" = "any" ]; then
			# if src_ip = any, then we set Src_IP=255.255.255.255. 
			# delete_conntrack kernel module will handle it.
			Src_IP=255.255.255.255
		fi

		echo $sType $Src_IP $Min_Port $Max_Port > /proc/$proc_fs_name
	fi
}

# pTrigger_en=`nvram get disable_port_trigger` # 0-> enable, 1-> disable
port_triggering_all_func()
{
	rule_num=`nvram show | grep ^triggering | wc -l`
	if [ "$rule_num" != "0" ]; then
		for item in `nvram show | grep ^triggering | awk -F"=" '{print $1}'`
		do
			entry=`nvram get $item`
			pTrigger_en=`echo $entry | awk '{print $9}'`
			if [ "$pTrigger_en" = "1" ]; then
				Src_IP=`echo $entry | awk '{print $3}'`
				Min_Port=`echo $entry | awk '{print $7}'`
				Max_Port=`echo $entry | awk '{print $8}'`
				if [ "$Src_IP" = "any" ]; then
					# if src_ip = any, then we set Src_IP=255.255.255.255. 
					# delete_conntrack kernel module will handle it.
					Src_IP=255.255.255.255
				fi
				echo $sType $Src_IP $Min_Port $Max_Port > /proc/$proc_fs_name
			fi
		done
	fi
	# disable trigger function, need flush lan port reservation table manually
	#echo "CLEAN" > /proc/lan_port_reserved_table
}

port_triggering_apply_func()
{
	num=1
	total_num=`nvram get port_trigger_num`
	while [ "$num" -le "$total_num" ];
	do
		x=`echo "$sArg_old" | cut -d ',' -f $num`
		y=`echo "$sArg_new" | cut -d ',' -f $num`

#		[ "$x" -eq 0 -a "$y" -eq 1 ] && lpr_for_enable_trigger $sType $num
		[ "$x" -eq 1 -a "$y" -eq 0 ] && sItem=$num && port_triggering_func $sType $sItem
		
                num=$(($num+1))
	done
}

dmz_func()
{
	dmz_ip=`nvram get dmz_ipaddr`
	echo $sType $dmz_ip 0 65535 > /proc/$proc_fs_name
}

upnp_func()
{
        iptables -F nat_upnp -t nat
        iptables -F fwd_upnp

	for entry in `cat /tmp/upnp_portmap`
	do
		Min_Port=`echo $entry | awk -F";" '{print $3}'`
		Max_Port=`echo $entry | awk -F";" '{print $4}'`
		Proto=`echo $entry | awk -F";" '{print $2}'`
		sIP=`echo $entry | awk -F";" '{print $5}'`
		
		echo $sType $sIP $Min_Port $Max_Port $Proto > /tmp/test_upnp.txt
		echo $sType $sIP $Min_Port $Max_Port $Proto > /proc/$proc_fs_name
		
	done

	rm -f /tmp/upnp_portmap
}


# Block Services function
block_services_func()
{
	if [ "$sItem" = "all" ]; then	# Disable -> Enable, handle all rules
		num=1;
		entry="$(nvram get block_services${num})"
		while [ "$entry" != "" ]; do		
			Min_Port=`echo $entry | awk -F" " '{print $3}'`
			Max_Port=`echo $entry | awk -F" " '{print $4}'`
			Proto=`echo $entry | awk -F" " '{print $2}'`
   
			getIP=`echo $entry | awk -F" " '{print $7}'`
			if [ "$getIP" = "all" ]; then
				LAN_IP=`nvram get lan_ipaddr`
				sIP=`echo $LAN_IP | cut -d"." -f"1-3" | awk '{print $0 ".1"}'`
				eIP=`echo $LAN_IP | cut -d"." -f"1-3" | awk '{print $0 ".254"}'`
			else	
				eIP=`echo $getIP | awk -F"-" '{print $2}'`
				if [ "$eIP" != "" ]; then
					sIP=`echo $getIP | awk -F"-" '{print $1}'`
				else
					sIP=`echo $getIP`
					eIP=""
				fi
			fi
			
			#echo $sType $sIP $Min_Port $Max_Port $Proto $eIP >> /tmp/test_block_svc.txt
			echo $sType $sIP $Min_Port $Max_Port $Proto $eIP > /proc/$proc_fs_name

			num=$(($num+1))
			entry="`nvram get block_services${num}`"
		done
	else	# Add, Edit 
		entry=`nvram get "$sType""$sItem"`
		Min_Port=`echo $entry | awk -F" " '{print $3}'`
		Max_Port=`echo $entry | awk -F" " '{print $4}'`
		Proto=`echo $entry | awk -F" " '{print $2}'`

		getIP=`echo $entry | awk -F" " '{print $7}'`
		if [ "$getIP" = "all" ]; then
			LAN_IP=`nvram get lan_ipaddr`
			sIP=`echo $LAN_IP | cut -d"." -f"1-3" | awk '{print $0 ".1"}'`
			eIP=`echo $LAN_IP | cut -d"." -f"1-3" | awk '{print $0 ".254"}'`
		else	
			eIP=`echo $getIP | awk -F"-" '{print $2}'`
			if [ "$eIP" != "" ]; then
				sIP=`echo $getIP | awk -F"-" '{print $1}'`
			else
				sIP=`echo $getIP`
				eIP=""
			fi
		fi
		
		#echo $sType $sIP $Min_Port $Max_Port $Proto $eIP >> /tmp/test_block_svc.txt
		echo $sType $sIP $Min_Port $Max_Port $Proto $eIP > /proc/$proc_fs_name

	fi
}


# Main function define here
if [ "$sType" = "forwarding" ]; then
	port_forwarding_func
fi

if [ "$sType" = "forwarding" ] && [ "$sItem" = "all" ]; then
	port_forwarding_all_func
fi

if [ "$sType" = "triggering" ] && [ "$sItem" != "all" ]; then
	port_triggering_func
fi

if [ "$sType" = "triggering" ] && [ "$sItem" = "all" ]; then
	port_triggering_all_func
fi

if [ "$sType" = "triggering" ] && [ "$sItem" = "apply" ]; then
	port_triggering_apply_func
fi

if [ "$sType" = "dmz" ]; then
	dmz_func	
fi

if [ "$sType" = "upnp" ]; then
	upnp_func	
fi

if [ "$sType" = "block_services" ]; then
	block_services_func
fi



