#!/bin/sh

RETVAL=0
WEB_INIT_PROG="/etc/rc.d/uhttpd.sh"
UDHCPD_INIT_PROG="/etc/rc.d/udhcpd.sh"
UDHCPC_INIT_PROG="/etc/rc.d/udhcpc.sh"
DNSMASQ_INIT_PROG="/etc/rc.d/dnsmasq.sh"
NTPCLIENT_INIT_PROG="/etc/rc.d/ntpclient.sh"
UPNP_INIT_PROG="/etc/rc.d/upnp.sh"
SYSLOGD_INIT_PROG="/etc/rc.d/syslogd.sh"
DROPBEAR_INIT_PROG="/etc/rc.d/dropbear.sh"
TELNETD_INIT_PROG="/etc/rc.d/telnetd.sh"
SNMPD_INIT_PROG="/etc/rc.d/snmpd.sh"
RIPD_INIT_PROG="/etc/rc.d/ripd.sh"
QOS_INIT_PROG="/etc/rc.d/qos.sh"
ROUTING_PROG="/etc/rc.d/routing.sh"
LLTD_PROG="/etc/rc.d/lltd.sh"
SIP_ALG_PROG="/etc/rc.d/sip_alg.sh"
TC_PROG="/etc/rc.d/TC.sh"
NET_SCAN="/etc/rc.d/net_scan.sh"
SCHE_PROG="/etc/rc.d/cmdsched.sh"
DNS_HIJACK="/etc/rc.d/dns_hijack.sh"
LLTD_PROG="/etc/rc.d/lltd.sh"
WINS="/etc/rc.d/wins_start.sh"
MAC_FILTER="/etc/rc.d/mac_filter.sh"
NETSTAR_PROG="/etc/rc.d/netstar.sh"

start() {
	# Start daemons.
	echo $"Starting Service: "
	#${QOS_INIT_PROG} start
	${WEB_INIT_PROG} start
	${SYSLOGD_INIT_PROG} start
	if [ "`nvram get TimerSettingAuto`" != "1" ]; then
        	setstr=`nvram get TimerSetManualstr`
        	if [ -n $setstr ]; then
        		date -u $setstr
			#echo -n "connected" > /tmp/NTP_connect
			echo -n "manual_connected" > /tmp/NTP_connect
        	fi
        fi

	if [ "`nvram get router_disable`" = "0" ]; then # NOT APmode
		if [ "`nvram get nat_disable`" = "0" ]; then # NAT Enable
			#${UPNP_INIT_PROG} start
			${DNSMASQ_INIT_PROG} start
		fi
		#${UDHCPD_INIT_PROG} start
		${UDHCPC_INIT_PROG} start
		${ROUTING_PROG} start
		${RIPD_INIT_PROG} start
		${SCHE_PROG} start both		# site_svc/email/both  
#		/usr/sbin/telnetenable
#		/usr/sbin/getdeviceinfo&

		lan_ifname=`nvram get lan_ifname`
		lan_ipaddr=`nvram get lan_ipaddr`	
    #${WINS} start	
		#${DNS_HIJACK} start
		echo 0 > /proc/custom_Passthru
		if [ "`nvram get ipv6_pass`" = "1" ];then
			echo 1 > /proc/custom_Passthru
		fi
		if [ "`nvram get PPPoEPassThrough_enable`" = "1" ];then
			if [ "`nvram get ipv6_pass`" = "1" ];then
				echo 3 > /proc/custom_Passthru
			else
				echo 2 > /proc/custom_Passthru
			fi
		fi
	fi
	${NET_SCAN} start
	${LLTD_PROG} start
	#/etc/rc.d/lan_port_resv.sh
	/sbin/lan_port_resv&
	#${MAC_FILTER} prepare
	#${MAC_FILTER} restart
	${NETSTAR_PROG} start
	#${TC_PROG} stop
	#ap_serv -i br0
	RETVAL=$?
	echo
	return $RETVAL
}

stop() {
	# Stop daemons.
	echo $"Shutting Service: "
	${NETSTAR_PROG} stop
	${WEB_INIT_PROG} stop
	#${UDHCPD_INIT_PROG} stop
	${UDHCPC_INIT_PROG} stop
	${DNSMASQ_INIT_PROG} stop
	#${UPNP_INIT_PROG} stop
	${RIPD_INIT_PROG} stop
	${SYSLOGD_INIT_PROG} stop
	${SCHE_PROG} stop		# site_svc/email/both  
	${NET_SCAN} stop
	#${LLTD_PROG} stop
  #${WINS} stop	
	#killall telnetenable
	#killall utelnetd
	#killall ap_serv
	if [ "`nvram get ipv6_pass`" = "1" ];then
		echo 0 > /proc/custom_Passthru
	fi
	if [ "`nvram get PPPoEPassThrough_enable`" = "1" ];then
		echo 0 > /proc/custom_Passthru
	fi
	RETVAL=$?
	echo
	return $RETVAL
}

ui_start() {
	# Start daemons.
	echo $"Starting Service: "
	#${QOS_INIT_PROG} start
	if [ "`nvram get router_disable`" = "0" ]; then # NOT APmode
		if [ "`nvram get nat_disable`" = "0" ]; then # NAT Enable
			#${UPNP_INIT_PROG} start
			${DNSMASQ_INIT_PROG} start
		fi
		#${UDHCPD_INIT_PROG} start
		${UDHCPC_INIT_PROG} start
		${ROUTING_PROG} start
		${RIPD_INIT_PROG} start
		#/usr/sbin/telnetenable
		echo 0 > /proc/custom_Passthru
		if [ "`nvram get ipv6_pass`" = "1" ];then
			echo 1 > /proc/custom_Passthru
		fi
		if [ "`nvram get PPPoEPassThrough_enable`" = "1" ];then
			if [ "`nvram get ipv6_pass`" = "1" ];then
				echo 3 > /proc/custom_Passthru
			else
				echo 2 > /proc/custom_Passthru
			fi
		fi
	fi
	${NET_SCAN} start
	#${LLTD_PROG} start
  #${WINS} start
	#ap_serv -i br0
	RETVAL=$?
	echo
	return $RETVAL
}

ui_stop() {
	# Stop daemons.
	echo $"Shutting Service: "
	#${UDHCPD_INIT_PROG} stop
	${UDHCPC_INIT_PROG} stop
	${DNSMASQ_INIT_PROG} stop
	#${UPNP_INIT_PROG} stop
	${RIPD_INIT_PROG} stop
	${ROUTING_PROG} stop
	${NET_SCAN} stop
	#${LLTD_PROG} stop
  #${WINS} stop	
	#killall telnetenable
	#killall utelnetd
	#killall ap_serv
	if [ "`nvram get ipv6_pass`" = "1" ];then
		echo 0 > /proc/custom_Passthru
	fi
	if [ "`nvram get PPPoEPassThrough_enable`" = "1" ];then
		echo 0 > /proc/custom_Passthru
	fi
	RETVAL=$?
	echo
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  start_ui)
	ui_start
	;;
  stop_ui)
	ui_stop
	;;
  restart|reload)
	ui_stop
	ui_start
	RETVAL=$?
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

