#!/bin/sh

. /etc/rc.d/tools.sh

lan_ifname=`nvram get lan_ifname`
lan_hwifname=`nvram get lan_hwifname`
wan_hwifname=`nvram get wan_hwifname`
router_disable=`nvram get router_disable`

# Configurable LAN IP,  yuecheng 2008.04.11
lan1_enable=`nvram get lan1_enable`
lan2_enable=`nvram get lan2_enable`
lan3_enable=`nvram get lan3_enable`

lan_hwaddr=`nvram get lan_hwaddr`
#ifconfig eth0 up
ifconfig lo 127.0.0.1 netmask 255.0.0.0 up

ifconfig $lan_ifname down
brctl delbr $lan_ifname
brctl addbr $lan_ifname
brctl setfd $lan_ifname 0
brctl stp $lan_ifname 0

#Use as Access Point
# To avoid to change mac address on br0, there are 2 ways as the followings,
# 1. changed eth1 hwaddr equal to eth0 
# 2. brctl addif br0 eth1, brctl addif br0 eth0

LAN_IPADDR=`nvram get lan_ipaddr`
LAN_SUBNET=`nvram get lan_netmask`

if [ "$(nvram get wds_endis_fun)" != "1" -o "$router_disable" = "0" ];then
brctl addif $lan_ifname $lan_hwifname
ifconfig $lan_hwifname up
ifconfig $lan_ifname promisc

fi
echo "Configuring LAN , lan_ifname = $lan_ifname ........"
ifconfig $lan_ifname down
ifconfig $lan_ifname $LAN_IPADDR netmask $LAN_SUBNET up

masklen=`print_masklen $LAN_SUBNET`

#if [ "`nvram get lan_hwaddr`" = "" ]; then
#	set `ifconfig $lan_hwifname`
#	nvram set lan_hwaddr=$5
#	echo "nvram set lan_hwaddr=$5"
#	nvram commit
#fi
lan_hwaddr=`nvram get lan_hwaddr`
wan_mtu=`nvram get wan_dhcp_mtu`

if [ "$router_disable" = "1" ]; then
        #ifconfig $wan_hwifname down hw ether $lan_hwaddr
        #ifconfig $wan_hwifname up
	#/sbin/set_trailer 1
      #brctl addif $lan_ifname $wan_hwifname
      hw_ether="`nvram get true_lanif`"
      ifconfig $hw_ether up
      brctl addif $lan_ifname $hw_ether

      ifconfig $wan_hwifname down
      if [ "$wan_mtu" = "0" ]; then
         ifconfig $wan_hwifname mtu 1500
      else
         ifconfig $wan_hwifname mtu $wan_mtu
      fi
      ifconfig $wan_hwifname up      
      brctl addif $lan_ifname $wan_hwifname 	
fi
