#!/bin/sh

RETVAL=0

touch /tmp/static_conflict
/sbin/cmdlan.sh stop

/sbin/ip_conflict.sh stop
/sbin/conflict_wanlan.sh
/sbin/ip_conflict.sh start &

exit $RETVAL




