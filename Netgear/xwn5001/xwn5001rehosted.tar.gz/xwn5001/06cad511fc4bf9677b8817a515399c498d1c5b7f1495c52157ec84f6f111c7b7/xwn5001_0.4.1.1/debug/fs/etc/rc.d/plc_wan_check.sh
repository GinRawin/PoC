#!/bin/sh


IP=`ifconfig br0 | grep inet | cut -d  ":" -f2 | cut -d " " -f1`

if [ "$(nvram get wan_dhcp_ipaddr)" = "0.0.0.0" -o "$IP" != "$(nvram get wan_dhcp_ipaddr)" ]; then
	/etc/rc.d/udhcpc.sh restart
fi