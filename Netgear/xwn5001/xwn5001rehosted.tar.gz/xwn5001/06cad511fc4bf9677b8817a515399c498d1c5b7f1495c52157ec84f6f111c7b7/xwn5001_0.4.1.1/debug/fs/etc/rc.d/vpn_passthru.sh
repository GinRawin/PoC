#!/bin/sh

MODULE_PATH=/lib/modules/2.6.22

pptp_passthru=`nvram get endis_vpn_passthru`
ipsec_passthru=`nvram get endis_ipsec_passthru`
lan_ifname=`nvram get lan_ifname`

RETVAL=0

start() {
	if [ "$pptp_passthru" = "1" ]; then
		/usr/sbin/insmod ${MODULE_PATH}/nf_conntrack_proto_gre.ko
		/usr/sbin/insmod ${MODULE_PATH}/nf_conntrack_pptp.ko
		/usr/sbin/insmod ${MODULE_PATH}/nf_nat_proto_gre.ko
		/usr/sbin/insmod ${MODULE_PATH}/nf_nat_pptp.ko
		#/usr/sbin/insmod ${MODULE_PATH}/ip_conntrack_proto_esp.ko
		#/usr/sbin/insmod ${MODULE_PATH}/ip_nat_proto_esp.ko
		iptables -F fwd_vpn_passthru
		iptables -A fwd_vpn_passthru -p 0x2f -j ACCEPT 2> /dev/null
		#iptables -A fwd_vpn_passthru -p esp -j ACCEPT 2> /dev/null

	fi
	if [ "$ipsec_passthru" = "1" ]; then
		/usr/sbin/insmod ${MODULE_PATH}/ip_conntrack_proto_esp.ko
		/usr/sbin/insmod ${MODULE_PATH}/ip_nat_proto_esp.ko
		if [ "$pptp_passthru" != "1" ]; then
			iptables -F fwd_vpn_passthru
		fi
		iptables -A fwd_vpn_passthru -p esp -j ACCEPT 2> /dev/null
	fi	
}

stop() {
	rmmod nf_nat_pptp 2> /dev/null
	rmmod nf_nat_proto_gre 2> /dev/null
	rmmod nf_conntrack_pptp 2> /dev/null
	rmmod nf_conntrack_proto_gre 2> /dev/null
	rmmod ip_nat_proto_esp 2> /dev/null
	rmmod ip_conntrack_proto_esp 2> /dev/null
	iptables -F fwd_vpn_passthru
	iptables -A fwd_vpn_passthru -i $lan_ifname -p tcp --dport 1723 -j DROP 2> /dev/null
	iptables -A fwd_vpn_passthru -i $lan_ifname -p udp --dport 1701 -j DROP 2> /dev/null
	iptables -A fwd_vpn_passthru -i $lan_ifname -p esp -j DROP 2> /dev/null
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

