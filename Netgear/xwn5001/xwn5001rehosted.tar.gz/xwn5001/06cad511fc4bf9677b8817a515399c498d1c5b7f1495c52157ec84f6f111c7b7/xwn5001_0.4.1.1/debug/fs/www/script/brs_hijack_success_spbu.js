function initPage()
{
	var paragraph = document.getElementById("message_1");
	var paragraph_text;

	paragraph_text = document.createTextNode(SPBU_17);
	paragraph.appendChild(paragraph_text);
	
	var paragraph_2 = document.getElementById("message_2");
	var paragraph_text_2;

	paragraph_text_2 = document.createTextNode(SPBU_18);
	paragraph_2.appendChild(paragraph_text_2);
}

addLoadEvent(initPage);
