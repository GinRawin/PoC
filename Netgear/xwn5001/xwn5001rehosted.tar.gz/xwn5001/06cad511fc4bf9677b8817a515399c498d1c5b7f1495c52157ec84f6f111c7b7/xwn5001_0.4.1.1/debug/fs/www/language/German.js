//BRS_01_checkNet.html

var wiz_start_genie_re="Ja.";
var genie_wireless_set_info="NETGEAR Genie hat ein vorhandenes drahtloses Netzwerk erkannt.";
var select_choice="Wählen Sie eine Option für die Wireless-Einstellungen dieses Geräts:";
var use_router_setting="Dieselben Einstellungen wie das vorhandene drahtlose Netzwerk verwenden (empfohlen).";
var use_manual_setting="Ein neues drahtloses Netzwerk einrichten. Ich bin mir bewusst, dass das Wireless-Gerät manuell mit dem neuen Netzwerk verbunden werden muss.";
var SWP0011="Bestätigung:";
var SWP0012="Bestätigen Sie die Wireless-Einstellungen, und klicken Sie auf die Schaltfläche Weiter. Die drahtlose Verbindung wurde hergestellt. Wenn Sie auf Weiter klicken, wird die drahtlose Verbindung getrennt. Stellen Sie sie unter Verwendung der neuen Einstellungen wieder her, und fahren Sie mit der Einrichtung fort.";
var range_ext="Neue Geräteeinstellungen:";
var SWP005="Keine Internetverbindung erkannt.";
var network_checking="Netzwerkverbindung wird überprüft...";
var wireless_net_det="Vorhandenes drahtloses Netzwerk erkannt";
var quit="Beenden";
var bh_try_again="Wiederholen";
var no_device_det_1 ="NETGEAR Genie kann keine Informationen zu vorhandenen drahtlosen Netzwerken abrufen.";
var no_device_det_2 ="Möchten Sie, dass NETGEAR Genie es erneut versucht?";
var wiz_start_manual="Nein. Ich möchte die Wireless-Einstellungen selbst konfigurieren.";
var LPC028="Überprüfen Sie die Internetverbindung des Routers.";
var sec_phr_g="Wireless-Passwort";

















var h_wlan="<body bgColor=#0099cc><P><font size=\"4\"><B>Hilfe: WLAN</B></font></P><P><B>Hinweis:</B> Um einen den gesetzlichen Bestimmungen entsprechenden Betrieb des Gerats und die Kompatibilitat mit anderen Geraten sicherzustellen, mussen Sie die richtigen Einstellungen fur Kanal und Region wahlen. </P><P><B>Richtige Aufstellung des Gerats zum Optimieren der Wireless-Verbindung</B></P><P>Durch die richtige Aufstellung des WLAN-Gerats konnen Sie masgeblich dazu beitragen, die Reichweite Ihres WLAN zu erhohen. Berucksichtigen Sie bei der Wahl des Standorts fur Ihr WLAN-Gerat die folgenden Hinweise:<UL><LI>Das Gerat sollte sich moglichst zentral innerhalb des Bereichs befinden, in dem die ans WLAN angebundenen Computer genutzt werden.<LI>Wahlen Sie einen erhohten Aufstellungsort fur das Gerat, beispielsweise ganz oben auf einem Wandregal.<LI>Stellen Sie das Gerat nicht in der Nahe moglicher Storquellen (Computer, Mikrowellen, schnurlose Telefone usw.) auf,<LI>Nicht in der Nahe von grosen Metallflachen. </LI></UL></P><P><B>Hinweis:</B> Ein ordnungsgemaser und storungsfreier Betrieb des Gerats bei voller Leistung ist nur gewahrleistet, wenn die vorstehenden Hinweise beachtet werden.</P><HR><A name=network></A><P><B>WLAN</B></P><P>Netzwerkname (SSID)</P><P>Geben Sie einen Wert aus bis zu 32 alphanumerischen Zeichen fur den Netzwerknamen ein. Allen Geraten im WLAN muss derselbe Netzwerkname zugewiesen werden. Der Netzwerkname lautet standardmasig Netgear_EXT; aus Sicherheitsgrunden empfiehlt NETGEAR jedoch unbedingt, einen anderen Namen zu verwenden. Beim Netzwerknamen wird zwischen Gros- und Kleinschreibung unterschieden. So ist beispielsweise <I>NETGEAR</I> nicht gleichbedeutend mit <I>NETGEAr</I>.</P><P>Region</P><P>Wahlen Sie Ihre Region (Land) aus der Liste aus. Der hier gewahlte Wert bestimmt den Betriebsmodus des Gerats. Wenn Sie hier eine andere Region auswahlen als die, in der Sie das Gerat tatsachlich betreiben, verstosen Sie moglicherweise gegen gesetzliche Bestimmungen. Wenn Sie den Router in einem Land betreiben mochten, fur das die Liste keinen Eintrag enthalt, mussen Sie die entsprechenden Betriebsparameter selbst festlegen. Weitere Informationen erhalten Sie von den zustandigen Behorden in Ihrem Land oder auf unserer Website.</P><P>Kanal</P><P>In diesem Feld legen Sie die verwendete Betriebsfrequenz fest. Sofern keine Interferenzen durch andere Access Points in der Umgebung auftreten, brauchen Sie den hier angegebenen Wert nicht zu andern.</P><P>Modus</P>Hier konnen Sie den gewunschten WLAN-Ubertragungsmodus auswahlen. Sie konnen zwischen den folgenden Optionen wahlen:<UL><LI>Bis zu 54 Mbit/s: Legacy-Modus mit einer maximalen Geschwindigkeit von 54 Mbit/s fur b/g-Netzwerke.<LI>Bis zu 130 Mbit/s: Neighbor-Friendly-Modus – Standardgeschwindigkeit von bis zu 130 Mbit/s bei Vorhandensein von mehreren drahtlosen Netzwerken.<LI>Bis zu 300 Mbit/s: Performance-Modus – maximale Wireless-N-Geschwindigkeit von bis zu 300 Mbit/s.</LI></UL></P><P>Die Standardeinstellung ?Bis zu 145 Mbit/s“. Sie lasst alle 11b, 11g und 11n WLAN-Gerate zu. </P><HR><A name=security></A><p><b>Sicherheitsoptionen</b></p><UL><LI>Keine: Die ubertragenen Daten werden nicht verschlusselt.<LI>WEP: Wired Equivalent Privacy. Die ubertragenen Daten werden mit WEP (64 oder 128 Bit) verschlusselt.<br><b>Hinweis:</b> Bei der Sicherheitseinstellung <b>WEP</b> oder <b>WPA-PSK [TKIP]-Authentifizierung</b> ist die Funktion <b>Wi-Fi Protected Setup</b> deaktiviert.<LI>WPA-PSK [TKIP]: Wi-Fi Protected Access Pre-Shared Key. Die ubertragenen Daten werden entsprechend dem WPA-PSK-Standard mit TKIP verschlusselt.<LI>WPA2-PSK [AES]: Wi-Fi Protected Access Version 2 Pre-Shared Key. Die ubertragenen Daten werden entsprechend dem WPA2-PSK-Standard mit AES verschlusselt.<LI>WPA-PSK [TKIP] + WPA2-PSK [AES]: Clients konnen entweder WPA-PSK [TKIP] oder WPA2-PSK [AES] verwenden.</LI></UL><p>In einem Robust-Security-Netzwerk erzielen Sie die beste Leistung mit NETGEAR WN511B und anderen Wireless-Adaptern, indem Sie fur die Netzwerk-Sicherheit anstelle von XWN5001 die Option WPA2-PSK verwenden.</p><HR><A name=wep></A><p><b>Verschlusselung (WEP)  </b></p><P>Authentifizierungsverfahren <p>Fur das Authentifizierungsverfahren kann normalerweise die Einstellung <b>Automatisch</b> belassen werden. Mit dieser Einstellung kann die Authentifizierung von Adaptern uber <b>Open System</b> oder <b>Shared Key</b> erfolgen. In der Dokumentation zur Wireless Card finden Sie eine Erlauterung, welches Verfahren wann am besten geeignet ist. Wenn Sie eine sicherere Authentifizierungsmethode wunschen, konnen Sie die Option <b>Shared Key</b> auswahlen. In diesem Fall konnen Ihre Wireless-Adapter ausschlieslich uber <b>Shared Key</b> eine Verbindung zu diesem Netzwerk herstellen.<p>Verschlusselungstiefe <p>Wahlen Sie die gewunschte Schlusseltiefe fur die WEP-Verschlusselung: <UL><LI>Verschlusselung mit 64 Bit (auch als 40-Bit-Verschlusselung bezeichnet) <LI>Verschlusselung mit 128 Bit </LI></UL><HR><A name=wepkey></A><p><b>WEP-Schlussel</b></p><p>Wenn WEP aktiviert ist, konnen die vier Schlussel fur die Datenverschlusselung wahlweise automatisch generiert oder manuell eingegeben werden. Fur alle Computer und Access Points im WLAN mussen dieselben Werte verwendet werden. <p>Automatische Schlusselgenerierung (Passphrase) <p>Geben Sie im Feld <b>Passphrase</b> ein Wort oder eine Zeichenfolge ein und klicken Sie auf <b>Generieren</b>, um die WEP-Schlussel automatisch zu erzeugen. Wenn als Verschlusselungstiefe 64 Bit gewahlt wurde, werden allen vier Schlusselfeldern automatisch Werte zugewiesen. Wenn als Verschlusselungstiefe 128 Bit gewahlt wurde, wird nur der WEP-Schlussel generiert, und der Schlusselwert wird in alle vier Felder eingetragen. <p>Manuelle Schlusseleingabe <p>Wahlen Sie den gewunschten Schlussel aus den vier erzeugten aus und geben Sie den WEP-Schlussel fur Ihr WLAN in das entsprechende Feld ein. <p>Bei WEP-Verschlusselung mit 64 Bit Schlusseltiefe: Geben Sie zehn Hexadezimalzahlen ein (Zeichen 0 bis 9 und A bis F in beliebiger Kombination). <p>Bei WEP-Verschlusselung mit 128 Bit Schlusseltiefe: Geben Sie 26 Hexadezimalzahlen ein (Zeichen 0 bis 9 und A bis F in beliebiger Kombination). <p>Klicken Sie anschliesend auf <b>Ubernehmen</b>, um die Einstellungen zu speichern.</P><HR><A name=wpa-psk></A><p><b>Verschlusselung (WPA-PSK)</b></p><p>Fur diese Option mussen Sie die TKIP-Verschlusselung nutzen und die WPA-Passphrase (Netzwerkschlussel) eingeben. Geben Sie in das Feld Passphrase ein Wort oder eine Zeichenfolge ein. Der Schlussel muss aus 8 bis 63 ASCII-Zeichen oder einer Hexadezimalzahl mit 64 Stellen bestehen. Hexadezimalzahlen setzen sich aus den folgenden Zeichen zusammen: <br>0, 1, 2, …, 8, 9, A, B, C, D, E und F. <p>Klicken Sie anschliesend auf <b>Ubernehmen</b>, um die Einstellungen zu speichern. </p><HR><A name=wpa2-psk></A><p><b>Verschlusselung (WPA2-PSK)</b></p><p>WPA2 ist eine neuere Version von WPA. Wahlen Sie diese Option nur aus, wenn alle drahtlosen Clients im Netzwerk WPA2 unterstutzen. Fur diese Option mussen Sie die AES-Verschlusselung nutzen und die WPA-Passphrase (Netzwerkschlussel) eingeben. Geben Sie in das Feld Passphrase ein Wort oder eine Zeichenfolge ein. Der Schlussel muss aus 8 bis 63 ASCII-Zeichen oder einer Hexadezimalzahl mit 64 Stellen bestehen. Hexadezimalzahlen setzen sich aus den folgenden Zeichen zusammen: <br>0, 1, 2, …, 8, 9, A, B, C, D, E und F. </p><HR><A name=wpa-psk+wpa2-psk></A><p><b>Verschlusselung (WPA-PSK + WPA2-PSK)  </b></p><p>Mit dieser Option kann der Client zwischen WPA (mit TKIP; Broadcast-Datenpakete nutzen ebenfalls TKIP) oder WPA2 (mit AES) wahlen. Hierfur muss die Verschlusselung TKIP + AES lauten. Auserdem muss die WPA-Passphrase (Netzwerkschlussel) eingegeben werden. Zum Erzielen optimaler Leistung mussen sich Clients wie WN511B bei diesem Router per WPA2 (mit AES) anmelden. Fur Clients, die sich per WPA-PSK (mit TKIP) anmelden, betragt die maximale Wireless-Ubertragungsrate 54 MBit/s. Geben Sie in das Feld Passphrase ein Wort oder eine Zeichenfolge ein. Der Schlussel muss aus 8 bis 63 ASCII-Zeichen oder einer Hexadezimalzahl mit 64 Stellen bestehen. Hexadezimalzahlen setzen sich aus den folgenden Zeichen zusammen: <br>0, 1, 2, …, 8, 9, A, B, C, D, E und F. </p><HR><p><b>So speichern oder verwerfen Sie die Anderungen:</b></p><p>Klicken Sie auf <b>Ubernehmen</b>, um die Anderungen an den Router zu ubermitteln. <br>Klicken Sie auf <b>Abbrechen</b>, um zu den vorigen Einstellungen zuruckzukehren. </p></body>";

var help_center="Hilfe-Center";
var help_show_hide="Hilfe-Center ein-/ausblenden";
var sec_wpa_mode="WPA-Modus:";
var auto_mark="Auto";
var guest_wire_iso="Wireless Isolation aktivieren";
var adva_wlan_ssid_broadcast="SSID-Broadcast aktivieren";
var cancel_mark="Abbrechen";
var apply_mark="Übernehmen";

var bh_config_wireless_setting="Wireless-Einstellungen werden konfiguriert";
var wiz_start_manual_xav="";



var wlan_network_mark="WLAN";
var wlan_mark_ssid="Netzwerkname (SSID)";
var wlan_mark_reg="Region";
var wlan_mark_chan="Kanal";
var wlan_mark_mode="Modus";
var wlan_mark_gb="g und b";
var wlan_mark_go="nur g";
var wlan_mark_bo="nur b";
var wlan_mark_turbog="108 MBit/s automatisch";
var wlan_mode_54="Bis zu 54 MBit/s" ;
var wlan_mode_65="Bis zu 65 MBit/s" ;
var wlan_mode_130="Bis zu 130 MBit/s" ;
var wlan_mode_145="Bis zu 145 MBit/s" ;
var wlan_mode_150="Bis zu 150 MBit/s" ;
var wlan_mode_300="Bis zu 300 MBit/s";
var wlan_wlacl="Liste der zugriffsberechtigten WLAN-Karten";
var wir_wning = "Gemäß den Wi-Fi Alliance-Richtlinien für eine 40 MHz und 20 MHz-Koexistenz, kann Ihre Servicerate, selbst bei Auswahl des Modus Bis %s MBit/s, auf 20 MHz absinken. Dies entspricht üblicherweise einer Leistung von %s MBit/s.";

var sec_type="Sicherheitsoptionen";
var sec_off="Nein";
var sec_wep="WEP";
var sec_wpa="WPA-PSK [TKIP]";
var sec_wpa2="WPA2-PSK [AES]";
var sec_wpas="WPA-PSK [TKIP] + WPA2-PSK [AES]";
var sec_pr_wpa="Sicherheitsoption (WPA-PSK)";
var sec_pr_wpa2="Sicherheitsoption (WPA2-PSK)";
var sec_pr_wpas="Sicherheitsoption (WPA-PSK + WPA2-PSK)";
var sec_auth="Art der Authentifizierung:";
var sec_auto="Automatisch";
var sec_share="Shared Key";
var sec_enc="Schlüsseltiefe:";
var sec_64="64-Bit";
var sec_128="128-Bit";
var sec_enc_head="Verschlüsselung (WEP)";
var sec_key="WEP-Schlüssel";
var sec_key1="Schlüssel 1";
var sec_key2="Schlüssel 2";
var sec_key3="Schlüssel 3";
var sec_key4="Schlüssel 4";
var sec_phr="Kennwort";
var sec_863_or_64h="(8–63 Zeichen oder Hexadezimalzahl mit 64 Stellen)";
var wep_or_wps="WEP-Sicherheit mit Shared-Key-Authentifizierung ist nicht mit WPS kompatibel. WPS wird nicht mehr zugänglich sein. Wollen Sie fortfahren?";
var wep_just_one_ssid="Die WEP-Verschlüsselung wird nur für einen Netzwerknamen pro Band unterstützt " ;


var bh_internet_checking="Internetverbindung wird überprüft. Bitte warten.";

var SB011="Wenn Sie über eine vorhandene WLAN-Konfiguration verfügen, die von allen Client-Geräten verwendet wird, können Sie <font id=\"a\" onclick=\"click_here();\">hier klicken</font>, um die voreingestellten Einstellungen mit den vorhandenen zu aktualisieren.";
//BRS_02_genieHelp.html
var bh_config_net_connection="Konfigurieren der Internetverbindung";

var wlan_mark="Wireless-Konfiguration";
var wlan_mark_ssid="Netzwerkname (SSID)";
var sec_type="Sicherheitsoptionen";
var sec_off="Nein";
var sec_wep="WEP";
var sec_wpa="WPA-PSK [TKIP]";
var sec_wpa2="WPA2-PSK [AES]";
var sec_wpas="WPA-PSK [TKIP] + WPA2-PSK [AES]";
var sec_phr="Kennwort";


var bh_connection_further_action="Sie sind noch nicht mit dem Internet verbunden.";

var bh_want_genie_help="Benötigen Sie Hilfe von NETGEAR Genie?";

var bh_yes_mark=" Ja ";

var bh_no_genie_help="Nein, ich möchte die Internetverbindung selbst konfigurieren.";

var bh_no_genie_help_confirm="Zum Konfigurieren der Internetverbindung ist Erfahrung mit Netzwerken erforderlich. Sind Sie sicher?"

var bh_have_saved_copy="Ich habe die Routereinstellungen gespeichert und möchte den Router auf diese Einstellungen zurücksetzen.";

var bh_next_mark=" Weiter ";


//BRS_03A_detcInetType.html
var bh_detecting_connection="Erkennen der Internetverbindung";

var bh_plz_wait_process="Dieser Vorgang kann ein oder zwei Minuten dauern. Bitte warten...";


//BRS_03A_A_noWan.html
var bh_no_cable="Es wurde kein Netzwerkkabel an den Internet-Port des Routers angeschlossen.";

var bh_wizard_setup_nowan_check="Stellen Sie sicher, dass das Kabel richtig an den Breitband-Modem-Port und den Internet-Port des Routers angeschlossen ist.";

var bh_click_try_again="Nachdem Sie das Netzwerkkabel geprüft haben, klicken Sie auf <b>Wiederholen</b>.";

var bh_try_again="Wiederholen";


//BRS_03A_B_pppoe.html
var bh_pppoe_connection="PPPoE-DSL-Internetverbindung erkannt";

var bh_enter_info_below="Geben Sie die benötigten Informationen unten ein.";

var bh_pppoe_login_name="Benutzername";
var bh_ddns_passwd="Passwort";


//BRS_03A_B_pppoe_reenter.html
var bh_ISP_namePasswd_error="Ungültiger ISP-Benutzername oder ungültiges Passwort";

var bh_enter_info_again="Geben Sie die benötigten Informationen unten noch einmal ein.";


//BRS_03A_C_pptp.html
var bh_pptp_login_name="Benutzername";

var bh_pptp_connection="PPTP-Internetverbindung erkannt";

var bh_basic_pptp_servip="IP-Adresse des Servers";

var bh_sta_routes_gtwip="Gateway-IP-Adresse";

var bh_basic_pptp_connection_id="Verbindungs-ID/Name";

//BRS_03A_F_l2tp.html
var bh_l2tp_connection="L2TP Internet Connection Detected";

//BRS_03A_D_bigpond.html
var bh_bpa_connection="BigPond-Internetverbindung erkannt"; 

var bh_basic_bpa_auth_serv="Authentifizierungsserver";

var bh_basic_pppoe_idle="Leerlaufzeit (Minuten)";


//BRS_03A_E_IP_problem_staticIP.html
var bh_no_internet_ip="Problem beim Erkennen der Internetverbindung";

var bh_no_internet_ip2="Problem beim Erkennen der Internetverbindung – IP-Adresse";

var bh_no_internet_ip3="Problem beim Erkennen der Internetverbindung – MAC-Adresse";

var bh_if_have_static_ip="Hat Ihnen Ihr Internet-Dienstanbieter (ISP) eine feste (statische) IP-Adresse zugewiesen? Dies ist <b>sehr selten</b> der Fall. ";

var bh_yes_correct="Ja. Mein ISP hat mir eine feste (statische) IP-Adresse zugewiesen.";

var bh_not_have_static_ip="Nein, ich habe keine feste (statische) IP-Adresse von meinem ISP.";

var bh_do_not_know="Ich weiß nicht. ";

var bh_select_option="Wählen Sie eine Option aus, und klicken Sie zum Fortfahren auf <b>Weiter</b>.";

var bh_select_an_option="Wählen Sie zuerst eine Option aus.";


//BRS_03A_E_IP_problem_staticIP_A_inputIP.html
var bh_fix_ip_setting="Feste Internet-IP-Einstellungen";

var bh_enter_ip_setting="Geben Sie die von Ihrem Internet-Dienstanbieter zugewiesenen festen IP-Einstellungen ein, und klicken Sie zum Fortfahren auf <b>Weiter</b>.";

var bh_info_mark_ip="IP-Adresse";
//var bh_info_mark_ip="Eigene IP-Adresse";
var bh_info_mark_mask="Subnetzmaske";

var bh_constatus_defgtw="Gateway-IP-Adresse";

var bh_preferred_dns="Bevorzugter DNS-Server";

var bh_alternate_dns="Alternativer DNS-Server";

var bh_basic_int_third_dns="Dritter DNS";

//BRS_03A_E_IP_problem.html
var bh_genie_cannot_find_ip="Folgende Ursachen kommen dafür sehr wahrscheinlich infrage:";
var bh_genie_cannot_find_ip_reason1="1.  Das Modem wurde während des Anschlusses von Kabeln nicht aus- und wieder eingeschaltet.";
var bh_genie_cannot_find_ip_reason1_desc="Um das Problem zu lösen, schalten Sie das Modem aus und wieder ein. Bei Modems mit Akku muss mitunter der Akku herausgenommen und wieder eingesetzt werden. Warten Sie danach zwei Minuten, bis sich das Modem wieder vollständig eingeschaltet hat."; 
var bh_genie_cannot_find_ip_reason2="2.  Das gelbe Netzwerkkabel ist nicht ganz eingesteckt oder falsch angeschlossen.";
var bh_genie_cannot_find_ip_reason2_desc="Um das Problem zu lösen, schließen Sie das gelbe Netzwerkkabel ordnungsgemäß an den Breitbandmodem-Port und den Internet-Port des Routers an.";

var bh_select_no_IP_option="Wählen Sie eine der unten stehenden Optionen aus, und klicken Sie zum Fortfahren auf <b>Weiter</b>:";
var bh_select_no_IP_option1="Ich habe das Modem gerade aus- und wieder eingeschaltet und zwei Minuten gewartet.";
var bh_select_no_IP_option2="Ich habe ein Problem mit dem Netzwerkkabel behoben.";
var bh_select_no_IP_option3="Keine der oben genannten Aussagen.";


//BRS_03A_E_IP_problem_staticIP_B_macClone.html
var bh_use_pc_mac="Wenn Sie vorher schon per Computer oder mit einem anderen Router eine Verbindung ins Internet hergestellt haben, kann NETGEAR Genie dieselbe MAC-Adresse verwenden.";

var bh_mac_in_product_label="Eine MAC-Adresse ist eine eindeutige Nummer.  Sie steht auf dem Produktetikett des Computers oder Routers.";

var bh_enter_mac="Geben Sie hier die MAC-Adresse ein."

var bh_mac_format="(Format AABBCCDDEEFF)";


//BRS_03B_haveBackupFile.html
var bh_settings_restoration="Routereinstellungen wiederherstellen";

var bh_browser_file="Rufen Sie die zuvor gespeicherte Sicherungsdatei mit den Routereinstellungen auf, und klicken Sie zum Fortfahren auf <b>Weiter</b>.";

var bh_back_mark="Zurück";


//BRS_03B_haveBackupFile_fileRestore.html
var bh_settings_restoring="Wiederherstellung der Routereinstellungen"; 

var bh_plz_waite_restore="Dies kann einige Zeit dauern. Bitte warten …";


//BRS_04_applySettings.html
var bh_apply_connection="Übernehmen der Einstellungen für die Internetverbindung";

var bh_plz_waite_apply_connection="Dieser Vorgang kann ein oder zwei Minuten dauern. Bitte warten...";


//BRS_05_networkIssue.html
var bh_netword_issue="Problem mit Netzwerkverbindung."

var bh_cannot_connect_internet="Leider kann mit den derzeitigen Einstellungen keine Verbindung zwischen Router und Internet hergestellt werden.";

var bh_plz_reveiw_items="Bitte überprüfen Sie Folgendes:";

var bh_cable_connection="- Stellen Sie sicher, dass alle Kabel richtig angeschlossen sind. Anweisungen finden Sie im Router-Installationshandbuch.";

var bh_modem_power_properly="- Schalten Sie das Breitbandmodem aus und wieder ein. Wenn das Modem einen Akku hat, nehmen Sie ihn heraus, und setzen Sie ihn erneut ein.";

var bh_try_again_or_manual_config="Soll NETGEAR Genie es erneut versuchen?";

var bh_I_want_manual_config="Nein. Ich möchte die Internetverbindung selbst konfigurieren."; 

var bh_manual_config_connection="Ich möchte die Internetverbindung selbst konfigurieren.";


//BRS_success.html
var bh_congratulations="Glückwunsch!";

var bh_connect_success_1="Sie sind jetzt mit dem Internet verbunden.";

var bh_connect_success_2="Für den Router wurde folgender eindeutiger Netzwerkname (SSID) und";

var bh_network_key="Netzwerkschlüssel (Passwort) voreingestellt";

var bh_rollover_help_text="Damit Ihr Netzwerk vor unerwünschtem Zugriff geschützt ist, wurde der Router bereits mit WPA2-PSK-Sicherheit vorkonfiguriert. Um eine Verbindung mit dem drahtlosen Netzwerk herzustellen, geben Sie den Netzwerkschlüssel (Passwort) ein. Diese Voreinstellungen sind bei diesem Gerät individuell, wie z. B. eine Seriennummer.  Sie können die Einstellungen später in der Benutzeroberfläche des Routers auf dem Bildschirm WLAN-Konfiguration ändern."; 

var bh_success_no_wireless_security_1 = "Für diesen Router sind keine WLAN-Sicherheitseinstellungen aktiviert. NETGEAR empfiehlt dringend, dass Sie ";
var bh_success_no_wireless_security_2 = "klicken Sie hier";
var bh_success_no_wireless_security_3 =  " um die WLAN-Sicherheitsfunktionen zu aktivieren und Ihr Netzwerk zu schützen.";

var bh_wirless_name="Wireless-Netzwerkname (SSID)"

var bh_wireless="WLAN";

var bh_wpa_wpa2_passpharse="Netzwerkschlüssel (Passwort)"; 

var bh_save_settings="Save router settings";

var bh_print_this="Ausdrucken";


var bh_take_to_internet="Mit dem Internet verbinden";

var bh_plz_wait_moment="Bitte haben Sie etwas Geduld...";

//the string for not_support_print is temporary.
var bh_not_support_print="Dieser Computer unterstützt keinen Drucker.";
//already exist
var bh_login_name_null="Benutzername darf nicht leer sein!";
var bh_password_error="Das bisherige Passwort ist falsch.";
var bh_idle_time_null="Geben Sie bitte die Leerlaufzeit ein.\n";
var bh_invalid_idle_time="Ungültige Leerlaufzeit. Bitte geben Sie eine gültige Zahl ein.\n";
var bh_invalid_myip="Ungültige eigene IP-Adresse. Bitte wiederholen Sie die Eingabe oder lassen Sie das Feld frei.";
var bh_invalid_gateway="Ungültige Gateway-IP-Adresse. Bitte wiederholen Sie die Eingabe";
var bh_bpa_invalid_serv_name="Ungültige Server-IP-Adresse zur Authentifizierung.";
var bh_invalid_servip_length="Die Etiketten sollten 63 Zeichen oder weniger enthalten.\n";
var bh_invalid_ip="Ungültige IP-Adresse. Bitte wiederholen Sie die Eingabe!";
var bh_invalid_mask="Ungültige Subnetzmaske. Bitte wiederholen Sie die Eingabe!\n";
var bh_same_subnet_ip_gtw="Die Gateway-IP-Adresse gehört zu einem anderen Subnetz als die  IP-Adresse!\n";
var bh_same_lan_wan_subnet="LAN IP address und WAN IP address dürfen nicht im gleichen Teilnetze sein! \n";
var bh_filename_null="Der Dateiname darf nicht leer sein.";
var bh_not_correct_file="Ungültiger Dateiname. Bitte wiederholen Sie die Eingabe:*.";
var bh_ask_for_restore="Warnung!\nDurch das Wiederherstellen der Einstellungen aus einer Konfigurationsdatei gehen alle aktuellen Einstellungen verloren.\nMöchten Sie den Vorgang wirklich fortsetzen?";
var bh_invalid_primary_dns="Ungültige primäre DNS-Adresse. Bitte wiederholen Sie die Eingabe.\n";
var bh_invalid_second_dns="Ungültige sekundäre DNS-Adresse. Bitte wiederholen Sie die Eingabe.\n";
var hb_invalid_third_dns="Invalid third DNS address. Please enter it again.\n";
var bh_dns_must_specified="Die DNS-Adresse muss angegeben werden.";
var bh_invalid_mac="Ungültige MAC-Address!";
var bh_failure_head="Fehler";
var bh_few_second="Hier wird in einigen Sekunden wieder die vorherige Seite angezeigt&nbsp;...";

var bh_important="Wichtige Information";
var bh_wanlan_conflict_info="Zur Vermeidung von Konflikten mit Ihrem Internet-Provider wurde die IP-Adresse des Routers geändert zu";
var bh_continue_mark="Weiter";


//readySHARE remote strings
var remote_share_head="ReadySHARE Cloud"

var ready_share_info1="Mit der ReadySHARE Cloud-Funktion erhalten Sie Cloud-Zugriff über das Internet auf ein USB-Speichergerät, das mit dem USB-Port Ihres Routers verbunden ist."
var how_setup_ready_share="So richten Sie ReadySHARE Cloud ein"
var ready_share_step1="Schritt 1: Sie benötigen ein ReadySHARE Cloud-Konto. Wenn Sie noch nicht über ein Konto verfügen,<a class='linktype' target='_blank' href='https://readyshare.netgear.com/site/index.jsp?pid=4&src=device'>klicken Sie hier</a>, um dieses einzurichten."
var ready_share_step2="Schritt 2: Geben Sie auf dieser Seite Ihren ReadySHARE Cloud-Benutzernamen und Ihr Passwort ein, um den Router und das an ihn angeschlossene USB-Speichergerät bei Ihrem Konto zu registrieren."
var ready_share_step3="Schritt 3: Melden Sie sich wieder mit Ihrem Konto bei <a class='linktype' target='_blank' href='http://readyshare.netgear.com/'>http://readyshare.netgear.com/</a> an. Sie sollten nun das an Ihren Router angeschlossene USB-Gerät sehen."
var ready_share_step4="Schritt 4: Bei der ersten Anmeldung werden Sie aufgefordert, einen Windows Client herunterzuladen, mit dem eine sichere Verbindung von Ihrem PC zum USB-Gerät des Routers hergestellt werden kann. Melden Sie sich bei diesem Client an, und Sie können von jedem beliebigen Standort aus auf das USB-Gerät zugreifen."
var ready_share_set_note="<b>Hinweis:</b> Ohne diesen Client können Sie den Inhalt des USB-Geräts durchsuchen aber keine Dateien öffnen oder Änderungen an ihnen vornehmen."
var ready_share_start="Aktivieren Sie jetzt ReadySHARE Cloud"
var ready_share_get_account="Wenn Sie kein ReadySHARE Cloud-Konto haben, <a class='linktype' target='_blank' href='https://readyshare.netgear.com/site/index.jsp?pid=4&src=device'>klicken Sie hier</a>, um eines zu erstellen"
var username="Benutzername"
var key_passphrase="Passwort"
var register="Registrieren"
var register_note="<b>Hinweis:</b> Das Internet bleibt aktiv, bis Sie sich abmelden."
var help_center="Hilfe-Center"
var help_show_hide="Hilfe-Center ein-/ausblenden"

var resister_user="ReadySHARE Cloud ist registriert mit dem Benutzer"
var access_storage_method="Sie können den Schritten 2 bis 4 folgen, um überall auf das Speichergerät zuzugreifen."
var unregister_info="Klicken Sie auf <B>Registrierung aufheben</B>, um ReadySHARE Cloud mit einem anderen Benutzer zu registrieren."
var unregister="Registrierung aufheben"

var result_register_ok="Registrierung erfolgreich abgeschlossen"
var result_register_fail="Registrierung fehlgeschlagen"
var result_unreg_ok="Abmeldung erfolgreich abgeschlossen"
var result_unreg_fail="Abmeldung fehlgeschlagen"


//for wireless check string
var wps_in_progress="Der WPS-Vorgang läuft. Übernehmen Sie die Änderungen später."
var ssid_null="SSID darf nicht leer sein."
var ssid_not_allowed_same="Dieser Netzwerkname (SSID) existiert bereits. Wählen Sie bitte einen anderen."
var ssid_not_allowed="Dieses Zeichen ist in der SSID nicht zulässig."
var SWSW02="<b>WEP</b> oder <b>WPA-PSK [TKIP]-Sicherheitsauthentifizierung</b> sind nicht mit WPS kompatibel. Der Zugriff auf WPS wird nicht möglich sein. Möchten Sie fortfahren?"
var SWSW11="WPS erfordert SSID-Broadcast. Wenn Sie diese Änderung vornehmen, kann auf WPS nicht mehr zugegriffen werden. Möchten Sie fortfahren?"
var SWSW12="Sind Sie sicher, dass Sie für Ihr Netzwerk keine Wireless-Sicherheit möchten? Diese Einstellung wird üblicherweise für Wireless Hot Spots verwendet, die öffentlich zugänglich sind. Möchten Sie fortfahren?"
var wds_auto_channel="WLAN-Repeating funktioniert nicht mit automatischer Kanalsuche.\nÄndern Sie bitte die Kanal-Einstellungen entsprechend, bevor Sie WLAN-Repeating aktivieren. "
var notallowpassp="Dieses Zeichen ist in der Passphrase nicht zulässig."
var guest_tkip_300_150="WPA-PSK [TKIP] darf NUR im (Wireless-G)-Modus \"Bis zu 54MBit/s\" betrieben werden, aber nicht im N-Modus."
var guest_tkip_aes_300_150="NETGEAR empfiehlt die Verwendung von WPA2-PSK [AES], um von der vollen Unterstützung für die Ausgangsrate N zu profitieren."
var wlan_tkip_aes_300_150="WICHTIG\nWPA-PSK [TKIP] kann eventuell nur im Modus \"Bis zu 54 MBit/s\" betrieben werden, aber nicht mit der Ausgangsrate N.\nNETGEAR empfiehlt die Verwendung von WPA2-PSK [AES], um von der vollen Unterstützung für die Ausgangsrate N zu profitieren."
var notSupportWLA="In Israel und im Nahen Osten wird 802.11a nicht unterstützt. Wenn Sie diese Option auswählen, wird Wireless a/n beendet. Möchten Sie trotzdem fortfahren?"
var passphrase_short8="Die eingegebene Passphrase ist zu kurz (mindestens acht Zeichen)"
var passphrase_long63="Die eingegebene Passphrase ist zu lang (höchstens 63 Zeichen)."


