#! /bin/sh

wan_hwifname=`/usr/sbin/nvram get wan_hwifname`

pppd maxfail 1 plugin rp-pppoe.so $wan_hwifname user guest@flets  password guest mtu 1450 mru 1450 persist idle 0 usepeerdns defaultroute lcp-echo-failure 3 lcp-echo-interval 30 iface_num 8 flets_test default_iface 1 unit 8 &
pppd maxfail 1 plugin rp-pppoe.so $wan_hwifname user flets@flets  password flets mtu 1450 mru 1450 persist idle 0 usepeerdns defaultroute lcp-echo-failure 3 lcp-echo-interval 30 iface_num 9 flets_test default_iface 1 unit 9 &
