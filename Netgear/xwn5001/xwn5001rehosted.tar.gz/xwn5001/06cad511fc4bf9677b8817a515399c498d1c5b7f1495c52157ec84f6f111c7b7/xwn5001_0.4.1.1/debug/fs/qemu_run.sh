cd /

/usr/sbin/uhttpd  

