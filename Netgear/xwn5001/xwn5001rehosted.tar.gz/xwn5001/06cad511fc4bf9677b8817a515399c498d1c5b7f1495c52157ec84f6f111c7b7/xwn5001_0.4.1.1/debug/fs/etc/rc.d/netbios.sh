#!/bin/sh

RETVAL=0
prog="wins"
PID_FILE="/var/run/wins.pid"
NETBIOS_CONF_FILE="/tmp/netbios.conf"
workgroup=Workgroup
#hostname=`nvram get wan_hostname`
hostname=`nvram get netbiosname`
lan_ifname=`nvram get lan_ifname`

start() {
	# Start daemons.
	echo $"Starting $prog: "

 	#update /tmp/netbios.conf file
 	rm -f ${NETBIOS_CONF_FILE}
 	
 	echo "interface = $lan_ifname"			>${NETBIOS_CONF_FILE}
 	echo "hostname = $hostname"					>>${NETBIOS_CONF_FILE}
	echo "workgroup = \"$workgroup\""     		>>${NETBIOS_CONF_FILE}
 	echo "comment   = \"NETGEAR $hostname\""	>>${NETBIOS_CONF_FILE}
 
	${prog} &
	RETVAL=$?
	echo
	return $RETVAL
}

stop() {
	killall -9 ${prog} #for release
	rm -f ${PID_FILE}
	RETVAL=$?
	echo
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL


