#!/bin/sh

KEY=`nvram get sysDNSKey`
DOMAIN=`nvram get sysDNSTHost`
EMAIL=`nvram get sysDNSEmail`
IP=`nvram get wan0_ipaddr`
TIMER=`nvram get sysDNSTInterval`

start()
{
    echo "TZO start"
    if [ -f /tmp/run/tzoupdate ]; then
		kill -14 `cat /tmp/run/tzoupdate`
	else
	    #tzoupdate -d $DOMAIN -e $EMAIL -k $KEY -l $IP -t $TIMER &
    	tzoupdate -d $DOMAIN -e $EMAIL -k $KEY -l 192.37.73.148 -t $TIMER &
    fi
}

stop()
{
	echo "TZO stop"
    if [ -f /tmp/TZO_LastIpAddress ]; then
    	rm -f /tmp/TZO_LastIpAddress
    fi
    if [ -f /tmp/TZO_LogonStatus ]; then
    	rm -f /tmp/TZO_LogonStatus
    fi
    if [ -f /tmp/run/tzoupdate ]; then
    	rm -f /tmp/run/tzoupdate
    fi
    killall -9 tzoupdate
}

case "$1" in
  start)
    start
    ;;
  stop)
    stop
    ;;
  restart)
    stop
    start
    ;;
  *)
    echo $"Usage: $0 {start|stop|restart}"
    exit 1
esac

exit 1

