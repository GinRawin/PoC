function initPage()
{
	var head_tag  = document.getElementsByTagName("h1");
	var connect_text = document.createTextNode(bh_internet_checking);
	head_tag[0].appendChild(connect_text);
	
	loadValue();
}

function loadValue()
{
	var forms = document.getElementsByTagName("form");
	var cf = forms[0];

	if(ping_result == "failed")	//failed
	{
		this.location.href = "internet_failed_spbu.html";
	}
	else if(ping_result == "success") //success
	{
	/*	if(hijack_process == 2)
			cf.submit();
		else
	*/		this.location.href = "wiz_BRS_success_spbu.html";
	}	
	else if(counter > 9 )	//none
	{
		this.location.href = "internet_failed_spbu.html";	
	}
	setTimeout("loadValue();", 1000);
}

addLoadEvent(initPage);
