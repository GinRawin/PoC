#!/bin/sh

sleep 15

wan0_ipaddr=`nvram get wan0_ipaddr`

if [ "$wan0_ipaddr" = "" ]; then
   echo "###### no wan ip"
   /sbin/ledcontrol -n internet_ng -s on
   #if [ -f /tmp/ip_conflict ]; then
   #   /sbin/diagLed_hdl 5 &
   #   rm -rf /tmp/ip_conflict
   #fi
fi

