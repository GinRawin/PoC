#!/bin/sh
#
# script file to start WLAN for WPS 2.0 SPEC
#
#set -o xtrace
nvram=/usr/sbin/nvram
WLAN_IF="ath0"
WAN_IF=`nvram get wan_ifname`
BR="br0"
sys_uptime=$([ -f /proc/uptime ] && cat /proc/uptime | awk '{print $1}' | awk -F. '{print $1}')
MSSID_num=1
SSID_ACT=0
MSSID_disable=1
RUN_GUEST_ACCESS_FILE=0
KVER=`uname -r | cut -f 1 -d '-'`
MODULE_PATH=/lib/modules/$KVER/net
hostapd=/sbin/hostapd
dir_hostapd=/tmp/hostapd
topo=/tmp/topology.conf
guest_access_file=/tmp/guest_access
TMP_HOSTAPD=$hostapd #/tmp/hostapd_$1
HOSTAPD_CLI=/sbin/hostapd_cli
################################################################################################

NV_NAME()
{
        if [ "$1" = "0" ]; then
            printf ""
        
        else
            printf "_$(($1+1))"
        
        fi     
}


##MODE##
MODE="ap"
if [ "$(nvram get wds_endis_fun)" = "1" -a "$(nvram get wds_repeater_basic)" = "0" -a "$(nvram get wds_endis_mac_client)" = "1" ]; then        
    MODE="repeater"
fi
MODE_a="ap"
if [ "$(nvram get wds_endis_fun_a)" = "1" -a "$(nvram get wds_repeater_basic_a)" = "0" -a "$(nvram get wds_endis_mac_client_a)" = "1" ]; then        
    MODE_a="repeater"
fi
##

config_open_hostapd()
{
cat <<EOF
#
# Open (NO) Security
#
driver=atheros
#wps_cred_processing=1
wps_ignore_hw_pbevent=0
hw_mode=g
ieee80211n=1


wpa=0

interface=$1
ssid=$2
auth_algs=1

logger_syslog_level=3
logger_stdout_level=3
ctrl_interface=/var/run/hostapd
ctrl_interface_group=0
macaddr_acl=0
bridge=br0
wme_enabled=0

# hw_mode=a
# driver=atheros
logger_syslog=-1
logger_stdout=-1
dump_file=/tmp/hostapd.dump
ignore_broadcast_ssid=0
ieee8021x=0
eapol_key_index_workaround=0

#
# WSC configuration section
#
config_methods=label virtual_push_button physical_push_button virtual_display
EOF
}

config_wep_hostapd()
{
cat <<EOF
#
# WEP Selected
#
#using expr the index should be reduced by 1

driver=atheros
#wps_cred_processing=1
wps_ignore_hw_pbevent=0
hw_mode=g
ieee80211n=1


wep_default_key=$3
auth_algs=1
wep_key0=$4
wep_key1=$5
wep_key2=$6
wep_key3=$7

interface=$1
ssid=$2
auth_algs=1
logger_syslog_level=2
logger_stdout_level=2
ctrl_interface=/var/run/hostapd
ctrl_interface_group=0
macaddr_acl=0
bridge=br0
wme_enabled=0

# hw_mode=a
logger_syslog=-1
logger_stdout=-1
dump_file=/tmp/hostapd.dump
ignore_broadcast_ssid=0
ieee8021x=0
eapol_key_index_workaround=0
dtim_period=2
max_num_sta=255
wep_rekey_period=300
wep_key_len_broadcast=5
wep_key_len_unicast=5

#
# WSC configuration section
#
config_methods=label virtual_push_button physical_push_button virtual_display
EOF
}

config_psk_hostapd()
{
cat <<EOF
#
# WPA-PSK Selected
#


driver=atheros
#wps_cred_processing=1
wps_ignore_hw_pbevent=0
hw_mode=g
ieee80211n=1

wpa=$5
wpa_key_mgmt=WPA-PSK
wpa_pairwise=$4
wpa_group_rekey=86400
wpa_gmk_rekey=86400
wpa_strict_rekey=0
wpa_ptk_rekey=0

interface=$1
ssid=$2
auth_algs=1

logger_syslog_level=3
logger_stdout_level=3
ctrl_interface=/var/run/hostapd
ctrl_interface_group=0
macaddr_acl=0
bridge=br0
wme_enabled=0

# hw_mode=a
logger_syslog=-1
logger_stdout=-1
dump_file=/tmp/hostapd.dump
ignore_broadcast_ssid=0
ieee8021x=0
eapol_key_index_workaround=0

#
# WSC configuration section
#
config_methods=label virtual_push_button physical_push_button virtual_display
EOF
}

config_psk_none_wps_hostapd()
{
cat <<EOF
#
# WPA-PSK Selected
#
wpa=$5
wpa_passphrase=$3
wpa_key_mgmt=WPA-PSK
wpa_pairwise=$4
wpa_group_rekey=3600
wpa_gmk_rekey=3600
wpa_strict_rekey=1

interface=$1
ssid=$2
bridge=br0
logger_syslog=-1
logger_syslog_level=2
logger_stdout=-1
logger_stdout_level=2
ctrl_interface=/var/run/hostapd
ctrl_interface_group=0
dtim_period=2
max_num_sta=255
macaddr_acl=0
auth_algs=1
ignore_broadcast_ssid=0
wme_enabled=0
ieee8021x=0
eapol_version=2
eapol_key_index_workaround=0
eap_server=1
EOF
}

#$1: Interface(eth0)    $2: ssid(DNI_WIFI)    $3:own_ip_addr(192.168.1.1)
#$4: auth_server_addr(192.168.1.10)    $5: auth_server_port(1812)    $6: auth_server_shared_secret(securite)
#$7: wpa(1 | 2 | 3)    $8: wpa_pairwise(TKIP | CCMP | TKIP CCMP)
config_psk_radius_hostapd()
{
cat <<EOF
#
# RADIUS Selected
#
# The own IP address of the access point (used as NAS-IP-Address)
own_ip_addr=$3
#nas_identifier=test.5gwireless.com

# RADIUS authentication server
auth_server_addr=$4
auth_server_port=$5
auth_server_shared_secret=$6
# RADIUS accounting server
#acct_server_addr=$4
#acct_server_port=1813
#acct_server_shared_secret=$6

### WPA
wpa=$7
wpa_key_mgmt=WPA-EAP
wpa_pairwise=$8
wpa_group_rekey=300
wpa_gmk_rekey=640

logger_syslog=-1
logger_syslog_level=3
logger_stdout=-1
logger_stdout_level=3

bridge=br0
interface=$1
ssid=$2
dump_file=/tmp/hostapd.dump
ctrl_interface=/var/run/hostapd
ctrl_interface_group=0
dtim_period=2
max_num_sta=255
macaddr_acl=0
ignore_broadcast_ssid=0
wme_enabled=0
ieee8021x=1
auth_algs=1

eap_server=0
eap_reauth_period=0
eapol_version=2
eapol_key_index_workaround=1

#===== Disable WPS =====
# wps_state=0
EOF
}

config_wpa_psk() #$1: interface $2: ssid $3: wpa_passphrase $4: wpa_pairwise $5: wpa
{
    CONF_HOSTAPD=/tmp/hostapd/hostapd_$1.conf
    config_psk_hostapd "$1" "$2" "$3" "$4" "$5" > $CONF_HOSTAPD
    if [ "$1" = "ath0" -o "$1" = "ath1" ] ; then 
        #if [ "$($nvram get endis_wl_wps)" = "1" ]; then
                set_wps $1 $CONF_HOSTAPD
        #fi
    fi

}

config_wpa_psk_none_wps() #$1: interface $2: ssid $3: wpa_passphrase $4: wpa_pairwise $5: wpa
{
    CONF_HOSTAPD=/tmp/hostapd/hostapd_$1.conf
    config_psk_none_wps_hostapd "$1" "$2" "$3" "$4" "$5" > $CONF_HOSTAPD

}

set_wps()
{    
	  #$1: athx
    #common settings
    echo "$1: Start WPS Configuration"		   
    AP_SETUP_LOCK="$((1-$(nvram get endis_pin)))"
    if [ "$(nvram get wps_status)" = "5" ]; then
        echo "wps_state=2" >> $2
        echo "pbc_in_m1=1" >> $2
    else
        echo "wps_state=1" >> $2
    fi

    DEVICE_PIN=`cat /tmp/wpspin`
    bridge=br0 #"$($nvram get lan_ifname)"
    DEV_NAME=$(nvram get netbiosname) #deriver from LAN Setup

    echo "eap_server=1" >>$2
    echo "ap_pin=$DEVICE_PIN" >> $2
    echo "upnp_iface=$bridge" >> $2

    echo "device_name=$DEV_NAME(Wireless AP)" >> $2
    echo "friendly_name=$DEV_NAME(Wireless AP)" >> $2
    echo "serial_number=12345" >> $2
    echo "manufacturer=NETGEAR, Inc." >> $2
    echo "model_name=$DEV_NAME(Wireless AP)" >> $2
    echo "model_number=$DEV_NAME" >>  $2
    echo "model_description=$DEV_NAME Wireless AP" >>  $2
    echo "device_type=6-0050F204-1" >>  $2
    if [ "$AP_SETUP_LOCK" = "1" -o "`cat /tmp/wscd_lock_stat`" = "1" ]; then
        echo "ap_setup_locked=1" >> $2
    fi
    if [ "$(nvram get endis_brutal)" = "1" ]; then
    	echo "wps_atk_times=$(nvram get wps_atk_times)" >> $2
    else
    	echo "wps_atk_times=99" >> $2
    fi

}

Ins_module()
{
    echo "*** Inserting Modules ***"
    insmod $MODULE_PATH/adf.ko
    insmod $MODULE_PATH/asf.ko
    insmod $MODULE_PATH/ath_hal.ko
    insmod $MODULE_PATH/ath_rate_atheros.ko

    #load DFS if A band is supported,default is supported and set AP_NO_A_BAND=1 if not supported
    #insmod $MODULE_PATH/ath_dfs.ko

    insmod $MODULE_PATH/ath_dev.ko
    insmod $MODULE_PATH/umac.ko flowmac_on=0
    insmod $MODULE_PATH/ath_pktlog.ko

    Set_region
    #wlanlog
    BOARD_REG=`artmtd -r region | grep region| cut -d " " -f 5`
		if [ "$BOARD_REG" = "0x0001" ]; then
			echo 1 > /proc/driver/ce_ini_proc
		else
			echo 2 > /proc/driver/ce_ini_proc		
		fi	

}
##end of Ins_module##


Rm_module()
{   
    echo "*** Removing Modules ***"
    rmmod ath_pktlog
    rmmod umac
    rmmod ath_dev
    #rmmod ath_dfs
    rmmod ath_rate_atheros
    rmmod ath_hal
    rmmod asf
    rmmod adf
}
##end of Rm_module##


Set_region()
{
    country_code_0=710              # Africa
    country_code_1=156              # Asia china
    country_code_2=5000             # Australia
    country_code_3=5001             # Canada
    country_code_4=276              # Europe Germany
    country_code_5=376              # Israel
    country_code_6=392              # Japan
    country_code_7=412              # Korea
    country_code_8=484              # Mexico
    country_code_9=76               # South America Brazil
    country_code_10=841             # United States
    country_code_11=376             # Middle East, use Israel instead
    country_code_12=156             # China
    country_code_13=643             # Russia
    COUN=$((country_code_`nvram get wl_country`))
    #echo "iwpriv wifi0 setCountryID $COUN"
    iwpriv wifi0 setCountryID $COUN
}
##end of Set_region##

Basic_setting()
{
     
    # 2.4G
    if [ "$2" = "bgn" ]; then
        IF_IND=`NV_NAME $1`
        IF_NAME=ath$1
        echo "$IF_NAME: basic settings"
        WL_SSID="$(nvram get wl_ssid$IF_IND | sed -e 's/\\\\\\\\/\\/g' -e 's/\\\\\\`/`/g' -e 's/\\\"/"/g')"
        WL_ISO=$(nvram get endis_wlan_iso$IF_IND)
        WL_BCAST=$(nvram get endis_ssid_broadcast$IF_IND)
        ifconfig wifi0 txqueuelen 1000

        
        case "$(nvram get wl_simple_mode)" in
        1)
            echo "$IF_NAME: up to 54M"
            iwpriv $IF_NAME mode 11G
            iwpriv $IF_NAME pureg 0
            ;;
        2)
            echo "$IF_NAME: up to 150M"
            iwpriv $IF_NAME mode 11NGHT20
            iwpriv $IF_NAME shortgi 1
            iwpriv $IF_NAME puren 0
            ;;
        3)
            echo "$IF_NAME: up to 300M"
            iwpriv $IF_NAME mode 11NGHT40PLUS
            iwpriv $IF_NAME shortgi 1
            iwpriv $IF_NAME puren 0
            ;;
        5)
            echo "$IF_NAME: up to 300M"
            iwpriv $IF_NAME mode 11NGHT40MINUS
            iwpriv $IF_NAME shortgi 1
            iwpriv $IF_NAME puren 0
            ;;
        6)    
            echo "$IF_NAME: up to 300M"
            iwpriv $IF_NAME mode 11NGHT40
            iwpriv $IF_NAME shortgi 1
            iwpriv $IF_NAME puren 0
            ;;
        esac
        
        iwpriv $IF_NAME vap_doth 0
        #iwpriv $IF_NAME athnewind 1      
        #iwpriv $IF_NAME protmode 1   # 802.11g protection mode
        #iwpriv $IF_NAME htweptkip 0
        
		    iwpriv wifi0 ForBiasAuto 1
		    if [ "$(nvram get wl_simple_mode)" = "1" ]; then
        	iwconfig $IF_NAME frag "$(nvram get wl_frag)"
			fi	
        
        iwpriv wifi0 AMPDU 1
        iwpriv wifi0 AMPDUFrames 32
        iwpriv wifi0 AMPDULim 50000
        
        WL_RTS=`nvram get wl_rts`
        if [ "$WL_RTS" = "2347" ];then
            iwconfig $IF_NAME rts off
        else
            iwconfig $IF_NAME rts "$WL_RTS"
        fi
        
		
		
        #iwconfig $IF_NAME rate "$(nvram get wl_rate)"
        iwpriv $IF_NAME wmm "$(nvram get endis_wl_wmm)"
        iwpriv $IF_NAME hide_ssid $((1-$WL_BCAST))
        [ "$(nvram get wl_plcphdr)" = "2" ] && iwpriv $IF_NAME shpreamble 0 || iwpriv $IF_NAME shpreamble 1
        #iwpriv $IF_NAME xr "$(nvram get endis_xr)"
        
        if [ "$WL_ISO" = "1" ]; then
            iwpriv $IF_NAME ap_bridge 0
        else
            iwpriv $IF_NAME ap_bridge 1
        fi

				iwconfig $IF_NAME essid "$WL_SSID"
        iwconfig $IF_NAME freq "$(nvram get wl_hidden_channel)"       
   fi
    
}
##end of Basic_setting##


Security()
{    
    # 2.4G
    mkdir -p $dir_hostapd
    if [ "$2" = "bgn" ]; then
        IF_IND=`NV_NAME $1`
        IF_NAME=ath$1
        echo "$IF_NAME: Security"

        WL_SSID="$(nvram get wl_ssid$IF_IND | sed -e 's/\\\\\\\\/\\/g' -e 's/\\\\\\`/`/g' -e 's/\\\"/"/g')"
        WL_SECTYPE=`nvram get wl_sectype$IF_IND`
        WL_AUTH=`nvram get wl_auth$IF_IND`
        WL_KEY=`nvram get wl_key$IF_IND`
        
        WL_WPA1_KEY="$(nvram get wl_wpa1_psk$IF_IND | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
        WL_WPA2_KEY="$(nvram get wl_wpa2_psk$IF_IND | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
        WL_WPASPSK_KEY="$(nvram get wl_wpas_psk$IF_IND | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
        WL_WPAX_KEYLEN="$(nvram get wl_sec_wpaphrase_len$IF_IND)"        
        
        # 'WPA/WPA2 Enterprise 
        #WL_RADIUS_MODE="$(nvram get wl_radius_mode$IF_IND)"
        WL_RAD_MODE="$(nvram get wl_wpae_mode$IF_IND)"
        WL_RAD_SERIP=$($nvram get wl_radiusSerIp$IF_IND)
        WL_RAD_SECTYPE=$($nvram get wl_radiusSecret$IF_IND)
        WL_RAD_PORT=$($nvram get wl_radiusPort$IF_IND)
		ACL_DIS_WPS=`nvram get acl_wps_disable`
		SSID_BCAST=`nvram get endis_ssid_broadcast`
		WDS_EN=$(nvram get wds_endis_fun)
		#for spbu
		DIS_PIN_SPBU=`nvram get dis_pin_spbu`
                
        #echo "WL_SSID=$WL_SSID, WL_SECTYPE=$WL_SECTYPE, WL_AUTH=$WL_AUTH, WL_KEY=$WL_KEY"
        CONF_HOSTAPD=/tmp/hostapd/hostapd_$IF_NAME.conf
        case $WL_SECTYPE in
        1) #none
            echo "$1: Security none"
            config_open_hostapd "$IF_NAME" "$WL_SSID" > $CONF_HOSTAPD
            if [ "$AP_INDEX" -le "1" ]; then
				if [ "$ACL_DIS_WPS" != "1" -a "$WDS_EN" = "0" ]; then
					if [ "$DIS_PIN_SPBU" -ne "1" ]; then
						set_wps $IF_NAME $CONF_HOSTAPD
						echo "$1: Security none: set wps !!!!!!!!!!!!!!!!!!!!!!!!!!!!"
					else
						echo "$1: Security none: not set wps !!!!!!!!!!!!!!!!!!!!!!!!!!!!"
					fi
				fi
            fi
        
            ;;
        2) #wep
            echo "$IF_NAME: Security wep"

            WEP_KEY0=$(nvram get wl_key1$IF_IND)
            WEP_KEY1=$(nvram get wl_key2$IF_IND)
            WEP_KEY2=$(nvram get wl_key3$IF_IND)
            WEP_KEY3=$(nvram get wl_key4$IF_IND)
                  
            iwpriv $IF_NAME wpa 0
        
            echo "$IF_NAME: WEP_KEY0=$WEP_KEY0, WEP_KEY1=$WEP_KEY1, WEP_KEY2=$WEP_KEY2, WEP_KEY3=$WEP_KEY3"
            case "$WL_AUTH" in
            0) #open
	              echo "$IF_NAME: Security wep open"
                iwpriv $IF_NAME authmode 1
                ;;
            1) #shared
                echo "$IF_NAME: Security wep share"
                iwpriv $IF_NAME authmode 2
                ;;
            2) #auto
                echo "$IF_NAME: Security wep auto"
                iwpriv $IF_NAME authmode 4
                ;;
            esac
        
            if [ "$WEP_KEY0" != "" ]; then
                iwconfig $IF_NAME enc  ${WEP_KEY0} [1]
            fi
            if [ "$WEP_KEY1" != "" ]; then
                iwconfig $IF_NAME enc  ${WEP_KEY1} [2]
            fi
            if [ "$WEP_KEY2" != "" ]; then
                iwconfig $IF_NAME enc  ${WEP_KEY2} [3]
            fi
            if [ "$WEP_KEY3" != "" ]; then
                iwconfig $IF_NAME enc  ${WEP_KEY3} [4]
            fi
        		iwconfig $IF_NAME enc [${WL_KEY}] 
        	      		
        		#config_wep_hostapd "$IF_NAME" "$WL_SSID" "$((WL_KEY-1))" "$WEP_KEY0" "$WEP_KEY1" "$WEP_KEY2" "$WEP_KEY3" > $CONF_HOSTAPD
        
            #WPS Startup    
            #WPS 2.0 Spec.
            echo "*** WARNING: WPS is enabled in WEP mode!! ***"
            echo "*** WARNING: WPS is disabled  ***"
            echo "*** WARNING: HOSTAPD isn't start-up!! ***"
            ;;
        3) #wpa-psk
            echo "$IF_NAME: Security wpa-psk(TKIP)"
            sec_algo="TKIP"
            #config_wpa_psk $IF_NAME "$WL_SSID" "$WL_WPA1_KEY" "$sec_algo" 1
            config_psk_hostapd "$IF_NAME" "$WL_SSID" "$WL_WPA1_KEY" "$sec_algo" "1" > $CONF_HOSTAPD
            if [ "${#WL_WPA1_KEY}" = "64" ]; then
							echo "wpa_psk=$WL_WPA1_KEY" >> $CONF_HOSTAPD
						else
							echo "wpa_passphrase=$WL_WPA1_KEY" >> $CONF_HOSTAPD
						fi	     
            echo "*** WARNING: WPS is enabled in TKIP only mode!! ***"
            echo "*** WARNING: WPS is disabled  ***"        
            ;;
        4) #wpa2-psk
            echo "$IF_NAME: Security wpa2-psk(AES)"
            sec_algo="CCMP"
            #config_wpa_psk $IF_NAME "$WL_SSID" "$WL_WPA2_KEY" "$sec_algo" 2
            config_psk_hostapd "$IF_NAME" "$WL_SSID" "$WL_WPA2_KEY" "$sec_algo" "2" > $CONF_HOSTAPD
            if [ "${#WL_WPA2_KEY}" = "64" ]; then
							echo "wpa_psk=$WL_WPA2_KEY" >> $CONF_HOSTAPD
						else
							echo "wpa_passphrase=$WL_WPA2_KEY" >> $CONF_HOSTAPD
						fi	     
           	if [ "$ACL_DIS_WPS" != "1"  -a "$WDS_EN" = "0" ]; then
							set_wps $IF_NAME $CONF_HOSTAPD
						fi
            ;;
        5) #wpa-psk/wpa2-psk
            # Limited key_length=64, using wpa_passphrase!
            echo "$IF_NAME: Security wpa-psk(TKIP)+wpa2-psk(AES)"
            sec_algo="TKIP CCMP"
            #config_wpa_psk $IF_NAME "$WL_SSID" "$WL_WPASPSK_KEY" "$sec_algo" 3
            config_psk_hostapd "$IF_NAME" "$WL_SSID" "$WL_WPASPSK_KEY" "$sec_algo" "3" > $CONF_HOSTAPD
            if [ "${#WL_WPASPSK_KEY}" = "64" ]; then
							echo "wpa_psk=$WL_WPASPSK_KEY" >> $CONF_HOSTAPD
						else
							echo "wpa_passphrase=$WL_WPASPSK_KEY" >> $CONF_HOSTAPD
						fi	 
            if [ "$ACL_DIS_WPS" != "1"  -a "$WDS_EN" = "0" ]; then
							set_wps $IF_NAME $CONF_HOSTAPD
            fi
				;;
        6) #wpa/wpa2-enterprise
            echo "$IF_NAME: Security wpa/wpa2 enterprise"
            case "$WL_RAD_MODE" in
            "WPAE-TKIP") #wpa (tkip)
                echo "$IF_NAME: wpa(tkip) encryption mode"
                sec_algo="TKIP"
                config_psk_radius_hostapd $IF_NAME $WL_SSID `nvram get lan_ipaddr` $WL_RAD_SERIP $WL_RAD_PORT $WL_RAD_SECTYPE 1 "$sec_algo" > $CONF_HOSTAPD
                ;;
            "WPAE-AES") #wpa2 (aes)
                echo "$IF_NAME: wpa2(aes) encryption mode"
                sec_algo="CCMP"
                config_psk_radius_hostapd $IF_NAME $WL_SSID `nvram get lan_ipaddr` $WL_RAD_SERIP $WL_RAD_PORT $WL_RAD_SECTYPE 2 "$sec_algo" > $CONF_HOSTAPD
                ;;
            "WPAE-TKIPAES") #wpa (tkip) + wpa2 (aes)
                echo "$IF_NAME: wpa(tkip) + wpa2(aes) encryption mode"
                sec_algo="CCMP TKIP"
                config_psk_radius_hostapd $IF_NAME $WL_SSID `nvram get lan_ipaddr` $WL_RAD_SERIP $WL_RAD_PORT $WL_RAD_SECTYPE 3 "$sec_algo" > $CONF_HOSTAPD
                ;;
            esac
        
            ;;
        esac
        if [ "$WL_SECTYPE" != 2 ]; then
     				echo "Running hostapd!"
     				$TMP_HOSTAPD -d $CONF_HOSTAPD &
      	fi

    
    fi
    
}
##end of Security##

ACL()
{
    # 2.4G
    if [ "$2" = "bgn" ]; then
        IF_IND=`NV_NAME $1`
        IF_NAME=ath$1
        echo "$IF_NAME: ACL Start...."
        MACAC_ENABLED=`nvram get wl_access_ctrl_on`
        if [ "$MACAC_ENABLED" != "0" ]; then
            iwpriv $IF_NAME maccmd $MACAC_ENABLED
            MACAC_NUM=`nvram get wl_acl_num`
            if [ "$MACAC_NUM" != "0" ]; then
                num=1
                while [ $num -le $MACAC_NUM ]
                do
                    AC_MAC=`nvram get wlacl$num | awk '{print $2}'`
                    iwpriv $IF_NAME addmac $AC_MAC
                    num=$(($num+1))
                done
            fi
        fi
    fi
}
##end of ACL##

Wds()
{
    if [ "$1" = "start" ]; then
    		
        # 2.4G
        if [ "$2" = "bgn" ]; then
           IF_IND=`NV_NAME $1`
           IF_NAME=ath$1echo "Wds start:"
           if [ "$(nvram get wds_endis_fun)" = "1" ]; then
                brctl stp $BR on
                if [ "$(nvram get wds_repeater_basic)" = "1" ]; then  ##root-ap##
                    echo "root ap"
                    iwpriv ath0 wds 1
                    if [ "$(nvram get wds_endis_mac_client)" = "1" ]; then
                        iwpriv ath0 maccmd 1 
                    fi
                    wlanconfig ath0 nawds mode 2
                    for rep in 1 2 3 4; do
                        repeater_mac=$(nvram get repeater_mac$rep)
                        if [ "$repeater_mac" != "" ]; then
                            wlanconfig ath0 nawds add-repeater $repeater_mac 0x6
                        fi
                    done
                else  ##repeater##
                    echo "repeater"
                    wlanconfig wds5 create wlandev wifi0 wlanmode sta nosbeacon
                    if [ "$(nvram get wl_sectype)" = "2" ]; then
                        AP_WEPKEY1=`nvram get wl_key1`
                        AP_WEPKEY2=`nvram get wl_key2`
                        AP_WEPKEY3=`nvram get wl_key3`
                        AP_WEPKEY4=`nvram get wl_key4`
            
                        iwpriv wds5 wpa 0
                        [ "$AP_WEPKEY1" = "" ] || iwconfig wds5 key [1] "$AP_WEPKEY1"
                        [ "$AP_WEPKEY2" = "" ] || iwconfig wds5 key [2] "$AP_WEPKEY2"
                        [ "$AP_WEPKEY3" = "" ] || iwconfig wds5 key [3] "$AP_WEPKEY3"
                        [ "$AP_WEPKEY4" = "" ] || iwconfig wds5 key [4] "$AP_WEPKEY4"
            
                        case "$(nvram get wl_auth)" in
                        0) #open
                            iwpriv wds5 authmode 1
                            iwconfig wds5 key ["$(nvram get wl_key)"] open
                            ;;
                        1) #shared
                            iwpriv wds5 authmode 2
                            iwconfig wds5 key ["$(nvram get wl_key)"] restricted
                            ;;
                        2) #auto
                            iwpriv wds5 authmode 4
                            iwconfig wds5 key ["$(nvram get wl_key)"]
                            ;;
                        esac
                    fi
            
                    iwpriv wds5 wds 1
                    iwpriv wds5 vap_ind 1
                    iwconfig wds5 mode managed freq $(nvram get wl_hidden_channel)
                    iwconfig wds5 ap $(nvram get basic_station_mac)
            
                    if [ "$(nvram get wds_endis_ip_client)" = "1" ]; then
                        iwpriv ath0 maccmd 1 
                    fi
                    ifconfig wds5 up
                    brctl addif $BR wds5
                fi
            fi
        fi
 
    else
        echo "Wds stop:" 
        wds_if=`ifconfig -a | grep wds`
        if [ "x$wds_if" != "x" ]; then
            ifconfig wds5 down
            brctl delif $BR wds5
            #echo "wlanconfig wds5 destroy"
            wlanconfig wds5 destroy
        fi
        iwpriv ath0 wds 0
        brctl stp $BR off
    fi      
}
##end of Wds##

Guest_access()
{
    ETH_P_ARP=0x0806
    ETH_P_RARP=0x8035
    ETH_P_IP=0x0800
    IPPROTO_ICMP=1
    IPPROTO_UDP=17
    DHCPS_DHCPC=67:68
    PORT_DNS=53

    cat<<EOF > $guest_access_file

#!/bin/sh

ebtables -F FORWARD
ebtables -F INPUT
ebtables -P FORWARD ACCEPT
ebtables -A FORWARD -p $ETH_P_ARP -j ACCEPT
ebtables -A FORWARD -p $ETH_P_RARP -j ACCEPT
ebtables -A FORWARD -p $ETH_P_IP --ip-proto $IPPROTO_UDP --ip-dport $DHCPS_DHCPC -j ACCEPT
ebtables -P INPUT ACCEPT
ebtables -A INPUT -p $ETH_P_IP --ip-proto $IPPROTO_UDP --ip-dport $DHCPS_DHCPC -j ACCEPT
ebtables -A INPUT -p $ETH_P_IP --ip-proto $IPPROTO_UDP --ip-dport $PORT_DNS -j ACCEPT
EOF

    ###2.4G
    #primary 
    if [ "$(nvram get endis_wlan_iso)" = "1" -a "$(nvram get endis_wl_radio)" = "1" ]; then
        RUN_GUEST_ACCESS_FILE=1
        echo "ebtables -A FORWARD -i ath0 -j DROP" >> $guest_access_file
        echo "ebtables -A INPUT -i ath0 -p $ETH_P_IP --ip-dst $(nvram get lan_ipaddr) -j DROP" >> $guest_access_file
    fi
     
    #guest

    index=1
    while [ "$index" -le "$MSSID_num" ]
             do
             IF_IND=`NV_NAME $index`
             		if [ "$(nvram get endis_allow_guest$IF_IND)" = "0" -a "$(nvram get endis_wl_radio$IF_IND)" = "1" ]; then
             		
             				RUN_GUEST_ACCESS_FILE=1
             				echo "ebtables -A FORWARD -i ath$index -j DROP" >> $guest_access_file
             				echo "ebtables -A INPUT -i ath$index -p $ETH_P_IP --ip-dst $(nvram get lan_ipaddr) -j DROP" >> $guest_access_file
             		
             		fi
             		index=$(($index+1))
             done 
    

    if [ "$RUN_GUEST_ACCESS_FILE" = "1" ]; then
        chmod +x $guest_access_file         
        $guest_access_file 
    else
        ebtables -F FORWARD
        ebtables -F INPUT
    fi
}
##end of Guest_access##

Create_vap()
{
    # Create 2.4G Interface from eth0
    wlanconfig ath0 create wlandev wifi0 wlanmode ap
    
    # Create Guest interface for 2.4G from eth0
    index=0
    guest_enable=0
    while [ "$index" -lt "$MSSID_num" ]
    do
        #if [ "$(nvram get endis_wl_radio_$(($index+2)))" = "1" ]; then
        if [ "$(nvram get wlg1_endis_guestNet)" = "1" ]; then
            guest_enable=1
        fi
        index=$(($index+1))
    done
    
    index=0
    if [ "$guest_enable" = "1" ]; then
        while [ "$index" -lt "$MSSID_num" ]
        do
            wlanconfig ath$(($index+2)) create wlandev wifi0 wlanmode ap
            index=$(($index+1))
        done
    fi
}
##end of Create_vap##

Parser()
{
		FILE="/tmp/sta.conf"
		INPUT=$1
		LINE=`cat $FILE | grep $INPUT | cut -c 8-`       #EX. ssid="12345"  ->  12345"
		if [ "$LINE" != "" ]; then
				VALUE=`echo $LINE | cut -c 1-$((${#LINE}-1))`    #remove " at the end
				printf $VALUE
		else
				printf "XXX"
		fi		
		
}
##end of Parser##

Sta_config()
{
		if [ "$1" = "start" ]; then
				wlanconfig ath5 create wlandev wifi0 wlanmode sta
				iwpriv ath5 wps 1
				#iwpriv ath5 athnewind 1
				
				if [ "$(nvram get wl_use_wps)" = "1" ]; then
						wpa_supplicant -i ath5 -b br0 -c /etc/ath/WSC_sta.conf -B
				else
				    SEC=$(nvram get wl_sectype_sta)
				    AP_SSID=$(nvram get wl_tar_ap_ssid)
				    sta_conf_file=$dir_hostapd/ath5.conf
				    
				    echo "network={" > $sta_conf_file
				    echo "ssid=\"$AP_SSID\"" >> $sta_conf_file
				    		    
				    case $SEC in
				    1)
				    		echo "key_mgmt=NONE" >> $sta_conf_file 
				    ;;
				    2)
				    		echo "key_mgmt=NONE" >> $sta_conf_file 
								echo "wep_key0=$(nvram get wl_key1_sta)" >> $sta_conf_file 
								echo "wep_key1=$(nvram get wl_key2_sta)" >> $sta_conf_file 
								echo "wep_key2=$(nvram get wl_key3_sta)" >> $sta_conf_file 
								echo "wep_key3=$(nvram get wl_key4_sta)" >> $sta_conf_file 
								echo "wep_tx_keyidx=$(nvram get wl_key_sta)" >> $sta_conf_file 
							  if [ "$(nvram get wl_auth_sta)" = "1" ]; then
    		  					echo "auth_alg=SHARED" >> $sta_conf_file 
    		  			fi		
				    ;;
				    3)
				    		echo "key_mgmt=WPA-PSK" >> $sta_conf_file 
	  		    		echo "proto=WPA" >> $sta_conf_file 
	  		    		echo "pairwise=TKIP" >> $sta_conf_file 
	  		    		echo "group=TKIP" >> $sta_conf_file 
	  		    		echo "scan_ssid=1" >> $sta_conf_file 
	  		    		echo "psk=\"$(nvram get wl_wpa1_psk_sta)\"" >> $sta_conf_file 
				    ;;
				    4)
				    		echo "key_mgmt=WPA-PSK" >> $sta_conf_file 
	  		    		echo "proto=WPA2" >> $sta_conf_file 
	  		    		echo "pairwise=CCMP" >> $sta_conf_file 
	  		    		echo "group=CCMP" >> $sta_conf_file 
	  		    		echo "scan_ssid=1" >> $sta_conf_file 
	  		    		echo "psk=\"$(nvram get wl_wpa2_psk_sta)\"" >> $sta_conf_file 
				    ;;
				    5)
				    		echo "key_mgmt=WPA-PSK" >> $sta_conf_file 
	  		    		echo "proto=WPA WPA2" >> $sta_conf_file 
	  		    		echo "pairwise=TKIP CCMP" >> $sta_conf_file 
	  		    		echo "group=TKIP CCMP" >> $sta_conf_file 
	  		    		echo "scan_ssid=1" >> $sta_conf_file 
	  		    		echo "psk=\"$(nvram get wl_wpas_psk_sta)\"" >> $sta_conf_file 
				    ;;
				    6)
				    ;;
				    esac
				    
				    echo "}" >> $sta_conf_file
				    wpa_supplicant -i ath5 -b br0 -c $sta_conf_file -B
				    brctl addif br0 ath5
				    
				
				fi
		else
				killall wpa_supplicant
				wlanconfig ath5 destroy
		fi
		
}
##end of Sta_config##

KILL_APP()
{
	PS=`ps`
	if [ "`echo $PS | grep $1`" != "" ]; then
			killall $1
	fi
}

IF_Handle()
{
    AP_IPADDR=$(nvram get lan_ipaddr)
    AP_NETMASK=$(nvram get lan_netmask)
      
    ####2.4G
    index=0
      while [ "$index" -le "$MSSID_num" ]     
              do
              if [ "$index" = "0" -o "$SSID_ACT" -gt "2" ]; then
              case "$SSID_ACT" in
                   1)      
                   iwpriv ath$index bintval 100
                   iwpriv ath$index dtim_period 2
                   ;;
                   2)      
                   iwpriv ath$index bintval 200
                   iwpriv ath$index dtim_period 2
                   ;;
                   3)      
                   iwpriv ath$index bintval 300
                   iwpriv ath$index dtim_period 2
                   ;;
                   4)      
                   iwpriv ath$index bintval 400
                   iwpriv ath$index dtim_period 2
                   ;;
                   5)      
                   iwpriv ath$index bintval 500
                   iwpriv ath$index dtim_period 2
                   ;;                  
              esac       
              fi 
              index=$(($index+1)) 
              done     

    if [ "$1" = "start" ]; then
        
        ####2.4G
        echo "IF start 2.4G:"
        sleep 2
        index=0
        while [ "$index" -le "$MSSID_num" ]
        do
            IF_IND=`NV_NAME $index`
            if [ "$MODE" != "repeater" ]; then
                  if [ "$(nvram get endis_wl_radio$IF_IND)" = "1" ]; then  
                        ifconfig ath$index up
                        brctl addif $BR ath$index                       
                        sleep 1    
                  fi       
            fi      
                 
            index=$(($index+1))
            done
            
    else
        echo "IF stop:"
        # 2.4G

        index=0
        while [ "$index" -lt "6" ]
        do
        		IF=ath$index
        		if [ "`ifconfig -a|grep $IF`" != "" ]; then
        				echo "removing $IF down"
        				ifconfig $IF down
        				brctl delif br0 $IF        
        				wlanconfig $IF destroy
        		fi		
        		index=$(($index+1))
        done
                      
    fi
}
##end of IF_Handle##

main()
{
    echo "$1: wlan.sh..."
   if [ "$1" = "start" ]; then
        
	#	if [ "$(nvram get dns_hijack)" = "1" -a "$(nvram get wps_status)" = "5" ]; then
	#		nvram set hijack_process=2	#take me to internet
	#	fi
		
        ####	2.4G	####
        RADIO=`nvram get endis_wl_radio`
        if [ "$(nvram get endis_wl_radio)" = "1" ]; then 
						#/sbin/ledcontrol -n wlan -s on
						#echo -n 2 > /proc/driver/load_wireless_led
						#echo -n 1 > /proc/driver/wirelessled
						#echo -n 1 > /proc/wireless_radio
            Ins_module
            nvram set wlan_busy=1
            Create_vap
            sleep 4

            index=0
            while [ "$index" -le "$MSSID_num" ]
            do
								IF_IND=`NV_NAME $index`
								
                if [ "$MODE" != "repeater" ] && [ "$(nvram get endis_wl_radio$IF_IND)" = "1" ]; then
                    Basic_setting $index bgn                         
                    Security $index bgn
                    ACL $index  bgn   
                    SSID_ACT=$(($SSID_ACT+1))                                  
                fi
                index=$(($index+1))
            done 

            #Guest_access
            Wds start
            IF_Handle start

			index_ath0=0
			
            sleep 3
			iwpriv ath$index_ath0 disablecoext "$(nvram get wl_disablecoext)"
			
            echo $sys_uptime > /tmp/WLAN_uptime
            DECAYPOWER=$(nvram get wl_txctrl_web)
            [ "$DECAYPOWER" = "0" ] || iwpriv wifi0 tpscale $DECAYPOWER
            nvram set wlan_busy=0
        else
            echo "Wireless 2.4G disabled"
            #echo -n 0 > /proc/wireless_radio
        fi
				
    else
        MODLIST=`lsmod | grep ath_hal`
        
##
## If the modules are already unloaded, we do not need to do anything
##
        if [ "$MODLIST" = "" ]; then
            echo "Modules already unloaded"
            return 
        fi
  
        KILL_APP hostapd
        KILL_APP wpa_supplicant
        KILL_APP wps_get_info.sh
        /etc/rc.d/wps_led.sh WPS_OVER                

        Wds stop
        IF_Handle stop 
        rm -rf $dir_hostapd
				sleep 2
        Rm_module

				#WLAN & WPS LED off
				#/sbin/ledcontrol -n wlan -s off
				#/sbin/ledcontrol -n wps -s off
				#echo -n 0 > /proc/driver/wirelessled
				#echo -n 0 > /proc/wireless_radio
   fi
   
   KILL_APP dni-discoverd
   dni-discoverd
}
##end of main##

case "$1" in 
"start")
    main start
		wl_2G_on=`ifconfig | grep -c wifi0`
		if [ "$wl_2G_on" != "1" ]; then
			main stop
		fi
    ;;  
"stop")
    main stop       
    ;;
"load_module")
    echo "wireless module test"
    Ins_module
    ;;
"restart")
    main stop
    main start    
		wl_2G_on=`ifconfig | grep -c wifi0`
		if [ "$wl_2G_on" != "1" ]; then
			main stop
		fi
    ;;
"wps_pbc")
    echo "*** WPS: WPS-PBC (Push Button)  ***" 
		#if [ "$($nvram get endis_wl_wps)" = "1" ] && [ "$($nvram get endis_wl_radio)" = "1" ]; then
		if [ "$($nvram get endis_wl_radio)" = "1" ]; then
			#WLAN & WPS LED power on
			#/sbin/ledcontrol -n wlan -s on
			#/sbin/ledcontrol -n wps -s on
			#echo -n 1 > /proc/driver/wirelessled
			
			BCAST="$(nvram get endis_ssid_broadcast)"
			if [ "$BCAST" = "0" ]; then
					iwpriv ath0 hide_ssid 0
					sleep 1
			fi			
	
			rm -f /tmp/wps_client
      $HOSTAPD_CLI -i ath0 wps_pbc
			if [ "$2" = "HW" ]; then
				wifi_pid="$($nvram get wifi_pid)"
				echo "pid = $wifi_pid"   
				if [ "$wifi_pid" != "" ]; then
					kill -9 $wifi_pid
				fi
				wifi_pid=$$  # get now wifi pid
				$nvram set wifi_pid=$wifi_pid                          
				set_wps_led ath0
				$nvram unset wifi_pid
			fi
		fi
    echo "*** RUN WPS-PBC Done!! ***"
    ;;
"wps_pin")
    echo "*** WPS: WPS-PIN (Enter PIN Number)  ***"  
		#WLAN & WPS LED power on
		#/sbin/ledcontrol -n wlan -s on
		#/sbin/ledcontrol -n wps -s on
		#echo -n 1 > /proc/driver/wirelessled
		
		BCAST="$(nvram get endis_ssid_broadcast)"
		if [ "$BCAST" = "0" ]; then
				iwpriv ath0 hide_ssid 0
				sleep 1
		fi	

    rm -f /tmp/wps_client
    enrollee_pin=`cat /tmp/wps_client_pin`
    echo "*** WPS: wps_pin $enrollee_pin ***"
    $HOSTAPD_CLI -i ath0 wps_pin any $enrollee_pin
    echo "*** RUN WPS-PIN Done!! ***"
    ;; 
"wps_quit")
    echo "*** WPS: WPS-Restart!! ***"
    WPS_QUIT=$( ps > /tmp/wps_quit; cat /tmp/wps_quit | grep hostapd | awk '{print $1}' )
    if [ $WPS_QUIT != "" ] ; then 
				#WPS LED power off
				#/sbin/ledcontrol -n wps -s off
        echo "*** KILL PID: $WPS_QUIT ***"
        kill -HUP $WPS_QUIT
        rm -f /tmp/wps_quit
    fi
    ;;
"sta")
    echo "*** sta vap started to connect ***"
    		Sta_config stop
    		Sta_config start
		;;      
*)
    echo "Warning! You must input ./wlan_ath.sh [start|stop|restart]."
esac
