#!/bin/sh
NVRAM=/usr/sbin/nvram

if [ "$IFACE_NUM" = "8" ]; then #EAST
	$NVRAM set wan_mulpppoe2_username="guest@flets"	
	$NVRAM set wan_mulpppoe2_passwd="guest"
fi
if [ "$IFACE_NUM" = "9" ]; then #WEST
	$NVRAM set wan_mulpppoe2_username="flets@flets"
    $NVRAM set wan_mulpppoe2_passwd="flets"
fi

kill -9 `cat /var/run/$IFNAME.pid`

