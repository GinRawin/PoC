#!/bin/sh 

NVRAM=/usr/sbin/nvram

${NVRAM} set netstar_status=3

${NVRAM} unset tmp_netstar
${NVRAM} unset tmp_netstar_by_user
${NVRAM} unset tmp_netstar_account                                
${NVRAM} unset tmp_netstar_default_cfg
${NVRAM} unset tmp_netstar_enabled
${NVRAM} unset multi_pppoe_policy_rul_tmp
${NVRAM} unset policy_rul_index

