#!/bin/sh

#[ -f /usr/local/sbin/upnp ] || exit 0
#[ -f /etc/resolv.conf ] || exit 0

RETVAL=0
prog="upnp"
PID_FILE="/var/run/upnp.pid"

lan_ifname=`nvram get lan_ifname`
wan_ifname=`nvram get wan_ifname`

start() {
	# Start daemons.
	local upnp_enable=`nvram get upnp_enable`
	#local upnp_advertime=`nvram get upnp_advertime`
	local upnp_advertime=`nvram get upnp_AdverTime`

	if [ "$upnp_enable" = "1" ]; then
		echo $"Starting $prog: "
		if [ "x$upnp_advertime" = "x" ]; then
			upnp_advertime="1800"			#default advertime=1800
			nvram set upnp_AdverTime=$upnp_advertime
			nvram commit
		fi
		${prog} -D -L $lan_ifname -W $lan_ifname -T $upnp_advertime
	fi
	RETVAL=$?
	echo
	return $RETVAL
}

stop() {
	# Stop daemons.
	echo $"Shutting down $prog: "
	#f [ -e ${PID_FILE} ]; then
	#kill `cat ${PID_FILE}`
	#rm -f ${PID_FILE}
	#i
	killall -9 upnp
	rm -f ${PID_FILE}
	RETVAL=$?
	echo
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

