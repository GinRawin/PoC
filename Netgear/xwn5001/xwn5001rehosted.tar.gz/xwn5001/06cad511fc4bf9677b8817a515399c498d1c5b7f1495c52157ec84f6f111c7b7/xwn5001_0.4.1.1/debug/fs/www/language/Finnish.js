//BRS_01_checkNet.html

var wiz_start_genie_re="Kyllä.";
var bh_config_wireless_setting="Langattomien asetusten määrittäminen";
var genie_wireless_set_info="NETGEAR genie on havainnut olemassa olevan langattoman verkon.";
var select_choice="Valitse haluamasi langattomat asetukset tälle laitteelle:";
var use_router_setting="Käytä samoja asetuksia nykyisessä langattomassa verkossani. Tämä on suositus.";
var use_manual_setting="Uuden langattoman-verkon muodostaminen: Ymmärrän, että langaton laite on liitettävä manuaalisesti tähän uuteen verkkoon.";
var SWP0011="Vahvistus:";
var SWP0012="Vahvista langattomat asetukset ja napsauta Seuraava-painiketta. Käytössäsi on tällä hetkellä langaton yhteys. Kun olet napsauttanut Seuraava-painiketta, langaton yhteys katkeaa. Muodosta yhteys uudelleen uusilla asetuksilla ja jatka asennusta.";
var range_ext="Laitteen uudet asetukset:";
var SWP005="Internet-yhteyttä ei tunnisteta.";
var network_checking="Tarkistetaan verkkoyhteyttä...";
var wireless_net_det="Olemassa oleva langaton verkko havaittu";
var quit="Lopeta";
var bh_try_again="Yritä uudelleen";
var no_device_det_1 ="NETGEAR genie ei saa haettua nykyisen langattoman verkon asetuksia.";
var no_device_det_2 ="Haluatko, että NETGEAR genie tarkistaa uudelleen?";
var wiz_start_manual="En. Haluan määrittää langattomat asetukset itse.";
var LPC028="Tarkista reitittimen Internet-yhteys.";
var sec_phr_g="Langattoman verkon salasana";

















var h_wlan="<body bgColor=#0099cc><P><font size=\"4\"><B>Langattomien asetusten ohje</B></font></P><P><B>HUOMAA:</B> Kayttokanava ja alue on maaritettava oikein, jotta maaraysten noudattaminen ja yhteensopivuus alueella olevien eri tuotteiden valilla voidaan varmistaa. <P><B>Laitteen sijoittaminen langattoman yhteyden optimoimiseksi</B><P>Langattoman yhteyden kanto- tai toiminta-alue voi vaihdella huomattavasti laitteen fyysisen sijainnin mukaan. Parhaat tulokset saat, kun sijoitat laitteen seuraavien ohjeiden mukaan:<UL><LI>Lahelle sen alueen keskipistetta, jossa tietokoneita kaytetaan.<LI>Jonnekin ylos, kuten korkealle hyllylle.<LI>Kauas mahdollisista hairiolahteista, kuten tietokoneista, mikroaaltouuneista ja langattomista puhelimista.<LI>Kauas suurista metallipinnoista. </LI></UL><P><B>Huomaa:</B> Huomautus: naiden ohjeiden noudattamatta jattaminen voi heikentaa jarjestelman suorituskykya merkittavasti tai tehda langattoman yhteyden muodostamisen laitteeseen mahdottomaksi.</P><HR><A name=network></A><P><B>Langattoman verkon</B></P><P>nimi (SSID)<P>(Wireless Network Name (SSID)) Anna jokin arvo, jossa on enintaan 32 aakkosnumeerista merkkia. Sama nimi (SSID) on maaritettava verkon kaikkiin langattomiin laitteisiin. Oletus-SSID-nimi on Netgear_EXT, mutta NETGEAR suosittelee, etta muutat verkon nimeksi (SSID) toisen arvon. Isoilla ja pienilla kirjaimilla L18on eri merkitys tassa arvossa. Esimerkiksi NETGEAR ei ole sama kuin NETGEAr.<P>Alue<P>(Region) Valitse avattavasta luettelosta alue, jolla olet. Tassa kentassa nakyy toiminta-alue, jota varten langaton liittyma on tarkoitettu. Laitteen kayttaminen jollakin muulla kuin tassa nakyvalla alueella saattaa olla laitonta. Jos oma maasi tai alueesi ei nay luettelossa, tarkista viranomaisilta tai NETGEARin verkkosivustosta, mita kanavia pitaisi kayttaa.<P>Kanava<P>(Channel) Tama kentta maarittaa kaytettavan kayttotaajuuden. Langattoman kanavan vaihtamisen ei pitaisi olla mahdollista, ellet huomaa hairioongelmia toisen lahella sijaitsevan tukiaseman kanssa.</P><P>Tila(Mode)</P> Valitse langaton tila, jota haluat kayttaa. Vaihtoehdot ovat:<UL><LI>Enintaan 54 Mbps (Up to 54 Mbps). Legacy-tila, jossa b- ja g-verkkojen enimmaisnopeus on 54.<LI>Enintaan 130 Mbps (Up to 130 Mbps). Naapuriystavallinen tila, jossa nopeus on oletusarvoisesti enintaan 130 Mbps, kun lahella on muita langattomia verkkoja.<LI>Enintaan 300 Mbps (Up to 300 Mbps). Suorituskykyinen tila, jossa langattoman verkon nopeus on enintaan 300 Mbps.</LI></UL><P>Oletusasetus on <b>Enintaan 145 Mbps</b>, joka sallii kaikki langattomat 11b- ja 11g- seka 11n-asemat. </P><HR><A name=security></A><p><b>Suojausvaihtoehdot</b></p><UL><LI>Ei mitaan - ei tietojen salausta<LI>WEP (Wired Equivalent Privacy), kayta tietojen 64- tai 128-bittista WEP-salausta<br><b>Huomautus:</b>  Wi-Fi Protected Setup -toiminto ei ole kaytossa, kun suojausasetus on WEP- ja WPA-PSK [TKIP] -todennus<LI>WPA-PSK [TKIP] - (Wi-Fi Protected Access -salaus ja esijaettu avain), kayta WPA-PSK-standardisalausta TKIP-salaustyypin kanssa<LI>WPA2-PSK [AES] - (Wi-Fi Protected Access 2 -salaus ja esijaettu avain), kayta WPA2-PSK-standardisalausta AES-salaustyypin kanssa<LI>WPA-PSK [TKIP] + WPA2-PSK [AES] - sallii tyoasemien kayttaa joko WPA-PSK (TKIP)- tai WPA2-PSK (AES) -standardia.</LI></UL><p>Parhaan suorituskyvyn saavuttamiseksi NETGEAR WN511B:lla tai muulla langattomalla sovittimella vahvassa suojausverkossa NETGEAR suosittelee, etta muutat XWN5001-verkon suojausasetukseksi WPA2-PSK.</p><HR><A name=wep></A><p><b>Salaus (WEP)  </b></p><P>Todennustapa <p>Tavallisesti voidaan kayttaa oletusarvoa Automaattinen. Jos se epaonnistuu, valitse sopiva arvo, Avoin jarjestelma - tai Jaettu avain. Tarkista kaytettava menetelma langattoman korttisi asiakirjoista.<p>Salauksen vahvuus <p>Valitse WEP-salauksen taso: <UL><LI>64-bittinen salaus (joskus kaytetaan nimitysta 40-bittinen) <LI>128-bittinen salaus </LI></UL><HR><A name=wepkey></A><p><b>Salausavain (WEP)</b></p><p>Jos WEP on kaytossa, voit ohjelmoida nelja tietojen salausavainta manuaalisesti tai automaattisesti. Naiden arvojen on oltava samat kaikissa verkossasi olevissa tietokoneissa ja tukiasemissa. <p>Automaattinen avaimen luominen (salasana) <p>Kirjoita jokin sana tai joukko tulostettavia merkkeja Salasana-kenttaan ja maarita sitten yksi tai useita WEP-avaimia valitsemalla Luo. Jos salauksen vahvuudeksi maaritetaan 64-bittinen, jokaiseen neljaan kenttaan taytetaan avainarvot automaattisesti. Jos salauksen vahvuudeksi maaritetaan 128-bittinen, vain valittuun WEP-avainkenttaan taytetaan avainarvot automaattisesti. <p>Manuaalinen syottotila <p>Valitse, mita naista neljasta avaimesta kaytetaan, ja syota verkkosi vastaavat WEP-avaintiedot valitun avaimen kenttaan. <p>Syota 64-bittiseen WEP-avaimeen 10 heksadesimaalista lukua (mika tahansa yhdistelma merkkeja 0 - 9, A - F). <p>Syota 128-bittiseen WEP-avaimeen 26 heksadesimaalista lukua (mika tahansa yhdistelma merkkeja 0 - 9, A - F). <p>Muista tallentaa valikon asetukset valitsemalla Kayta.</P><HR><A name=wpa-psk></A><p><b>Salaus (WPA-PSK)</b></p><p>Jos tama vaihtoehto on valittuna, sinun on kaytettava TKIP-salausta ja maaritettava WPA-salasana (verkkoavain). Kirjoita jokin sana tai joukko tulostettavia merkkeja Salasana-kenttaan. Salasanassa on oltava 8–63 ASCII-merkkia tai tasmalleen 64 heksadesimaalista lukua. Heksadesimaalisia lukuja ovat seuraavat merkit: <br>0, 1, 2, ..., 8, 9, A, B, C, D, E ja F. <p>Muista tallentaa asetukset napsauttamalla Kayta-painiketta. </p><HR><A name=wpa2-psk></A><p><b>Salaus (WPA2-PSK)</b></p><p>WPA2 on uudempi versio WPA:sta. Valitse tama vaihtoehto vain, jos kaikki langattomassa verkossasi olevat langattomat tyoasemat tukevat WPA2-standardia. Jos tama vaihtoehto on valittuna, sinun on kaytettava AES-salausta ja maaritettava WPA-salasana (verkkoavain). Kirjoita jokin sana tai joukko tulostettavia merkkeja Salasana-kenttaan. Salasanassa on oltava 8–63 ASCII-merkkia tai tasmalleen 64 heksadesimaalista lukua. Heksadesimaalisia lukuja ovat seuraavat merkit: <br>0, 1, 2, ..., 8, 9, A, B, C, D, E ja F. </p><HR><A name=wpa-psk+wpa2-psk></A><p><b>Salaus (WPA-PSK + WPA2-PSK)  </b></p><p>Tama vaihtoehto sallii tyoasemien kayttaa joko WPA-standardia (TKIP-salauksen kanssa; myos lahetyspaketeissa kaytetaan TKIP-salausta) tai WPA2-standardia (AES-salauksen kanssa). Jos tama vaihtoehto valitaan, salauksen on oltava TKIP + AES. WN511B:n kaltaiset tyoasemat on yhdistettava tahan laitteeseen WPA2-standardia (AES-salausta) kayttaen, jotta paras mahdollinen langaton suorituskyky voidaan saavuttaa. Langattoman verkon suurin nopeus on 802.11g sellaisissa tyoasemissa, jotka on yhdistetty WPA-PSK-standardilla (TKIP-salauksella). Kirjoita jokin sana tai joukko tulostettavia merkkeja Salasana-kenttaan. Salasanassa on oltava 8–63 ASCII-merkkia tai tasmalleen 64 heksadesimaalista lukua. Heksadesimaalisia lukuja ovat seuraavat merkit: <br>0, 1, 2, ..., 8, 9, A, B, C, D, E ja F. <HR><p><b>Muutosten tallentaminen tai peruuttaminen</b></p><p>Ota muutokset kayttoon napsauttamalla <b>Kayta</b>-painiketta. <br>Palauta entiset asetukset valitsemalla <b>Peruuta</b>. </p></body>";

var help_center="Ohjekeskus";
var help_show_hide="Näytä/piilota ohjekeskus";
var sec_wpa_mode="WPA-tila:";
var auto_mark="Automaattinen";
var guest_wire_iso="Ota käyttöön langaton erotus";
var adva_wlan_ssid_broadcast="Ota käyttöön SSID-tunnuksen lähetys";
var cancel_mark="Peruuta";
var apply_mark="Käytä";

var wlan_network_mark="Langaton verkko";
var wlan_mark_ssid="Nimi (SSID)";
var wlan_mark_reg="Alue";
var wlan_mark_chan="Kanava";
var wlan_mark_mode="Tila";
var wlan_mark_gb="b ja g";
var wlan_mark_go="vain g";
var wlan_mark_bo="vain b";
var wlan_mark_turbog="Automaattinen 108 Mbps";
var wlan_mode_54="Enintään 54 Mbps";
var wlan_mode_65="Enintään 65 Mbps";
var wlan_mode_130="Enintään 130 Mbps";
var wlan_mode_145="Enintään 145 Mbps";
var wlan_mode_150="Enintään 150 Mbps";
var wlan_mode_300="Enintään 300 Mbps";
var wlan_wlacl="Langattoman kortin käyttöluettelo";
var wir_wning = "Wi-Fi Alliancen 40 MHz:n ja 20 MHz:n verkkojen samanaikaista käyttöä koskevien suositusten mukaisesti tuotteesi palvelukanavan palvelutiheys voi laskea 20 MHz:iin, vaikka valitsisit Enintään %s Mbps -tilan. Tämä vastaa tyypillisesti %s Mbps:n suorituskykyä.";

var sec_type="Suojausvaihtoehdot";
var sec_off="Ei mitään";
var sec_wep="WEP";
var sec_wpa="WPA-PSK (TKIP)";
var sec_wpa2="WPA2-PSK (AES)";
var sec_wpas="WPA-PSK (TKIP) + WPA2-PSK (AES)";
var sec_pr_wpa="Suojausvaihtoehdot (WPA-PSK)";
var sec_pr_wpa2="Suojausvaihtoehdot (WPA2-PSK)";
var sec_pr_wpas="Suojausvaihtoehdot (WPA-PSK + WPA2-PSK)";
var sec_auth="Todennustapa";
var sec_auto="Automaattinen";
var sec_share="Jaettu avain";
var sec_enc="Salauksen vahvuus";
var sec_64="64-bittinen";
var sec_128="128-bittinen";
var sec_enc_head="Salaus (WEP)";
var sec_key="Salausavain (WEP)";
var sec_key1="Avain 1";
var sec_key2="Avain 2";
var sec_key3="Avain 3";
var sec_key4="Avain 4";
var sec_phr="Salasana";
var sec_863_or_64h="(8–63 merkkiä tai 64 heksadesimaalilukua)";
var wep_or_wps="WEP-suojaus, jossa käytetään automaattista jaetun avaimen todennusta, ei toimi WPS:n kanssa. WPS ei ole käytettävissä. Haluatko jatkaa?";
var wep_just_one_ssid="WEP-suojausta voidaan tukea vain yhdelle SSID-nimelle yhtä kaistaa kohden";


var bh_internet_checking="Tarkistetaan Internet-yhteyttä. Odota...";

var SB011="Jos käytössä on jo kaikkien työasemalaitteiden käyttämät langattoman verkon asetukset, voit päivittää esimääritetyt asetukset olemassa oleviin <font id=\"a\" onclick=\"click_here();\">napsauttamalla tätä</font>.";

//BRS_02_genieHelp.html
var bh_config_net_connection="Määritetään Internet-yhteyttä";

var bh_connection_further_action="Et ole vielä muodostanut yhteyttä Internetiin.";

var bh_want_genie_help="Haluatko käyttää apuna NETGEAR Genie -määritystä?";

var bh_yes_mark="Kyllä";

var bh_no_genie_help="Ei, haluan määrittää Internet-yhteyden itse.";

var bh_no_genie_help_confirm="Internet-yhteyden määrittäminen vaatii asiantuntemusta. Oletko varma?"

var bh_have_saved_copy="Olen tallentanut reitittimen asetukset tiedostoon ja haluan palauttaa ne reitittimeen."

var bh_next_mark="Seuraava";


//BRS_03A_detcInetType.html
var bh_detecting_connection="Tunnistetaan Internet-yhteyttä";

var bh_plz_wait_process="Tämä voi kestää pari minuuttia. Odota...";


//BRS_03A_A_noWan.html
var bh_no_cable="Reitittimen Internet-porttiin ei ole liitetty Ethernet-kaapelia";

var bh_wizard_setup_nowan_check="Varmista, että kaapeli on liitetty kunnolla sekä laajakaistamodeemin porttiin että reitittimen Internet-porttiin.";

var bh_click_try_again="Kun olet tarkistanut Ethernet-kaapelin, valitse <b>Yritä uudestaan</b>.";

var bh_try_again="Yritä uudelleen";


//BRS_03A_B_pppoe.html
var bh_pppoe_connection="PPPoE DSL -Internet-yhteys on tunnistettu";

var bh_enter_info_below="Määritä alla tarvittavat tiedot.";

var bh_pppoe_login_name="Käyttäjätunnus";
var bh_ddns_passwd="Salasana";


//BRS_03A_B_pppoe_reenter.html
var bh_ISP_namePasswd_error="Internet-palveluntarjoajalta saatu käyttäjätunnus tai salasana on virheellinen";

var bh_enter_info_again="Määritä tarvittavat tiedot uudelleen.";


//BRS_03A_C_pptp.html
var bh_pptp_login_name="Käyttäjätunnus";

var bh_pptp_connection="PPTP-Internet-yhteys on tunnistettu";

var bh_basic_pptp_servip="Palvelimen osoite";

var bh_sta_routes_gtwip="Yhdyskäytävän IP-osoite";

var bh_basic_pptp_connection_id="Yhteyden tunnus/nimi";

//BRS_03A_F_l2tp.html
var bh_l2tp_connection="L2TP Internet Connection Detected";

//BRS_03A_D_bigpond.html
var bh_bpa_connection="BigPond-Internet-yhteys on tunnistettu"; 

var bh_basic_bpa_auth_serv="Todennuspalvelin";

var bh_basic_pppoe_idle="Aikakatkaisu (minuutteina)";


//BRS_03A_E_IP_problem_staticIP.html
var bh_no_internet_ip="Ongelma Internet-yhteyden tunnistamisessa";

var bh_no_internet_ip2="Ongelma Internet-yhteyden tunnistamisessa - IP-osoite";

var bh_no_internet_ip3="Ongelma Internet-yhteyden tunnistamisessa - MAC-osoite";

var bh_if_have_static_ip="Onko Internet-palveluntarjoaja määrittänyt sinulle kiinteän (staattisen) IP-osoitteen? Tämä on <b>erittäin harvinaista</b>. ";

var bh_yes_correct="Kyllä. Internet-palveluntarjoaja määritti minulle kiinteän (staattisen) IP-osoitteen.";

var bh_not_have_static_ip="Ei, en ole saanut kiinteää (staattista) IP-osoitetta palveluntarjoajalta.";

var bh_do_not_know="En tiedä. ";

var bh_select_option="Valitse vaihtoehto ja jatka valitsemalla <b>Seuraava</b>.";

var bh_select_an_option="Valitse ensin vaihtoehto.";


//BRS_03A_E_IP_problem_staticIP_A_inputIP.html
var bh_fix_ip_setting="Kiinteät Internet-IP-asetukset";

var bh_enter_ip_setting="Anna Internet-palveluntarjoajalta saadut kiinteät IP-asetukset ja jatka valitsemalla <b>Seuraava</b>.";

var bh_info_mark_ip="IP-osoite";
//var bh_info_mark_ip="Oma IP-osoite";
var bh_info_mark_mask="Aliverkon peite";

var bh_constatus_defgtw="Oletusyhdyskäytävä";

var bh_preferred_dns="Ensisijainen DNS-palvelin";

var bh_alternate_dns="Vaihtoehtoinen DNS-palvelin";

var bh_basic_int_third_dns="Kolmas DNS";

//BRS_03A_E_IP_problem.html
var bh_genie_cannot_find_ip="Tämä johtuu todennäköisesti jostakin seuraavista syistä:";
var bh_genie_cannot_find_ip_reason1="1.  Modeemin virtaa ei katkaistu ja kytketty uudelleen kaapeleiden liittämisen jälkeen.";
var bh_genie_cannot_find_ip_reason1_desc="Ratkaise ongelma katkaisemalla modeemin virta ja kytkemällä se uudelleen. Jos modeemissa on varaparisto, se pitää ehkä poistaa ja asettaa takaisin, jotta modeemin virta katkeaa. Kun olet katkaissut modeemista virran ja kytkenyt sen uudelleen, odota kaksi minuuttia, jotta modeemi ehtii käynnistyä kunnolla."; 
var bh_genie_cannot_find_ip_reason2="2.  Keltaista Ethernet-kaapelia ei ole liitetty kunnolla tai se on kiinnitetty väärään paikkaan.";
var bh_genie_cannot_find_ip_reason2_desc="Ratkaise ongelma varmistamalla, että keltainen Ethernet-kaapeli on liitetty kunnolla sekä laajakaistamodeemin porttiin että reitittimen Internet-porttiin.";

var bh_select_no_IP_option="Valitse yksi seuraavista vaihtoehdoista ja jatka valitsemalla <b>Seuraava</b>:";
var bh_select_no_IP_option1="Katkaisin modeemista virran, kytkin sen uudelleen ja odotin kaksi minuuttia.";
var bh_select_no_IP_option2="Korjasin Ethernet-kaapelin ongelman.";
var bh_select_no_IP_option3="Ei mikään näistä.";


//BRS_03A_E_IP_problem_staticIP_B_macClone.html
var bh_use_pc_mac="Jos olet aikaisemmin muodostanut Internet-yhteyden tietokoneella tai toisella reitittimellä, NETGEAR Genie voi käyttää tuolloin toiminutta MAC-osoitetta.";

var bh_mac_in_product_label="MAC-osoite on yksilöllinen numero.  Voit tarkistaa tietokoneen tai reitittimen MAC-osoitteen laitteen tuotetarrasta.";

var bh_enter_mac="Kirjoita MAC-osoite tähän.";

var bh_mac_format="(muodossa AABBCCDDEEFF)";


//BRS_03B_haveBackupFile.html
var bh_settings_restoration="Reitittimen asetusten palauttaminen";

var bh_browser_file="Etsi aiemmin tallentamasi reitittimen asetusten varmuuskopiotiedosto selaamalla, ja jatka valitsemalla <b>Seuraava</b>.";

var bh_back_mark="Edellinen";


//BRS_03B_haveBackupFile_fileRestore.html
var bh_settings_restoring="Palautetaan reitittimen asetukset"; 

var bh_plz_waite_restore="Tämä voi kestää muutaman minuutin. Odota.";


//BRS_04_applySettings.html
var bh_apply_connection="Internet-yhteysasetusten käyttäminen";

var bh_plz_waite_apply_connection="Tämä voi kestää pari minuuttia. Odota...";


//BRS_05_networkIssue.html
var bh_netword_issue="Ongelma verkkoyhteydessä";

var bh_cannot_connect_internet="Reititin ei voi muodostaa verkkoyhteyttä käyttämällä nykyisiä asetuksia.";

var bh_plz_reveiw_items="Tarkista seuraavat seikat:";

var bh_cable_connection="- Varmista, että kaapelit on liitetty oikein. Katso lisätietoja reitittimen asennusoppaasta.";

var bh_modem_power_properly="- Varmista, että laajakaistamodeemin virta on katkaistu ja kytketty uudelleen oikein. Jos modeemissa on varaparisto, poista ja aseta se takaisin paikalleen, jotta modeemin virta katkeaa ja kytkeytyy uudelleen.";

var bh_try_again_or_manual_config="Haluatko yrittää uudelleen NETGEAR Genie -määritystä?";

var bh_I_want_manual_config="En. Haluan määrittää Internet-yhteyden itse."; 

var bh_manual_config_connection="Haluan määrittää Internet-yhteyden itse";


//BRS_success.html
var bh_congratulations="Onnittelut!";

var bh_connect_success_1="Olet muodostanut langattoman Internet-yhteyden.";

var bh_connect_success_2="Tälle reitittimelle on määritetty valmiiksi seuraava yksilöllinen langattoman verkon nimi (SSID) ja ";

var bh_network_key="verkkoavain (salasana)";

var bh_rollover_help_text="Reitittimeen on määritetty valmiiksi WPA2-PSK-salaus langattoman yhteyden suojaamiseksi luvattomilta käyttäjiltä. Yhteyden muodostaminen langattomaan verkkoon vaatii verkkoavaimen (salasanan). Valmiiksi määritetyt asetukset ovat yksilölliset tälle laitteelle sarjanumeron tapaan.  Halutessasi voit muuttaa asetuksia myöhemmin Langattomat asetukset -näytössä reitittimen Web-käyttöliittymässä. ";

var bh_success_no_wireless_security_1 = "Langattoman verkon suojaus ei ole käytössä tässä reitittimessä. NETGEAR suosittelee painokkaasti ";
var bh_success_no_wireless_security_2 = "napsauta tätä";
var bh_success_no_wireless_security_3 =  " langattoman verkon suojaamista.";

var bh_wirless_name="Langattoman verkon nimi (SSID)"

var bh_wireless="Langaton";

var bh_wpa_wpa2_passpharse="Verkkoavain (salasana)"; 

var bh_save_settings="Save router settings";

var bh_print_this="Tulosta tämä";


var bh_take_to_internet="Käytä Internet-yhteyttä";

var bh_plz_wait_moment="Odota hetki...";

//the string for not_support_print is temporary.
var bh_not_support_print="Tietokone ei tue tulostinta.";
//already exist
var bh_login_name_null="Käyttäjätunnus ei voi olla tyhjä.";
var bh_password_error="Virheellinen salasana.";
var bh_idle_time_null="Määritä aikakatkaisuaika.\n";
var bh_invalid_idle_time="Virheellinen aikakatkaisuaika. Anna oikea numero.\n";
var bh_invalid_myip="Virheellinen IP-osoite. Anna se uudelleen tai jätä se tyhjäksi.";
var bh_invalid_gateway="Virheellinen yhdyskäytävän IP-osoite. Anna se uudelleen.";
var bh_bpa_invalid_serv_name="Virheellinen todennuspalvelimen IP-osoite.";
var bh_invalid_servip_length="Merkinnöissä voi olla enintään 63 merkkiä.\n";
var bh_invalid_ip="Virheellinen IP-osoite. Anna se uudelleen.";
var bh_invalid_mask="Virheellinen aliverkon peite. Anna se uudelleen.\n";
var bh_same_subnet_ip_gtw="IP-osoitteen ja yhdyskäytävän IP-osoitteen on oltava samassa aliverkossa.\n";
var bh_same_lan_wan_subnet="Lähiverkon IP-osoite ja laajaverkon IP-osoite eivät voi olla samassa aliverkossa.\n";
var bh_filename_null="Tiedostonimi ei voi olla tyhjä.";
var bh_not_correct_file="Määritä oikea tiedosto. Tiedostomuoto on *.";
var bh_ask_for_restore="Varoitus! \nAsetusten palauttaminen määritystiedostosta poistaa kaikki nykyiset asetukset. \nHaluatko varmasti tehdä tämän?";
var bh_invalid_primary_dns="Virheellinen ensisijainen DNS-osoite. Anna se uudelleen.\n";
var bh_invalid_second_dns="Virheellinen toissijainen DNS-osoite. Anna se uudelleen.\n";
var hb_invalid_third_dns="Invalid third DNS address. Please enter it again.\n";
var bh_dns_must_specified="DNS-osoite on määritettävä.";
var bh_invalid_mac="Virheellinen MAC-osoite.";
var bh_failure_head="Epäonnistui";
var bh_few_second="Tämä näyttö palautuu automaattisesti edelliseen näyttöön muutaman sekunnin kuluttua...";

var bh_important="Tärkeä päivitys";
var bh_wanlan_conflict_info="Jotta reitittimesi IP-osoite ei ole ristiriidassa Internet-palveluntarjoajan määritysten kanssa, IP-osoitteeksi on vaihdettu ";
var bh_continue_mark="Jatka";

var wlan_mark="Langattomat asetukset";
var wlan_mark_ssid="Nimi (SSID)";
var sec_type="Suojausvaihtoehdot";
var sec_off="Ei mitään";
var sec_wep="WEP";
var sec_wpa="WPA-PSK (TKIP)";
var sec_wpa2="WPA2-PSK (AES)";
var sec_wpas="WPA-PSK (TKIP) + WPA2-PSK (AES)";
var sec_phr="Salasana";

//readySHARE remote strings
var remote_share_head="ReadySHARE Cloud"

var ready_share_info1="ReadySHARE Cloud -toiminnon avulla voidaan käyttää reitittimen USB-porttiin liitettyä USB-tallennuslaitetta Internetin kautta."
var how_setup_ready_share="ReadySHARE Cloudn käyttöönotto"
var ready_share_step1="Vaihe 1: Tarvitset ReadySHARE Cloud -tilin. Jos sinulla ei ole tiliä, siirry tilin luontiin <a class='linktype' target='_blank' href='https://readyshare.netgear.com/site/index.jsp?pid=4&src=device'>napsauttamalla tätä</a>."
var ready_share_step2="Vaihe 2: rekisteröi tällä sivulla reitittimesi ja siihen liitetty USB-laite käyttäjätilillesi kirjoittamalla ReadySHARE Cloud -käyttäjätunnuksesi ja salasanasi."
var ready_share_step3="Vaihe 3: Kirjaudu uudelleen sisään sivustoon <a class='linktype' target='_blank' href='http://readyshare.netgear.com/'>http://readyshare.netgear.com/</a>. Sivulla pitäisi näkyä reitittimeen liitetty USB-laite."
var ready_share_step4="Vaihe 4: Ensimmäisellä käyttökerralla sinua pyydetään lataamaan Windows-sovellus, jolla muodostetaan suojattu yhteys tietokoneesta reitittimen USB-laitteeseen. Kun olet kirjautunut sovellukseen, voit käyttää USB-laitetta mistä tahansa."
var ready_share_set_note="<b>Huomautus:</b> ilman tätä sovellusta voit selata USB-laitteen sisältöä, mutta et voi avata tai muokata tiedostoja."
var ready_share_start="Aloita nyt ja ota ReadySHARE Cloud käyttöön"
var ready_share_get_account="Jos sinulla ei ole ReadySHARE Cloud -tiliä, hanki se <a class='linktype' target='_blank' href='https://readyshare.netgear.com/site/index.jsp?pid=4&src=device'>napsauttamalla tätä</a>"
var username="Käyttäjätunnus"
var key_passphrase="Salasana"
var register="Rekisteröi"
var register_note="<b>Huomautus:</b> Internet-yhteyttä ei katkaista, ennen kuin rekisteröinti poistetaan."
var help_center="Ohjekeskus"
var help_show_hide="Näytä/piilota ohjekeskus"

var resister_user="ReadySHARE Cloud on rekisteröity käyttäjälle"
var access_storage_method="Noudattamalla vaiheiden 2 - 4 ohjeita voit käyttää tallennustilaa mistä tahansa."
var unregister_info="Valitse <B>Poista rekisteröinti</B>, jos haluat rekisteröidä ReadySHARE Cloud -palvelun toiselle käyttäjälle."
var unregister="Poista rekisteröinti"

var result_register_ok="Rekisteröinti onnistui"
var result_register_fail="Rekisteröinti epäonnistui"
var result_unreg_ok="Rekisteröinnin poisto onnistui"
var result_unreg_fail="Rekisteröinnin poisto epäonnistui"


//for wireless check string
var wps_in_progress="WPS-prosessi on käynnissä. Ota muutokset käyttöön myöhemmin."
var ssid_null="SSID ei voi olla tyhjä."
var ssid_not_allowed_same="SSID toistuu. Määritä jokin toinen SSID."
var ssid_not_allowed="Merkkiä ei saa käyttää SSID-tunnuksessa"
var SWSW11="WPS vaatii toimiakseen SSID-lähetyksen. Jos teet tämän muutoksen, WPS ei ole käytettävissä. Haluatko jatkaa?"
var SWSW12="Oletko varma, ettet halua verkkoon langatonta suojausta? Tätä asetusta käytetään tavallisesti julkisessa käytössä olevien langattomien tukiasemien kohdalla. Haluatko jatkaa?"
var SWSW02="WEP- tai WPA-PSK [TKIP] -suojaustodennus ei toimi WPS:n kanssa. WPS-määritys ei ole käytettävissä. Haluatko jatkaa?"
var wds_auto_channel="Langatonta toistotoimintoa ei voi käyttää automaattisen kanavan kanssa.\nMuuta kanava-asetuksia, ennen kuin otat käyttöön langattoman toistotoiminnon. "
var notallowpassp="Merkkiä ei saa käyttää salasanassa"
var guest_tkip_300_150="Vierasverkon WPA-PSK [TKIP] toimii AINOASTAAN enintään 54 Mbps:n taajuudella (Legacy G -tilassa), ei N-taajuudella."
var guest_tkip_aes_300_150="NETGEAR suosittelee käyttämään vierasverkossa suojausasetusta WPA2-PSK [AES], jotta voit hyödyntää N-taajuuden täyttä tukea."
var wlan_tkip_aes_300_150="TÄRKEÄÄ\nWPA-PSK [TKIP] voi toimia \"enintään 54Mbps:n taajuudella\", ei N-taajuudella.\nNETGEAR suosittelee käyttämään suojausasetusta WPA2-PSK [AES], jotta voit hyödyntää N-taajuuden täyttä tukea."
var notSupportWLA="Israelissa ja Lähi-idässä ei tueta verkkotyyppiä 802,11a. Jos valitset tämän, langaton a/n suljetaan. Jatketaanko?"
var passphrase_short8="Liian lyhyt salasana. Salasanan on oltava vähintään 8 merkkiä pitkä."
var passphrase_long63="Salasana on liian pitkä. Enimmäispituus on 63 merkkiä."



