#
# This script is called when WAN interfaces(not default one) gain the IP.
#
# When default WAN interface gain the IP, it would set nvram action=3 and
# service scripts will be called by monitor.sh. Other interfaces would not 
# set action=3, but some scripts still need to be call. So, This file 
# collects(or call) those scripts.
#
. /etc/rc.d/tools.sh

# Add nat rules
echo 0 > /proc/sys/net/ipv4/ip_forward
#iptables -F POSTROUTING -t nat

#echo "start add multi-nat " > /tmp/aaron-nat
defif=`nvram get wan_default_iface`

#if [ "`nvram get wan${defif}_ipaddr`" = "" ]; then
#	exit 0
#fi
for i in 1 2; do
	#if [ "$i" = "$defif" ]; then
	#	continue
	#fi
	if [ "`nvram get wan_mulpppoe${i}_username`" = "" ]; then
		continue
	fi
	wan_ipaddr=`nvram get wan$(($i-1))_ipaddr`
   tmp_ifname=`nvram get wan$(($i-1))_ifname`
	if [ "$wan_ipaddr" != "" ]; then
        	ifname=`echo $tmp_ifname | awk -F: '{print $1}'`
	      if [ "$ifname" != "$tmp_ifname" ]; then
            wan_mask=`nvram get wan$(($i-1))_netmask`
            lmasklen=`print_masklen $wan_mask`
            lsubnet=`print_subnet $wan_ipaddr $wan_mask`
            iptables -t nat -A POSTROUTING -o $ifname -j SNATP2P --to-source $wan_ipaddr
         else
            iptables -t nat -A POSTROUTING -o $ifname -j SNATP2P --to-source $wan_ipaddr
         fi
	fi
done

#tmp_ifname=`nvram get wan$(($defif-1))_ifname`
#ifname=`echo $tmp_ifname | awk -F: '{print $1}'`
#wan_ipaddr=`nvram get wan$(($defif-1))_ipaddr`
#iptables -t nat -A POSTROUTING -o $ifname -j SNATP2P --to-source $wan_ipaddr

echo 1 > /proc/sys/net/ipv4/ip_forward




