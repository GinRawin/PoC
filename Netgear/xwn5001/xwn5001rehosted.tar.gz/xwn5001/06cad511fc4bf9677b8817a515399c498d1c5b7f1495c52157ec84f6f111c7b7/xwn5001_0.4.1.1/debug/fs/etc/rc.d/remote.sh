#!/bin/sh
# this script is used to control management control list function

#[ -f /bin/iptables ] || exit 0

. /etc/rc.d/tools.sh

accept="ACCEPT"
log="LOG"
drop="DROP"
reject="REJECT"

RETVAL=0

iptables="iptables"
NVRAM="/usr/sbin/nvram"
LAN_IPADDR=`nvram get lan_ipaddr`
LAN_SUBNET=`nvram get lan_netmask`
masklen=`print_masklen $LAN_SUBNET`
subnet=`print_subnet $LAN_IPADDR $LAN_SUBNET`
wan_ip=`nvram get wan0_ipaddr`
mark_flag=3
accesslog_enable=`nvram get LogAccessEnable`

check_dual_interafce()
{
	if [ "$1" = "add" ];then
		OP="-A"
	else
		OP="-D"
	fi
	if [ "`$NVRAM get wan_proto`" = "pptp" ]; then
		if [ "`$NVRAM get dy_pptp`" = "1" ]; then
			dual_ip=`$NVRAM get wan_dhcp_ipaddr`
		else
			dual_ip=`$NVRAM get wan_pptp_local_ip`
		fi
	fi
	if [ "`$NVRAM get wan_proto`" = "pppoe" ]; then
		if [ "`$NVRAM get wan_pppoe_wan_assign`" = "1" ] && [ "`$NVRAM get wan_pppoe_netmask`" != "0.0.0.0" ]; then
			dual_ip=`$NVRAM get wan_pppoe_ip`
		fi
	fi
	if [ "$dual_ip" = "" ];then return;fi

	if [ "$2" = "" ]; then
		$iptables $OP local_server -m mark --mark $mark_flag -d $dual_ip -p tcp --dport 80 -j ACCEPT
	else
		if echo $2|grep \- >/dev/null;then
			$iptables $OP local_server -m mark --mark $mark_flag -d $dual_ip -m iprange --src-range $2 -p tcp --dport 80 -j ACCEPT
		else
			$iptables $OP local_server -m mark --mark $mark_flag -d $dual_ip -s $2 -p tcp --dport 80 -j ACCEPT
		fi
	fi
}

start() {
	local remote_endis=`nvram get remote_endis`
	local remote_access=`nvram get remote_access`
	local remote_iplist=`nvram get remote_iplist`
	local remote_port=`nvram get remote_port`
	local wan_ifname=`nvram get wan_ifname`


	if [ "$remote_endis" = "1" ]; then
		#$iptables -t nat -A nat_local_server -p tcp --dport $remote_port -j REDIRECT --to-ports 80	
		if [ "$remote_access" = "2" ]; then	# every one
			#The rule in mangle table mark packet which will be REDIRECT. 
			#This can prevent remote host access DUT by port 80 directly.
			$iptables -t mangle -A PREROUTING -p tcp --dport $remote_port -j MARK --set-mark $mark_flag 
			$iptables -t nat -A nat_local_server -p tcp --dport $remote_port -j REDIRECT --to-ports 80
			if [ "$accesslog_enable" = "1" ]; then
				$iptables -A local_server -m mark --mark $mark_flag -d $wan_ip -p tcp --dport 80 -m log --log-prefix "AUTH Permit configuration from wired Internet" -j ACCEPT
			else
				$iptables -A local_server -m mark --mark $mark_flag -d $wan_ip -p tcp --dport 80 -j ACCEPT
			fi
			check_dual_interafce add
		else
			if [ "$remote_access" = "0" ]; then	# only this ip
				$iptables -t mangle -A PREROUTING -s $remote_iplist -p tcp --dport $remote_port -j MARK --set-mark $mark_flag
				$iptables -t nat -A nat_local_server -s $remote_iplist -p tcp --dport $remote_port -j REDIRECT --to-ports 80

				if [ "$accesslog_enable" = "1" ]; then
					$iptables -A local_server -m mark --mark $mark_flag -d $wan_ip -s $remote_iplist -p tcp --dport 80 -m log --log-prefix "AUTH Permit configuration from wired Internet" -j ACCEPT
				else
					$iptables -A local_server -m mark --mark $mark_flag -d $wan_ip -s $remote_iplist -p tcp --dport 80 -j ACCEPT
				fi
			else
				$iptables -t mangle -A PREROUTING -m iprange --src-range $remote_iplist -p tcp --dport $remote_port -j MARK --set-mark $mark_flag
				$iptables -t nat -A nat_local_server -m iprange --src-range $remote_iplist -p tcp --dport $remote_port -j REDIRECT --to-ports 80	
				$iptables -A local_server -m mark --mark $mark_flag -d $wan_ip -m iprange --src-range $remote_iplist -p tcp --dport 80 -j ACCEPT
			fi
			check_dual_interafce add $remote_iplist
		fi
	fi	
	#$iptables -t nat -A nat_local_server -p tcp --dport 80 -s $subnet/$masklen -j DROP	
}

stop() {

	local remote_endis=`nvram get remote_endis`
	local remote_access=`nvram get remote_access`
	local remote_iplist=`nvram get remote_iplist`
	local remote_port=`nvram get remote_port`
	local wan_ifname=`nvram get wan_ifname`

		#$iptables -t nat -D nat_local_server -p tcp --dport $remote_port -j REDIRECT --to-ports 80	
		if [ "$remote_access" = "2" ]; then	# every one 
			$iptables -t mangle -D PREROUTING -p tcp --dport $remote_port -j MARK --set-mark $mark_flag 2> /dev/null 
			$iptables -t nat -D nat_local_server -p tcp --dport $remote_port -j REDIRECT --to-ports 80 2> /dev/null	
			$iptables -D local_server -m mark --mark $mark_flag -d $wan_ip -p tcp --dport 80 -j ACCEPT 2> /dev/null
			$iptables -D local_server -m mark --mark $mark_flag -d $wan_ip -p tcp --dport 80 -m log --log-prefix "AUTH Permit configuration from wired Internet" -j ACCEPT 2> /dev/null
			check_dual_interafce del
		else
			if [ "$remote_access" = "0" ]; then	# only this ip
				$iptables -t mangle -A PREROUTING -s $remote_iplist -p tcp --dport $remote_port -j MARK --set-mark $mark_flag 2> /dev/null
				$iptables -t nat -D nat_local_server -s $remote_iplist -p tcp --dport $remote_port -j REDIRECT --to-ports 80 2> /dev/null	
				$iptables -D local_server -m mark --mark $mark_flag -d $wan_ip -s $remote_iplist -p tcp --dport 80 -j ACCEPT 2> /dev/null

				$iptables -D local_server -m mark --mark $mark_flag -d $wan_ip -s $remote_iplist -p tcp --dport 80 -m log --log-prefix "AUTH Permit configuration from wired Internet" -j ACCEPT 2> /dev/null
			else
				$iptables -t mangle -A PREROUTING -m iprange --src-range $remote_iplist -p tcp --dport $remote_port -j MARK --set-mark $mark_flag
				$iptables -t nat -D nat_local_server -m iprange --src-range $remote_iplist -p tcp --dport $remote_port -j REDIRECT --to-ports 80	
				iptables -D local_server -m mark --mark $mark_flag -d $wan_ip -m iprange --src-range $remote_iplist -p tcp --dport 80 -j ACCEPT
			fi
			check_dual_interafce del $remote_iplist
		fi
	#$iptables -t nat -D nat_local_server -p tcp --dport 80 -s $subnet/$masklen -j DROP	
	
}


case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL
