#!/bin/sh


Get_info()
{
		if [ "$1" = "start" ]; then
				/etc/rc.d/wps_led.sh WPS_CLIENT &
				wlanconfig ath5 create wlandev wifi0 wlanmode sta
				iwpriv ath5 wps 1
				iwpriv ath5 vap_doth 0
				iwpriv ath5 extap 1
				brctl addif br0 ath5
				
				cp /etc/ath/WSC_sta.conf /tmp/sta.conf
				/sbin/wpa_supplicant -d -i ath5 -b br0 -c /tmp/sta.conf &
				sleep 2
				wpa_cli wps_pbc
				i=1
				while [ "$i" -lt "4" ]
				do 
						echo "## waiting 40s($i) ..." > /dev/console
						sleep 40
						RES=`cat /tmp/sta.conf | grep network=`
						if [ "$RES" != "" ]; then
							nvram set hijack_process=3
							nvram set dns_hijack=0
							echo -n 5 > /proc/driver/wps_stat
							/etc/rc.d/wps_led.sh WPS_OVER &
							flash -wl /tmp/sta.conf
							break
						else								
								i=$(($i+1))	
						fi			
				done

		else
				brctl delif br0 ath5
				killall wpa_supplicant
				wlanconfig ath5 destroy
		fi
		
}
##end of Get_info##

if [ "$(nvram get endis_wl_radio)" = "1" ]; then
	#ifconfig ath0 down
	#killall hostapd
	#wlanconfig ath0 destroy    
	#sleep 1
	Get_info stop
	Get_info start
	Get_info stop

	if [ "$i" = "4" ]; then
		/etc/rc.d/wps_led.sh WPS_FAIL &
		sleep 6
		/usr/sbin/soapclient &
	else
		nvram set wps_status=5
		/etc/rc.d/wlan_ath.sh restart
	fi
else
	echo "skip WPS and do soapclient ...." > /dev/console
	/usr/sbin/soapclient &
fi
