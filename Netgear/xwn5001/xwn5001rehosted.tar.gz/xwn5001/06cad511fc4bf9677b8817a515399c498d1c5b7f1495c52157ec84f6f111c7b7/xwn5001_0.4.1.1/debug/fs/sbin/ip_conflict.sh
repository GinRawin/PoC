#!/bin/sh
nvram="/usr/sbin/nvram"

lan_ipaddr=$($nvram get lan_ipaddr)

echo "running ip_conflict.sh"

set_lan() #$1 is is the first 3 field of lan ip
{	
	echo -n "1" > /tmp/wan_lan_ip_conflict	
	#$nvram set wan_lan_ip_conflict=1
	
	ip=`$nvram get lan_ipaddr | sed 's/\([0-9]*.[0-9]*.[0-9]*\).*/\1/'`	

   # for port forward web setting change
	for file in `nvram show | grep forwarding | cut -d "=" -f1`
	do
      new_info=`nvram get $file | sed "s/[0-9]*\.[0-9]*\.[0-9]*/$ip/"`
		$nvram set $file="$new_info"
	done
    
	for file in `nvram show | grep reservation | cut -d "=" -f1`   
	do
		new_info=`nvram get $file | sed "s/[0-9]*\.[0-9]*\.[0-9]*/$ip/"`
		$nvram set $file="$new_info"
	done
	for file in `nvram show | grep block_services | cut -d "=" -f1` 
	do
		new_info=`nvram get $file | sed "s/[0-9]*\.[0-9]*\.[0-9]*/$ip/"`
		new_info=`echo $new_info | sed "s/-[0-9]*\.[0-9]*\.[0-9]*/-$ip/"`
		$nvram set $file="$new_info"
	done

	new_info=`$nvram get dmz_ipaddr | sed "s/[0-9]*\.[0-9]*\.[0-9]*/$ip/"`
	$nvram set dmz_ipaddr="$new_info"
	
	if [ -f /tmp/static_conflict ]; then
      echo "static_conflict"
		rm -rf /tmp/static_conflict
		/sbin/cmdlan.sh start
	else
       echo "dynamic_conflict"
		#/www/cgi-bin/firewall.sh stop
		/sbin/cmdlan.sh restart
		#/www/cgi-bin/firewall.sh start
		$nvram commit
	fi
}

case "$1" in
        start)

         # add http_hijack services, here means not in blankstate, need to run http_hijack when WAN/LAN IP conflict
         sleep 1
         /usr/bin/lan_phy down
         set_lan
         sleep 2
         /usr/bin/lan_phy up
         echo "set wan_lan_ip_conflict=1"
         /usr/sbin/nvram set wan_lan_ip_conflict=1
         echo 2 > /proc/fast_nat
         /etc/rc.d/conflict.sh restart
        	;;
        stop)
#		echo -n 7 > /proc/switch_phy
		;;
        *)
        	echo "Usage: /sbin/ip_conflict.sh start|stop"
        	;;
esac
