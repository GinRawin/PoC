//BRS_01_checkNet.html

var wiz_start_genie_re="Ja.";
var bh_config_wireless_setting="Konfigurere trådløsinnstillinger";
var genie_wireless_set_info="NETGEAR genie har oppdaget et eksisterende trådløst nettverk.";
var select_choice="Velg trådløsinnstillinger på denne enheten:";
var use_router_setting="Bruk de samme innstillingene i mitt eksisterende trådløse nettverk. Dette er anbefalt.";
var use_manual_setting="Konfigurer et nytt trådløst nettverk. Jeg forstår at den trådløse enheten må kobles manuelt til det nye nettverket.";
var SWP0011="Bekreftelse:";
var SWP0012="Bekreft trådløsinnstillingene, og klikk deretter på knappen Neste. Du er nå tilkoblet trådløst. Etter at du har klikket på Neste, vil du miste den trådløse tilkoblingen. Deretter kan du koble til på nytt med de nye innstillingene og fortsette konfigureringen.";
var range_ext="Enhetens nye innstillinger:";
var SWP005="Ingen Internett-tilkobling er oppdaget.";
var network_checking="Kontrollerer nettverkstilkoblingen ...";
var wireless_net_det="Eksisterende trådløst nettverk oppdaget";
var quit="Avslutt";
var bh_try_again="Prøv igjen";
var no_device_det_1 ="NETGEAR genie kan ikke hente informasjon om det eksisterende trådløse nettverket.";
var no_device_det_2 ="Vil du at NETGEAR genie skal prøve igjen?";
var wiz_start_manual="Nei. Jeg ønsker å konfigurere trådløsinnstillingene selv.";
var LPC028="Kontroller ruterens Internett-tilkobling.";
var sec_phr_g="Trådløst passord";



















var h_wlan="<body bgColor=#0099cc><P><font size=\"4\"><B>Hjelp for Tradlos tilkobling (Wireless)</B></font></P><P><B>MERK:</B> Driftskanalen og omradet ma vare riktig konfigurert for at det skal vare samsvar med alle relevante krav og forskrifter og kompatibilitet mellom lignende produkter i omradet ditt. <P><B>Plassering av enheten for a sikre optimal tradlos tilkobling</B><P>Driftsavstanden eller -omradet for den tradlose tilkoblingen kan variere betraktelig pa bakgrunn av hvor enheten er plassert. Du far best resultat hvis enheten plasseres:<UL><LI>nar midten i det omradet PC-en skal brukes<LI>hoyt oppe, for eksempel pa en hylle<LI>vekk fra potensielle kilder til interferens, for eksempel PC-er, mikrobolgeovner og tradlose telefoner<LI>vekk fra store metalloverflater </LI></UL><P><B>Merk:</B> Hvis ikke disse retningslinjene folges, kan ytelsen bli betraktelig redusert, eller det kan bli umulig a koble seg tradlost til enheten.</P><HR><A name=network></A><P><B>Tradlost nettverk</B></P><P>Navn (SSID) (Name (SSID))<P>Skriv inn en verdi pa opptil 32 alfanumeriske tegn. Det samme navnet (SSID) ma tilordnes til alle de tradlose enhetene i nettverket. Standard SSID er Netgear_EXT, men NETGEAR anbefaler sterkt at du endrer nettverkets navn (SSID) til en annen verdi. I denne verdien skilles det mellom sma og store bokstaver. NETGEAR er for eksempel ikke det samme som NETGEAR.<P>Omrade (Region)<P>Velg omradet ditt fra rullegardinlisten. Dette feltet viser omradet der det tradlose grensesnittet skal brukes. Det kan hende det ikke er tillatt a bruke enheten i et annet omrade enn det som vises her. Hvis landet eller omradet ditt ikke er oppfort, ma du ta kontakt med de relevante lokale myndighetene eller se pa webomradet til NETGEAR for mer informasjon om hvilke kanaler du skal bruke.<P>Kanal (Channel)<P>Dette feltet angir hvilken driftsfrekvens som skal brukes. Det skal ikke vare nodvendig a endre den tradlose kanalen med mindre det oppstar interferensproblemer med et annet tilgangspunkt i narheten.</P><P>Modus (Mode)</P>Velg tradlosmodusen som skal brukes. Alternativene er:<UL><LI>Opptil 54 Mbps (Up to 54 Mbps). Eldre modus (Legacy Mode), med en maksimal hastighet pa opptil 54 Mbps for b/g-nettverk.<LI>Opptil 130 Mbps (Up to 130 Mbps). Nabovennlig modus (Neighbor-Friendly Mode), standardmodusen, med en hastighet pa opptil 130 Mbps nar det er tradlose nettverk i narheten.<LI>Opptil 300 Mbps (Up to 300 Mbps). Ytelsesmodus (Performance Mode), med en maksimal Wireless-N-hastighet pa opptil 300 Mbps.</LI></UL><P>Standardinnstillinger er <b>Opptil 130 Mbps</b>, noe som er kompatibelt med alle 11b-, 11g- og 11n-tradlose stasjoner. </P><HR><A name=security></A><p><b>Sikkerhetsalternativer</b></p><UL><LI>Ingen – ingen datakryptering<LI>WEP – Wired Equivalent Privacy. Bruk WEP 64- eller 128-biters datakryptering<br><b>Merk:</b> Wi-Fi Protected Setup-funksjonen er deaktivert nar sikkerhetsinnstillingen er godkjent for WEP eller WPA-PSK [TKIP].<LI>WPA-PSK [TKIP] – Wi-Fi Protected Access med forhandsdelt nokkel. Bruk standard WPA-PSK-kryptering med TKIP-krypteringstype<LI>WPA2-PSK [AES] – Wi-Fi Protected Access versjon 2 med forhandsdelt nokkel. Bruk standard WPA2-PSK-kryptering med AES-krypteringstypen<LI>WPA-PSK [TKIP] + WPA2-PSK [AES] – tillat klienter som bruker enten WPA-PSK [TKIP] eller WPA2-PSK [AES]</LI></UL><p>Hvis du vil oppna best mulig ytelse med NETGEAR WN511B- eller andre tradlose kort i robuste sikkerhetsnettverk, anbefaler NETGEAR at du endrer sikkerhetsalternativet for XWN5001-nettverket til WPA2-PSK.</p><HR><A name=wep></A><p><b>Sikkerhetskryptering (WEP)  </b></p><P>Godkjenningstype <p>Vanligvis kan du bruke standardverdien Automatisk. Hvis det mislykkes, kan du velge riktig verdi - Apent system eller Delt nokkel. Kontroller det tradlose kortets dokumentasjon for a se hvilke metoder som skal brukes.<p>Krypteringsstyrke <p>Velg WEP-krypteringsniva: <UL><LI>64-biters (noen ganger kalt 40-biters) kryptering <LI>128-biters kryptering </LI></UL><HR><A name=wepkey></A><p><b>Sikkerhetskrypteringsnokkel (WEP)</b></p><p>Hvis WEP er aktivert, kan du programmere de fire datakrypteringsnoklene manuelt eller automatisk. Disse verdiene ma vare identiske for alle PC-er og tilgangspunkter i nettverket. <p>Automatisk nokkelgenerering (passord) <p>Skriv inn et ord eller en gruppe utskrivbare tegn i boksen Passord, og klikk pa knappen Generer for a generere WEP-noklene automatisk. Hvis krypteringsstyrken er satt til 64 biter, skrives det automatisk inn en nokkelverdi i alle de fire nokkelboksene. Hvis krypteringsstyrken er satt til 128 biter, fylles bare den valgte WEP-nokkelboksen nokkelverdier. <p>Manuell angivelsesmodus <p>Velg hvilken av de fire noklene som skal brukes, og skriv inn den tilhorende WEP-nokkelinformasjonen for nettverket i den valgte nokkelboksen. <p>For 64-biters WEP – skriv inn 10 heksadesimale sifre (enhver kombinasjon av 0–9 og A–F). <p>For 128-biters WEP – skriv inn 26 heksadesimale sifre (enhver kombinasjon av 0–9 og A–F). <p>Pass pa at du klikker pa Bruk for a lagre innstillingene pa denne menyen.</P><HR><A name=wpa-psk></A><p><b>Sikkerhetskryptering (WPA-PSK)</b></p><p>Hvis dette alternativet velges, ma du bruke TKIP-kryptering og angi WPA-passordet (nettverksnokkelen). Skriv inn et ord eller en gruppe utskrivbare tegn i boksen Passord. Passordet ma besta av enten 8 til 63 ASCII-tegn eller noyaktig 64 heksadesimale sifre. Et heksadesimalt siffer er ett av folgende tegn: <br>0, 1, 2, ..., 8, 9, A, B, C, D, E og F. <p>Klikk pa Bruk for a lagre innstillingene. </p><HR><A name=wpa2-psk></A><p><b>Sikkerhetskryptering (WPA2-PSK)</b></p><p>WPA2 er en nyere versjon av WPA. Velg dette alternativet bare hvis alle tradlosklientene i nettverket stotter WPA2. Hvis dette alternativet velges, ma du bruke AES-kryptering og angi WPA-passordet (nettverksnokkelen). Skriv inn et ord eller en gruppe utskrivbare tegn i boksen Passord. Passordet ma besta av enten 8 til 63 ASCII-tegn eller noyaktig 64 heksadesimale sifre. Et heksadesimalt siffer er ett av folgende tegn: <br>0, 1, 2, ..., 8, 9, A, B, C, D, E og F. </p><HR><A name=wpa-psk+wpa2-psk></A><p><b>Sikkerhetskryptering (WPA-PSK + WPA2-PSK)  </b></p><p>Med dette alternativet kan klienter bruke enten WPA (med TKIP, kringkastede pakkerbruker ogsa TKIP) eller WPA2 (med AES). Hvis dette alternativet velges, ma krypteringen vare TKIP + AES. Du ma ogsa angi WPA-passordet (nettverksnokkelen). For at du skal fa maksimal tradlos ytelse, ma 11N-klienter kobles til denne ruteren ved hjelp av WPA2-PSK (med AES). For klienter som kobler til via WPA-PSK (med TKIP), er den maksimale tradloshastigheten 802.11g. Skriv inn et ord eller en gruppe utskrivbare tegn i boksen Passord. Passordet ma besta av enten 8 til 63 ASCII-tegn eller noyaktig 64 heksadesimale sifre. Et heksadesimalt siffer er ett av folgende tegn: <br>0, 1, 2, ..., 8, 9, A, B, C, D, E og F. <HR><p><b>Slik lagrer eller avbryter du endringer:</b></p><p>Klikk pa <b>Bruk</b> for at endringene skal bli aktivert. <br>Klikk pa <b>Avbryt</b> for a ga tilbake til de forrige innstillingene. </p></body>";

var help_center="Hjelpesentral";
var help_show_hide="Vis/skjul hjelpesentral";
var sec_wpa_mode="WPA-modus:";
var auto_mark="Automatisk";
var guest_wire_iso="Aktiver Trådløs isolering";
var adva_wlan_ssid_broadcast="Aktiver SSID Broadcast";
var cancel_mark="Avbryt";
var apply_mark="Bruk";

var wlan_network_mark="Trådløst nettverk";
var wlan_mark_ssid="Navn (SSID)";
var wlan_mark_reg="Område";
var wlan_mark_chan="Kanal";
var wlan_mark_mode="Modus";
var wlan_mark_gb="b og g";
var wlan_mark_go="bare g";
var wlan_mark_bo="bare b";
var wlan_mark_turbog="Automatisk 108 Mbps";
var wlan_mode_54="Opptil 54 Mbps";
var wlan_mode_65="Opptil 65 Mbps";
var wlan_mode_130="Opptil 130 Mbps";
var wlan_mode_145="Opptil 145 Mbps";
var wlan_mode_150="Opptil 150 Mbps";
var wlan_mode_300="Opptil 300 Mbps";
var wlan_wlacl="Tilgangsliste for trådløskort";
var wir_wning = "I henhold til Wi-Fi Alliance-retningslinjer for sameksistens mellom 40 Mhz og 20 Mhz, selv om du velger modusen \'Opptil %sMbps\', kan produktets servicehastighet reduseres til 20 Mhz. Dette korresponderer vanligvis til %s Mbps-ytelse.";

var sec_type="Sikkerhetsalternativer";
var sec_off="Ingen";
var sec_wep="WEP";
var sec_wpa="WPA-PSK (TKIP)";
var sec_wpa2="WPA2-PSK (AES)";
var sec_wpas="WPA-PSK (TKIP) + WPA2-PSK (AES)";
var sec_pr_wpa="Sikkerhetsalternativer (WPA-PSK)";
var sec_pr_wpa2="Sikkerhetsalternativer (WPA2-PSK)";
var sec_pr_wpas="Sikkerhetsalternativer (WPA-PSK + WPA2-PSK)";
var sec_auth="Godkjenningstype";
var sec_auto="Automatisk";
var sec_share="Delt nøkkel";
var sec_enc="Krypteringsstyrke";
var sec_64="64-biters";
var sec_128="128-biters";
var sec_enc_head="Sikkerhetskryptering (WEP)";
var sec_key="Sikkerhetskrypteringsnøkkel (WEP)";
var sec_key1="Nøkkel 1";
var sec_key2="Nøkkel 2";
var sec_key3="Nøkkel 3";
var sec_key4="Nøkkel 4";
var sec_phr="Passord";
var sec_863_or_64h="(8–63 tegn eller 64 heksadesimale sifre)";
var wep_or_wps="WEP-sikkerhet med automatisk autentifisering av delt nøkkel fungerer ikke med WPS. WPS er utilgjengelig. Vil du fortsette?";
var wep_just_one_ssid="WEP-sikkerhet støttes bare på én SSID for hvert bånd";


var bh_internet_checking="Kontrollerer Internett-forbindelsen. Vent litt ...";

var SB011="Hvis du har eksisterende trådløsinnstillinger som brukes av alle klientens enheter, kan du <font id=\"a\" onclick=\"click_here();\">klikke her</font> for å oppdatere de forhåndsinnstilte innstillingene til de eksisterende.";

//BRS_02_genieHelp.html
var bh_config_net_connection="Konfigurerer Internett-forbindelsen";

var wlan_mark="Trådløsinnstillinger";
var wlan_mark_ssid="Navn (SSID)";
var sec_type="Sikkerhetsalternativer";
var sec_off="Ingen";
var sec_wep="WEP";
var sec_wpa="WPA-PSK (TKIP)";
var sec_wpa2="WPA2-PSK (AES)";
var sec_wpas="WPA-PSK (TKIP) + WPA2-PSK (AES)";
var sec_phr="Passord";

var bh_connection_further_action="Du er ennå ikke tilkoblet Internett.";

var bh_want_genie_help="Vil du ha hjelp fra NETGEAR Genie?";

var bh_yes_mark="Ja";

var bh_no_genie_help="Nei, jeg vil konfigurere Internett-tilkoblingen selv.";

var bh_no_genie_help_confirm="Konfigurering av Internett-tilkoblingen krever erfaring med nettverksoppbygging. Er du sikker?"

var bh_have_saved_copy="Jeg har lagret ruterinnstillingene i en fil, og jeg vil gjenopprette ruteren med de innstillingene."

var bh_next_mark="Neste";


//BRS_03A_detcInetType.html
var bh_detecting_connection="Registrerer Internett-tilkoblingen";

var bh_plz_wait_process="Denne prosessen kan ta et minutt eller to. Vent litt...";


//BRS_03A_A_noWan.html
var bh_no_cable="Ingen Ethernet-kabel er koblet til ruterens Internett-port";

var bh_wizard_setup_nowan_check="Sørg for at kabelen er koblet til bredbåndets modemport og ruterens Internett-port.";

var bh_click_try_again="Etter at du har merket av for Ethernet-kabelen, klikker du på <b>Prøv på nytt</b>.";

var bh_try_again="Prøv igjen";


//BRS_03A_B_pppoe.html
var bh_pppoe_connection="PPPoE DSL-Internett-tilkobling oppdaget";

var bh_enter_info_below="Skriv inn den påkrevde informasjonen nedenfor.";

var bh_pppoe_login_name="Brukernavn";
var bh_ddns_passwd="Passord";


//BRS_03A_B_pppoe_reenter.html
var bh_ISP_namePasswd_error="Feil ISP-brukernavn eller -passord";

var bh_enter_info_again="Skriv inn den påkrevde informasjonen igjen.";


//BRS_03A_C_pptp.html
var bh_pptp_login_name="Pålogging";

var bh_pptp_connection="PPTP-Internett-tilkobling oppdaget";

var bh_basic_pptp_servip="Serveradresse";

var bh_sta_routes_gtwip="IP-adresse for gateway";

var bh_basic_pptp_connection_id="Tilkoblings-ID/tilkoblingsnavn";

//BRS_03A_F_l2tp.html
var bh_l2tp_connection="L2TP Internet Connection Detected";

//BRS_03A_D_bigpond.html
var bh_bpa_connection="BigPond-Internett-tilkobling oppdaget"; 

var bh_basic_bpa_auth_serv="Godkjenningsserver";

var bh_basic_pppoe_idle="Tidsavbrudd ved inaktivitet (i minutter)";


//BRS_03A_E_IP_problem_staticIP.html
var bh_no_internet_ip="Problemer med å registrere Internett-tilkoblingen";

var bh_no_internet_ip2="Problemer med å registrere Internett-tilkoblingen – IP-adresse";

var bh_no_internet_ip3="Problemer med å registrere Internett-tilkoblingen – MAC-adresse";

var bh_if_have_static_ip="Fikk du en fast (statisk) IP-adresse av Internett-leverandøren din? Dette er en <b>svært sjelden</b> spesialdistribusjon. ";

var bh_yes_correct="Ja. Internett-leverandøren ga meg en fast (statisk) IP-adresse.";

var bh_not_have_static_ip="Nei, jeg fikk ingen statisk IP-adresse fra Internett-leverandøren.";

var bh_do_not_know="Jeg vet ikke. ";

var bh_select_option="Velg et alternativ, og klikk på <b>Neste</b> for å gå videre.";

var bh_select_an_option="Velg et alternativ først.";


//BRS_03A_E_IP_problem_staticIP_A_inputIP.html
var bh_fix_ip_setting="Innstillinger for fast Internett-IP";

var bh_enter_ip_setting="Angi de faste IP-innstillingene som du fikk av Internett-leverandøren, og klikk på <b>Neste</b> for å gå videre.";

var bh_info_mark_ip="IP-adresse";
//var bh_info_mark_ip="Min IP-adresse";
var bh_info_mark_mask="Nettverksmaske";

var bh_constatus_defgtw="Standard gateway";

var bh_preferred_dns="Foretrukket DNS-server";

var bh_alternate_dns="Alternativ DNS-server";

var bh_basic_int_third_dns="Tredje DNS";

//BRS_03A_E_IP_problem.html
var bh_genie_cannot_find_ip="Dette skyldes mest sannsynlig én av følgende grunner:";
var bh_genie_cannot_find_ip_reason1="1.  Modemet ble ikke slått av og deretter på igjen under kablingen.";
var bh_genie_cannot_find_ip_reason1_desc="Hvis du vil løse dette problemet, slår du modemet av og deretter på igjen. For å slå modemet av og deretter på igjen med reservebatteri, kan det hende du må ta batteriet ut og sette det inn igjen. Etter å ha slått modemet av og deretter på igjen, venter du i 2 minutter på at modemet skal starte opp igjen."; 
var bh_genie_cannot_find_ip_reason2="2.  Den gule Ethernet-kabelen er ikke helt tilkoblet eller satt inn på feil sted.";
var bh_genie_cannot_find_ip_reason2_desc="For å løse dette problemet må du sørge for at Ethernet-kabelen er koblet til bredbåndets modemport og ruterens Internett-port.";

var bh_select_no_IP_option="Velg ett av alternativene nedenfor, og klikk på <b>Neste</b> for å gå videre:";
var bh_select_no_IP_option1="Jeg har slått modemet av og på igjen og ventet i 2 minutter.";
var bh_select_no_IP_option2="Jeg rettet opp en feil med Ethernet-kabelen.";
var bh_select_no_IP_option3="Ingen av alternativene ovenfor.";


//BRS_03A_E_IP_problem_staticIP_B_macClone.html
var bh_use_pc_mac="Hvis du tidligere koblet til Internett-tjenesten med en datamaskin eller en annen ruter, kan NETGEAR Genie bruke samme MAC-adresse som fungerte tidligere.";

var bh_mac_in_product_label="En MAC-adresse er et unikt nummer.  Du finner datamaskinens eller ruterens MAC-adresse på produktetiketten.";

var bh_enter_mac="Skriv inn MAC-adressen her.";

var bh_mac_format="(format AABBCCDDEEFF)";


//BRS_03B_haveBackupFile.html
var bh_settings_restoration="Gjenopprette ruterinnstillinger ";

var bh_browser_file="Finn sikkerhetskopifilen for ruterinnstillingene som du tidligere har lagret, og klikk på <b>Neste</b> for å gå videre.";

var bh_back_mark="Tilbake";


//BRS_03B_haveBackupFile_fileRestore.html
var bh_settings_restoring="Gjenoppretter ruterinnstillinger"; 

var bh_plz_waite_restore="Denne prosessen kan ta noen minutter. Vent litt …";


//BRS_04_applySettings.html
var bh_apply_connection="Aktiverer innstillinger for Internett-tilkoblingen";

var bh_plz_waite_apply_connection="Denne prosessen kan ta et minutt eller to. Vent litt...";


//BRS_05_networkIssue.html
var bh_netword_issue="Problem med nettverkstilkoblingen";

var bh_cannot_connect_internet="Ruteren kan ikke kobles til Internett med gjeldende innstillinger.";

var bh_plz_reveiw_items="Gå gjennom følgende elementer:";

var bh_cable_connection="- Kontroller at kabeltilkoblingene er riktige. Se installasjonsveiledningen for ruteren for å få instruksjoner.";

var bh_modem_power_properly="- Kontroller at bredbåndsmodemet blir slått riktig av og på. Hvis du har et modem som går på reservebatteri, må du fjerne og sette batteriet inn igjen for å slå modemet av og på igjen.";

var bh_try_again_or_manual_config="Vil du at NETGEAR Genie skal prøve igjen?";

var bh_I_want_manual_config="Nei. Jeg vil konfigurere Internett-tilkoblingen selv."; 

var bh_manual_config_connection="Jeg vil konfigurere Internett-tilkoblingen selv";


//BRS_success.html
var bh_congratulations="Gratulerer.";

var bh_connect_success_1="Du er tilkoblet Internett.";

var bh_connect_success_2="Denne ruteren er forhåndsinnstilt med følgende unike navn på trådløst nettverk (SSID) og ";

var bh_network_key="nettverksnøkkel (passord)";

var bh_rollover_help_text="Ruteren er forhåndsinnstilt med WPA2-PSK trådløs sikkerhet for å beskytte nettverket ditt mot uønsket tilgang. For å koble til det trådløse nettverket må du angi nettverksnøkkelen (passord). Disse forhåndsinnstillingene er unike for denne enheten, som et serienummer.  Hvis du vil endre dem, kan du gjøre det senere på skjermbildet Wireless Settings (Trådløsinnstillinger) på ruterens webgrensesnitt."; 

var bh_success_no_wireless_security_1 = "Trådløs sikkerhet er ikke aktivert på denne ruteren. NETGEAR anbefaler at du ";
var bh_success_no_wireless_security_2 = "klikk her";
var bh_success_no_wireless_security_3 =  " for å aktivere trådløs sikkerhet og beskytte nettverket.";

var bh_wirless_name="Navn på trådløst nettverk (SSID)"

var bh_wireless="Trådløs";

var bh_wpa_wpa2_passpharse="Nettverksnøkkel (passord)"; 

var bh_save_settings="Save router settings";

var bh_print_this="Skriv ut";


var bh_take_to_internet="Før meg til Internett";

var bh_plz_wait_moment="Vent litt ...";

//the string for not_support_print is temporary.
var bh_not_support_print="Datamaskinen har ikke støtte for skriver.";
//already exist
var bh_login_name_null="Brukernavnet kan ikke være tomt.";
var bh_password_error="Passordet er ugyldig.";
var bh_idle_time_null="Angi inaktiv tid.\n";
var bh_invalid_idle_time="Den inaktive tiden er ugyldig. Angi riktig tall.\n";
var bh_invalid_myip="IP-adressen er ugyldig. Skriv den inn på nytt, eller la den stå tom.";
var bh_invalid_gateway="IP-adressen for gatewayen er ugyldig. Skriv den inn på nytt.";
var bh_bpa_invalid_serv_name="Ugyldig IP-adresse for godkjenningsserver.";
var bh_invalid_servip_length="Merkelappene skal ha 63 tegn eller færre.\n";
var bh_invalid_ip="IP-adressen er ugyldig. Skriv den inn på nytt.";
var bh_invalid_mask="Nettverksmasken er ugyldig. Skriv den inn på nytt.\n";
var bh_same_subnet_ip_gtw="IP-adressen og IP-adressen for gatewayen må være i samme nettverksmaske.\n";
var bh_same_lan_wan_subnet="LAN-IP-adressen og WAN-IP-adressen kan ikke være i samme nettverksmaske.\n";
var bh_filename_null="Filnavnet kan ikke være tomt.";
var bh_not_correct_file="Tilordne den riktige filen. Filformatet er *.";
var bh_ask_for_restore="Advarsel! \nHvis du gjenoppretter innstillingene fra en konfigurasjonsfil, slettes alle de gjeldende innstillingene. \nEr du sikker på at du vil gjøre dette?";
var bh_invalid_primary_dns="Den primære DNS-adressen er ugyldig. Skriv den inn på nytt.\n";
var bh_invalid_second_dns="Den sekundære DNS-adressen er ugyldig. Skriv den inn på nytt.\n";
var hb_invalid_third_dns="Invalid third DNS address. Please enter it again.\n";
var bh_dns_must_specified="DNS-adressen må spesifiseres.";
var bh_invalid_mac="MAC-adressen er ugyldig.";
var bh_failure_head="Feil";
var bh_few_second="Dette skjermbildet går automatisk tilbake til det forrige skjermbildet i løpet av noen sekunder ...";

var bh_important="Viktig oppdatering";
var bh_wanlan_conflict_info="Hvis du vil unngå konflikt med Internett-leverandøren, må ruterens IP-adresse ha blitt oppdatert til ";
var bh_continue_mark="Fortsett";


//readySHARE remote strings
var remote_share_head="ReadySHARE Cloud"

var ready_share_info1="ReadySHARE Cloud-funksjonen gir deg ekstern tilgang via Internett til en USB-lagringsenhet som er koblet til ruterens USB-port."
var how_setup_ready_share="Slik konfigurerer du ReadySHARE Cloud"
var ready_share_step1="Trinn 1: Du trenger en ReadySHARE Cloud-konto. Hvis du ikke har en, kan du<a class='linktype' target='_blank' href='https://readyshare.netgear.com/site/index.jsp?pid=4&src=device'>klikke her</a> for å få en."
var ready_share_step2="Trinn 2: På denne siden angir du brukernavnet og passordet for ReadySHARE Cloud for å registrere ruteren og USB-enheten som er tilkoblet kontoen din."
var ready_share_step3="Trinn 3: Logg på <a class='linktype' target='_blank' href='http://readyshare.netgear.com/'>http://readyshare.netgear.com/</a> igjen med kontoen din. Du vil se USB-enheten som er tilkoblet ruteren."
var ready_share_step4="Trinn 4: Den første gangen blir du bedt om å laste ned en Windows-klient, som brukes til å foreta en sikker tilkobling fra PC-en til ruterens USB-enhet. Logg på denne klienten slik at du kan få tilgang til USB-enheten overalt."
var ready_share_set_note="<b>Merk:</b> Uten denne klienten kan du bla gjennom innholdet på USB-enheten, men du kan ikke åpne filer eller foreta endringer i dem"
var ready_share_start="Start nå ved å aktivere ReadySHARE Cloud"
var ready_share_get_account="Hvis du ikke har en ReadySHARE Cloud-konto, kan du <a class='linktype' target='_blank' href='https://readyshare.netgear.com/site/index.jsp?pid=4&src=device'>klikke her</a> for å få en"
var username="Brukernavn"
var key_passphrase="Passord"
var register="Registrer"
var register_note="<b>Merk:</b> Internett vil være aktivert til avregistreringen er fullført."
var help_center="Hjelpesentral"
var help_show_hide="Vis/skjul hjelpesentral"

var resister_user="ReadySHARE Cloud er registrert med bruker"
var access_storage_method="Du kan følge trinnene 2–4 ovenfor for å få tilgang til lagringsenheten overalt."
var unregister_info="Klikk på <B>Unregister</B> (Avregistrer) for å registrere ReadySHARE Cloud med en annen bruker."
var unregister="Unregister"

var result_register_ok="Registreringen er fullført"
var result_register_fail="Registreringen mislyktes"
var result_unreg_ok="Avregistreringen er fullført"
var result_unreg_fail="Avregistreringen mislyktes"


//for wireless check string
var wps_in_progress="WPS-prosessen pågår. Ta i bruk endringene senere."
var ssid_null="SSID kan ikke være tom."
var ssid_not_allowed="Tegnet er ikke tillatt i SSID"
var ssid_not_allowed_same="SSID-en er duplisert, bytt til en annen."
var SWSW02="Sikkerhetsgodkjenning med WEP eller WPA-PSK [TKIP] fungerer ikke med WPS. WPS blir utilgjengelig. Vil du fortsette?"
var SWSW11="WPS krever SSID-kringkasting for å fungere. Hvis du gjør denne endringen, blir WPS utilgjengelig. Vil du fortsette?"
var SWSW12="Er du sikker på at du ikke ønsker trådløs sikkerhet på nettverket ditt? Denne innstillingen brukes vanligvis for trådløse tilgangspunkt som er åpne for alle. Vil du fortsette?"
var wds_auto_channel="Funksjonen for trådløs repetisjon kan ikke brukes med Automatisk kanal.\nEndre kanalinnstillingene før du aktiverer funksjonen for trådløs repetisjon. "
var notallowpassp="Tegnet er ikke tillatt i passord"
var guest_tkip_300_150="WPA-PSK [TKIP] i gjestenettverk fungerer BARE i modusen \"Up to 54 Mbps\" (Opptil 54 Mbps) (Legacy G), ikke i N-modusen."
var guest_tkip_aes_300_150="NETGEAR anbefaler at du bruker WPA2-PSK [AES] i gjestenettverket for å få full støtte for N-hastigheten."
var wlan_tkip_aes_300_150="VIKTIG\nWPA-PSK [TKIP] kan bare brukes med en hastighet på \"opptil 54 Mbps\", ikke N-hastighet.\nNETGEAR anbefaler at du bruker WPA2-PSK [AES] for å få full støtte for N-hastighet."
var notSupportWLA="Israel og Midtøsten støtter ikke 802.11a. Hvis du velger dette, slås trådløs a/n av. Vil du fortsette?"
var passphrase_short8="Passordet er for kort. Det må inneholde minst 8 tegn."
var passphrase_long63="Passordet er for langt. Det kan ikke inneholde mer enn 63 tegn."
