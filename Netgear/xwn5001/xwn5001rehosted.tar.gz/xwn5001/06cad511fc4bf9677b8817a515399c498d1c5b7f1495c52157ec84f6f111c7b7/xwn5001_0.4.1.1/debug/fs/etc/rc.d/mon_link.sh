#!/bin/sh

DOWN_TIME=0
PWS_TIME=600
TEST_PWS_TIME="$(nvram get pwr_save_time)"
if [ "$TEST_PWS_TIME" != "" ]; then
	PWS_TIME=$TEST_PWS_TIME
fi
nvram set plc_pwr_save=0
LAST_ETH_LINK=-1

while [ 1 ]
do
		WAN_PROTO="$(nvram get wan_proto)"
		wlan_on="$(nvram get endis_wl_radio)"
		WL_STA=""
		if [ "$wlan_on" = "1" ]; then
			WL_STA=`wlanconfig ath0 list sta 2>/dev/null`
			#there is will be : in the mac address if any sta is connecting to ath0
		fi	
		ETH_STA=`cat /proc/driver/phy | cut -c 1`

		if [ "$WL_STA" = "" -a "$ETH_STA" = "0" ]; then
				DOWN_TIME=$((DOWN_TIME+2))
		else				
				if [ "$(nvram get plc_pwr_save)" = "1" ]; then
						nvram set plc_pwr_save=0
						nvram commit
						if [ "$(nvram get pwr_save_enable)" = "1" ]; then
							echo "Leaving power saving mode"
							echo -n 1 > /proc/driver/select_ctl
							if [ "$wlan_on" = "1" ]; then
								echo -n 1 > /proc/driver/wirelessled
							fi
							echo -n 0 > /proc/driver/power_amber_led
							echo 30 > /proc/driver/net_sw
						fi
						
				fi
				DOWN_TIME=0		
		fi
		if [ "$DOWN_TIME" -ge "$PWS_TIME"  -a "$(nvram get plc_pwr_save)" = "0" ]; then
				nvram set plc_pwr_save=1
				nvram commit
				if [ "$(nvram get pwr_save_enable)" = "1" ]; then
					echo "Entering power saving mode"
					echo -n 0 > /proc/driver/select_ctl
					echo -n 0 > /proc/driver/plcled
					echo -n 0 > /proc/driver/actled
					echo -n 0 > /proc/driver/wirelessled
					echo -n 1 > /proc/driver/power_amber_led
					echo 31 > /proc/driver/net_sw
				fi	
		fi

		if [ "$WAN_PROTO" = "dhcp" -a "$LAST_ETH_LINK" = "0" -a "$ETH_STA" = "1" ]; then
			echo "cable plug-in ..."
			killall -SIGUSR1 udhcpc
		fi
		LAST_ETH_LINK=$ETH_STA
		
		#echo "DOWN_TIME= $DOWN_TIME"
		sleep 2
done
