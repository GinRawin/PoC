#!/bin/sh

lan_ifname=`nvram get lan_ifname`
lan_hwifname=`nvram get lan_hwifname`
wlan_ifname=`nvram get wl_ifname`
lan_accessenable=`nvram get HTTPLANAccessEnable`
wlan_accessenable=`nvram get HTTPWLANAccessEnable`

accesslog_enable=`nvram get LogAccessEnable`

EBTABLE_BIN="/usr/sbin/ebtables"
IPTABLES_BIN="/usr/sbin/iptables"

RETVAL=0

[ -f /usr/sbin/ebtables ] || exit 0
[ -f /usr/sbin/iptables ] || exit 0

start() {

	if [ "$lan_accessenable" = "0" ]; then
		${EBTABLE_BIN} -t broute -A BROUTING -i $lan_hwifname -j mark --mark-set 100 
		if [ "$accesslog_enable" = "0" ]; then
			${IPTABLES_BIN} -I INPUT 1 -i $lan_ifname -p tcp --dport 80 -m mark --mark 100 -j DROP
		else
			${IPTABLES_BIN} -I INPUT 1 -i $lan_ifname -p tcp --dport 80 -m mark --mark 100 -m log --log-prefix "FILTER HTTP Connection denied" --log-type 2 -j DROP 2> /dev/null
		fi
	fi
	if [ "$wlan_accessenable" = "0" ]; then
		info=`${EBTABLE_BIN} -t broute -L BROUTING | grep 0x65`
		if [ "x$info" = "x" ]; then
			${EBTABLE_BIN} -t broute -A BROUTING -i $wlan_ifname -j mark --mark-set 101
			${EBTABLE_BIN} -t broute -A BROUTING -i ra1 -j mark --mark-set 102
			${EBTABLE_BIN} -t broute -A BROUTING -i ra2 -j mark --mark-set 103
			${EBTABLE_BIN} -t broute -A BROUTING -i ra3 -j mark --mark-set 104
		fi
		if [ "$accesslog_enable" = "0" ]; then
			${IPTABLES_BIN} -I INPUT 1 -i $lan_ifname -p tcp --dport 80 -m mark --mark 101 -j DROP
			${IPTABLES_BIN} -I INPUT 2 -i $lan_ifname -p tcp --dport 80 -m mark --mark 102 -j DROP
			${IPTABLES_BIN} -I INPUT 3 -i $lan_ifname -p tcp --dport 80 -m mark --mark 103 -j DROP
			${IPTABLES_BIN} -I INPUT 4 -i $lan_ifname -p tcp --dport 80 -m mark --mark 104 -j DROP
		else
			${IPTABLES_BIN} -I INPUT 1 -i $lan_ifname -p tcp --dport 80 -m mark --mark 101 -m log --log-prefix "FILTER HTTP Connection denied" --log-type 2 -j DROP 2> /dev/null
			${IPTABLES_BIN} -I INPUT 2 -i $lan_ifname -p tcp --dport 80 -m mark --mark 102 -m log --log-prefix "FILTER HTTP Connection denied" --log-type 2 -j DROP 2> /dev/null
			${IPTABLES_BIN} -I INPUT 3 -i $lan_ifname -p tcp --dport 80 -m mark --mark 103 -m log --log-prefix "FILTER HTTP Connection denied" --log-type 2 -j DROP 2> /dev/null
			${IPTABLES_BIN} -I INPUT 4 -i $lan_ifname -p tcp --dport 80 -m mark --mark 104 -m log --log-prefix "FILTER HTTP Connection denied" --log-type 2 -j DROP 2> /dev/null
		fi
	fi

	echo
	return $RETVAL  
}

stop() {

	${EBTABLE_BIN} -t broute -D BROUTING -i $lan_hwifname -j mark --mark-set 100 2> /dev/null 
	#${EBTABLE_BIN} -t broute -D BROUTING -i $wlan_ifname -j mark --mark-set 101 2> /dev/null
	#${EBTABLE_BIN} -t broute -D BROUTING -i ra1 -j mark --mark-set 102 2> /dev/null
	#${EBTABLE_BIN} -t broute -D BROUTING -i ra2 -j mark --mark-set 103 2> /dev/null
	#${EBTABLE_BIN} -t broute -D BROUTING -i ra3 -j mark --mark-set 104 2> /dev/null
	${IPTABLES_BIN} -D INPUT -i $lan_ifname -p tcp --dport 80 -m mark --mark 100 -j DROP 2> /dev/null
	${IPTABLES_BIN} -D INPUT -i $lan_ifname -p tcp --dport 80 -m mark --mark 101 -j DROP 2> /dev/null
	${IPTABLES_BIN} -D INPUT -i $lan_ifname -p tcp --dport 80 -m mark --mark 102 -j DROP 2> /dev/null
	${IPTABLES_BIN} -D INPUT -i $lan_ifname -p tcp --dport 80 -m mark --mark 103 -j DROP 2> /dev/null
	${IPTABLES_BIN} -D INPUT -i $lan_ifname -p tcp --dport 80 -m mark --mark 104 -j DROP 2> /dev/null

	${IPTABLES_BIN} -D INPUT -i $lan_ifname -p tcp --dport 80 -m mark --mark 100 -m log --log-prefix "FILTER HTTP Connection denied" --log-type 2 -j DROP 2> /dev/null
	${IPTABLES_BIN} -D INPUT -i $lan_ifname -p tcp --dport 80 -m mark --mark 101 -m log --log-prefix "FILTER HTTP Connection denied" --log-type 2 -j DROP 2> /dev/null
	${IPTABLES_BIN} -D INPUT -i $lan_ifname -p tcp --dport 80 -m mark --mark 102 -m log --log-prefix "FILTER HTTP Connection denied" --log-type 2 -j DROP 2> /dev/null
	${IPTABLES_BIN} -D INPUT -i $lan_ifname -p tcp --dport 80 -m mark --mark 103 -m log --log-prefix "FILTER HTTP Connection denied" --log-type 2 -j DROP 2> /dev/null
	${IPTABLES_BIN} -D INPUT -i $lan_ifname -p tcp --dport 80 -m mark --mark 104 -m log --log-prefix "FILTER HTTP Connection denied" --log-type 2 -j DROP 2> /dev/null
	echo
	return $RETVAL
}


case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL
