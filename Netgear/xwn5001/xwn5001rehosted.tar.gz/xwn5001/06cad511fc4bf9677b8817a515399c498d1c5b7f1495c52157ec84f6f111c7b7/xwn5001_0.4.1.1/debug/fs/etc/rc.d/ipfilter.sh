#!/bin/sh

#[ -f /bin/iptables ] || exit 0

RETVAL=0

#iptables="iptables"
lan_if=`nvram get lan_ifname`
wan_if=`nvram get wan_ifname`
IPF_TBL=fwd_block_svc
LogIPFilterEnable=`nvram get LogIPFilterEnable`

start() 
{
	for item in `nvram show | grep ^IPFilter | awk -F"=" '{print $1}'`
	do
		ipf_entry=`nvram get $item`
		ipf_op=`echo $ipf_entry | awk -F";" '{print $1}' | awk -F"=" '{print $2}'`
		#[ "$ipf_op" = "0" ] && continue

		ipf_dir=`echo $ipf_entry | awk -F";" '{print $2}' | awk -F"=" '{print $2}'`
		ipf_srcip=`echo $ipf_entry | awk -F";" '{print $3}' | awk -F"=" '{print $2}'`
		ipf_dstip=`echo $ipf_entry | awk -F";" '{print $4}' | awk -F"=" '{print $2}'`
		ipf_proto=`echo $ipf_entry | awk -F";" '{print $5}' | awk -F"=" '{print $2}'`
		ipf_port=`echo $ipf_entry | awk -F";" '{print $6}' | awk -F"=" '{print $2}'`

		if [ "$ipf_op" = "0" ]; then
			OP_ACT="DROP"
			log_act="Dropped"
		elif [ "$ipf_op" = "1" ]; then
			OP_ACT="ACCEPT"
			log_act="Accepted"
		elif [ "$ipf_op" = "2" ]; then
			OP_ACT="REJECT --reject-with icmp-port-unreachable"
			log_act="Rejected"
		fi

		if [ "$ipf_dir" = "1" ]; then			#dir=1 means LAN->WAN
			DIR_ACT=" -i $lan_if -o $wan_if"	
		else
			DIR_ACT=" -i $wan_if -o $lan_if"	
		fi

		if [ "$ipf_srcip" != "" ]; then
			SRC_ACT=" -s $ipf_srcip"
		else
			SRC_ACT=""
		fi

		if [ "$ipf_dstip" != "" ]; then
			DST_ACT=" -d $ipf_dstip"
		else
			DST_ACT=""
		fi

		if [ "$ipf_proto" = "all" ] || [ "$ipf_proto" = "icmp" ]; then
			PROTO_ACT=" -p $ipf_proto"
			isTCPUDP=0	
		elif [ "$ipf_proto" = "tcp" ] || [ "$ipf_proto" = "udp" ]; then
			hasDash=`echo $ipf_port | grep "-"`
			if [ "$hasDash" != "" ]; then
				p1=`echo $ipf_port | awk -F"-" '{print $1}'`
				p2=`echo $ipf_port | awk -F"-" '{print $2}'`
				PROTO_ACT=" -p $ipf_proto --dport $p1:$p2"
			else
				PROTO_ACT=" -p $ipf_proto --dport $ipf_port"
			fi
			isTCPUDP=0
		else
			PROTO_ACT=" -p $ipf_proto"
			isTCPUDP=0
		fi

		if [ "$LogIPFilterEnable" = "1" ]; then
			LOG_ACT="-m log --log-prefix"
			prefix_message="FILTER $log_act proto $ipf_proto"
		fi

		if [ "$isTCPUDP" = "0" ]; then
			if [ "$LogIPFilterEnable" = "1" ]; then
				if [ "$ipf_op" = "1" ]; then
					iptables -A $IPF_TBL $DIR_ACT $SRC_ACT $DST_ACT $PROTO_ACT -j $OP_ACT
				else
					iptables -A $IPF_TBL $DIR_ACT $SRC_ACT $DST_ACT $PROTO_ACT $LOG_ACT "$prefix_message" -j $OP_ACT
				fi
			else
				iptables -A $IPF_TBL $DIR_ACT $SRC_ACT $DST_ACT $PROTO_ACT -j $OP_ACT
			fi		
		else
			if [ "$LogIPFilterEnable" = "1" ]; then
				if [ "$ipf_op" = "1" ]; then
					iptables -A $IPF_TBL $DIR_ACT $SRC_ACT $DST_ACT -p tcp $PROTO_ACT -j $OP_ACT
					iptables -A $IPF_TBL $DIR_ACT $SRC_ACT $DST_ACT -p udp $PROTO_ACT -j $OP_ACT
				else
					iptables -A $IPF_TBL $DIR_ACT $SRC_ACT $DST_ACT -p tcp $PROTO_ACT $LOG_ACT "$prefix_message" -j $OP_ACT
					iptables -A $IPF_TBL $DIR_ACT $SRC_ACT $DST_ACT -p udp $PROTO_ACT $LOG_ACT "$prefix_message" -j $OP_ACT
				fi
			else
				iptables -A $IPF_TBL $DIR_ACT $SRC_ACT $DST_ACT -p tcp $PROTO_ACT -j $OP_ACT
				iptables -A $IPF_TBL $DIR_ACT $SRC_ACT $DST_ACT -p udp $PROTO_ACT -j $OP_ACT

			fi
		fi
	done
}


stop() {
	iptables -F $IPF_TBL
}


case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

