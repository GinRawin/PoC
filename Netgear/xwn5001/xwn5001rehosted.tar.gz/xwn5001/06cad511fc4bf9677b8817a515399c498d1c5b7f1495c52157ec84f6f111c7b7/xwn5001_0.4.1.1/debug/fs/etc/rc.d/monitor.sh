#!/bin/sh

UDHCPD_INIT_PROG="/etc/rc.d/udhcpd.sh"
DHCPRELAY_INIT_PROG="/etc/rc.d/dhcprelay.sh"
DNSMASQ_INIT_PROG="/etc/rc.d/dnsmasq.sh"
NTPCLIENT_INIT_PROG="/etc/rc.d/ntpclient.sh"
UPNP_INIT_PROG="/etc/rc.d/upnp.sh"
SYSLOGD_INIT_PROG="/etc/rc.d/syslogd.sh"
DROPBEAR_INIT_PROG="/etc/rc.d/dropbear.sh"
TELNETD_INIT_PROG="/etc/rc.d/telnetd.sh"
SNMPD_INIT_PROG="/etc/rc.d/snmpd.sh"
RIPD_INIT_PROG="/etc/rc.d/ripd.sh"
TR069_AGENT_PROG="/etc/rc.d/tr069-agent.sh"
SIP_ALG_PROG="/etc/rc.d/sip_alg.sh"
WAN_START_PROG="/etc/rc.d/wan_start.sh"
IGMPPROXY_PROG="/etc/rc.d/igmpproxy.sh"
UDHCPD_PROG="/etc/rc.d/udhcpd.sh"    # use for relay agent 
log_file="/var/log/messages"

ddns_force_update_check()
{
	ddns_enable=`nvram get ddns_enable`
	if [ "$ddns_enable" != 1 ]; then
		return 0;
	fi

    if [ ! -f /tmp/ddns_force_update ]; then
        	return 0;
	fi

	#if WAN is not connected, return 0
	wan_ipaddr=`nvram get wan0_ipaddr`
	if [ "$wan_ipaddr" = "" ]; then
		return 0
	fi

	read last_update < /tmp/ddns_force_update
	current_time=`cat /proc/uptime| cut -d "." -f 1`

	#echo "==== last_update=$last_update, current_time=$current_time ====" //test
	if [ $current_time -ge $(($last_update + 86400)) ]; then			#force update if 
		echo $current_time > /tmp/ddns_force_update
		/etc/rc.d/wan_ddns.sh start
	fi
}

while true; do
	#action=`nvram get action`
   	wl1_action=`nvram get wl1_action`
	restore_enable=`nvram get restore_defaults`
	firmware=`nvram get fw_tmpfile`
	startPos=`nvram get fw_startPos`
	endPos=`nvram get fw_endPos`
	blk_site_enable=`nvram get bs_url_filter_enabled`
	#blk_site_enable=`nvram get block_skeyword`
	blk_svc_enable=`nvram get blockserv_ctrl`
	wan_ip=`nvram get wan0_ipaddr`
   lan_proto=`nvram get lan_proto`

	
	# action = 1 -> Reboot
	# 	 = 2 -> Restart
	#	 = 3 -> restart when ip-up (dhcpc, ppp)
   	# wl1_action = 1 -> start wireless 

	if [ "$restore_enable" = "1" ]; then
		sleep 2
		echo "Restore Default settings..."
		nvram unset restore_defaults

		if [ "EU" = "`nvram get region_boardinfo`" ];then
			cp -f /etc/nvram_eu/nvram.config /tmp/configs/nvram.config
		else
			cp -f /etc/nvram/nvram.config /tmp/configs/nvram.config
        	#echo "auth_reboot=1" >> /tmp/configs/nvram.config
        	#echo "auth_ip=`nvram get auth_ip`" >> /tmp/configs/nvram.config
		fi
		commit
		reboot
	fi
	
	#action=`nvram get action`
	#nvram unset action
	action=`nvram get _action_`
	if [ -n "$action" ]; then
		for i in $action 
		do 
			if [ "$i" = "1" ]; then
				echo "Reboot..........."
				sleep 2
				#auth_reboot=1 means an authorized host reboots this machine.a
				#auth_reboot will be use in boa
				
				if [ "`nvram get auth_reboot`" != "xxxx" ]; then
                                	nvram set auth_reboot=1
					echo "auth_reboot=1"
				else
					nvram unset auth_ip
                                	nvram unset auth_reboot
				fi
				nvram commit
				/etc/rc.d/wan_start.sh stop
				#reboot
				[ -f /tmp/reboot ] && /tmp/reboot || /sbin/reboot
			elif [ "$i" = "2" ]; then
				echo "Restart..........."
				echo 0 > /proc/sys/net/ipv4/ip_forward
				${WAN_START_PROG} stop
				/etc/rc.d/lan_start.sh
				${UDHCPD_INIT_PROG} stop
				${DNSMASQ_INIT_PROG} stop
				#${SYSLOGD_INIT_PROG} stop
				#${UPNP_INIT_PROG} stop
				${RIPD_INIT_PROG} stop
				${NTPCLIENT_INIT_PROG} stop
				#${SIP_ALG_PROG} stop
				#${IGMPPROXY_PROG} stop

				#/etc/rc.d/resetbutton.sh restart
				#/etc/rc.d/routing.sh start
				if [ "`nvram get router_disable`" = "0" ]; then
					${RIPD_INIT_PROG} start
				fi

				nvram commit

			elif [ "$i" = "3" ]; then
				iface="0"
				if [ "`nvram get wan${iface}_ipaddr`" != "" ]; then

					logger -- "[Internet connected] IP address: $wan_ip,"
					${DNSMASQ_INIT_PROG} restart
					#/etc/rc.d/start_firewall_1.sh
					#/etc/rc.d/start_firewall_2.sh
					#/etc/rc.d/netstar.sh restart    # user for IO-DATA project
				# this script first clean all ebtables rull and then do the pppoe passthrough and selective bridging traffic
					#if [ -e /tmp/upnp_portmap ]; then
        	#   				rm -f /tmp/upnp_portmap
	        #			fi
					${UPNP_INIT_PROG} restart
					#/etc/rc.d/resetbutton.sh restart


					#/etc/rc.d/ipfilter.sh restart		# -> Security-> ip filter
					/etc/rc.d/httpaccess.sh restart		# -> Admin -> Access
					#/etc/rc.d/wifi_separate.sh restart	
					#/etc/rc.d/routing.sh restart
               				# RIP function support WAN port
					if [ "`nvram get router_disable`" = "0" ]; then   # not AP mode
						${RIPD_INIT_PROG} restart
					fi
					#${SIP_ALG_PROG} start
					#${IGMPPROXY_PROG} restart
					#/etc/rc.d/ntpclient.sh restart
					if [ "`nvram get TimerSettingAuto`" = "1" ]; then
						${NTPCLIENT_INIT_PROG} restart
					fi

					#/etc/rc.d/pppoe_passthrough.sh	
					#/etc/rc.d/vpn_passthru.sh restart	
					# WAN LED indicator
					#ledcontrol -n wan -c green -s on
					#ledcontrol -n wan -c amber -s off
					
						# for temporary only
						#iptables -I INPUT -i br0 -j ACCEPT
			  	else 
				# this script first clean all ebtables rull and then do the pppoe passthrough and selective bridging traffic
               echo ""
					#${SIP_ALG_PROG} start
   		  		fi
           			#nvram commit
         		elif [ "$i" = "4" ]; then
				action_script=`nvram get action_script`
				nvram unset action_script
				if [ ! $action_script = "" ]; then
					$action_script
				fi

			elif [ "$i" = "5" ]; then
				nvram commit

			elif [ "$i" = "7" ]; then
          			#/etc/rc.d/eco.sh restore
          			/etc/rc.d/cmdsched.sh start eco
          	elif [ "$i" = "8" ]; then
          		#for inspection
				/usr/sbin/telnetd -l /bin/ash &
			else
				#check 6:script
				local act=`echo $i | awk -F\: '{print $1}'`
				local script=`echo $i | awk -F\: '{print $2}'`
				local commit=`echo $i | awk -F\: '{print $3}'`
 
            			if [ "$act" = "6" -a -n "$script" ]; then
               				if [ "$script" = "tftpdstart" ]; then
                  				echo "start tftpd"
                  				#/usr/sbin/in.tftpd -v -i /etc/tftpserver.ini &
                  				#nvram set action=6:tftpdstop
               				elif [ "$script" = "tftpdstop" ]; then
                  				echo "stop tftpd"
                  				killall in.tftpd
                  			#kenny.w added
	                  		elif [ "$script" = "snmpfwupgradestart" ]; then   
                  				echo "snmp firmware upgrade start"
                  				/etc/rc.d/snmp_fw_upgrade.sh
                  			#end of added
               				else 
		  				if [ "x$commit" != "x" -a "$commit" != "0" ]; then	
                  					nvram commit
		  				fi	
                  				${script} restart	
               				fi
				fi
			fi	
	
		done	
	fi	
		
	
#wscd config ap,  restart wlan	
	if [ -e /tmp/reinitwscd ]; then
	       rm /tmp/reinitwscd
	       /etc/rc.d/wlan.sh restart
	       
	fi	
	
#upnp, request connection, start wan
		if [ -e /tmp/upnp_wan_restart ]; then
	       rm /tmp/upnp_wan_restart
		   sleep 1
		   echo "upnp request connection!!" > /dev/console
	       /sbin/cmdwan.sh start
	       
	fi
	       
	       
	#/etc/rc.d/urlfilter.sh check
	#ddns_force_update_check

	#To do check log entries <= 256 
	#/etc/rc.d/check_log_len.sh
					
	#/etc/rc.d/sleep.sh 7
	#If another action is waitting, do not run "alarm",
	#run another action directly
	if [ "`nvram get action`" = "" ]; then
		/sbin/alarm 0
	fi
done

