cd /

/sbin/httpd  

