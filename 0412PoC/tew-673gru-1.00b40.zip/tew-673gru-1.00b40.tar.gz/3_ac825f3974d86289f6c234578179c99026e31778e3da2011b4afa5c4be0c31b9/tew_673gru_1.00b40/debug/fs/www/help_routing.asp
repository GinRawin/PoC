<HTML>
<HEAD>
<!-- $MVD$:app("RoboHELP HTML Edition by Blue Sky Software, portions by MicroVision Dev. Inc.","769") -->
<!-- $MVD$:template("","0","0") -->
<!-- $MVD$:fontset("Arial","Arial") -->
<!-- $MVD$:fontset("Times New Roman","Times New Roman") -->
<!-- $MVD$:fontset("Arial Narrow","Arial Narrow") -->
<TITLE>Routing</TITLE>
<link rel="stylesheet" href="style.css" type="text/css"><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script type="text/javascript">
<!--
function MM_preloadImages() { //v3.0
var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
function MM_swapImgRestore() { 
var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_findObj(n, d) { 
var p,i,x; if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
if(!x && d.getElementById) x=d.getElementById(n); return x;
}
function MM_swapImage() { 
var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
-->
</script>
</HEAD>
<BODY onLoad="MM_preloadImages('but_help_access_1.gif','but_help_main_1.gif','but_management_1.gif','but_help_routing_1.gif','but_help_status_1.gif','but_tools_1.gif','but_help_wireless_1.gif')">
<table width="750" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="21"><img src="c1_tl.gif" width="21" height="21" /></td>
<td width="708" background="bg1_t.gif"><img src="top_1.gif" width="390" height="21" /></td>
<td width="21"><img src="c1_tr.gif" width="21" height="21" /></td>
</tr>
<tr>
<td valign="top" background="bg1_l.gif"><img src="top_2.gif" width="21" height="69" /></td>
<td background="bg.gif"><table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="13%"><img src="logo.gif" width="270" height="69" /></td>
<td width="87%" align="right"><img src="description.gif" /></td>
</tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="20%" height="429" valign="top"><table width="100%" border="0" align="center" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><b>Help</b></td>
</tr>
<tr>
<td bgcolor="#000000" ><table width="56%" border="0" cellpadding="0" cellspacing="0" bgcolor="#1D1D1D">
<tr>
<td><a href="help_main.asp"><img src="but_help_main_0.gif" name="Image2" width="155" height="27" border="0" id="Image2" onmouseover="MM_swapImage('Image2','','but_help_main_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_wlan.asp"><img src="but_help_wireless_0.gif" name="Image31" width="155" height="27" border="0" id="Image31" onmouseover="MM_swapImage('Image31','','but_help_wireless_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_status.asp"><img src="but_help_status_0.gif" name="Image23" width="155" height="27" border="0" id="Image23" onmouseover="MM_swapImage('Image23','','but_help_status_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_routing.asp"><img src="but_help_routing_1.gif" name="Image30" width="155" height="27" border="0" id="Image22" onmouseover="MM_swapImage('Image30','','but_help_routing_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="2" >
<tr>
<td width="13%" align="right"><font color="#FFFFFF">&bull;</font></td>
<td width="87%"><b><a href="help_routing.asp#routing_static" class="submenus">Static</a><a href="help_access.asp#access_user_group" class="submenus"></a></b></td>
</tr>
<!--<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="inbound_filter.asp" class="submenus"><b>Inbound Filter </b></a></td>
</tr>-->
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><b><a href="help_routing.asp#routing_dynamic" class="submenus">Dynamic</a><a href="help_access.asp#access_url_group" class="submenus"></a></b></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><b><a href="help_routing.asp#routing_routing_table" class="submenus">Routing Table</a><a href="help_access.asp#access_ip_filter" class="submenus"></a></b></td>
</tr>
</table></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_access.asp"><img src="but_help_access_0.gif" name="Image24" width="155" height="27" border="0" id="Image24" onmouseover="MM_swapImage('Image24','','but_help_access_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_manage.asp"><img src="but_management_0.gif" name="Image21" width="155" height="27" border="0" id="Image21" onmouseover="MM_swapImage('Image21','','but_management_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_tools.asp"><img src="but_tools_0.gif" name="Image1" width="155" height="27" border="0" id="Image1" onmouseover="MM_swapImage('Image1','','but_tools_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
</table></td>
</tr>
</table>
<p></p>
<p>&nbsp;</p>
<p>&nbsp;</p></td>
<td width="2%"><img src="spacer.gif" width="10" height="15" /></td>
<td width="78%" valign="top"><table width="550" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">Routing</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>This page enables you to set how the router forwards data.</P>
<P> Click the items below for more information:</P>
<UL>
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet"> <b><A HREF="#routing_static">Static</A></b></P>
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet"> <b><A HREF="#routing_dynamic">Dynamic</A></b></P>
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet"> <b><A HREF="#routing_routing_table">Routing Table</A></b></P>
</UL></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br> <a name="routing_static"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">Static</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>This screen enables you to set parameters by which the router
forwards data to its destination if your network has a static <A HREF="glossary.asp#def_ip_address">IP
address</A>.</P>
<P> <SPAN STYLE="font-weight : bold;">Network Address:</SPAN><A NAME="routing_static_network_address"></A> Type the static <A HREF="glossary.asp#def_ip_address">IP address</A> your network uses to access the Internet. Your <A HREF="glossary.asp#def_ISP">ISP</A> or network <A HREF="glossary.asp#def_administrator">administrator</A> provides you with this information.</P>
<P> <SPAN STYLE="font-weight : bold;">Network Mask:</SPAN><A NAME="routing_static_network_mask"></A> Type the <A HREF="glossary.asp#def_subnet_mask">network (subnet) mask</A> for your network. If you do not type a value here, the network mask
defaults to 255.255.255.255. Your <A HREF="glossary.asp#def_ISP">ISP</A> or network <A HREF="glossary.asp#def_administrator">administrator</A> provides you with this information.</P>
<P> <SPAN STYLE="font-weight : bold;">Gateway Address:</SPAN><A NAME="routing_static_gateway_address"></A> Type the <A HREF="glossary.asp#def_gateway">gateway address</A> for
your network. Your <A HREF="glossary.asp#def_ISP">ISP</A> or network <A HREF="glossary.asp#def_administrator">administrator</A> provides you with this information.</P>
<P> <SPAN STYLE="font-weight : bold;">Interface:</SPAN><A NAME="routing_static_interface"></A> Select which interface, <A HREF="glossary.asp#def_WAN">WAN</A> or <A HREF="glossary.asp#def_LAN">LAN</A>,
you use to connect to the Internet.</P>
<P> <SPAN STYLE="font-weight : bold;">Metric:</SPAN><A NAME="routing_static_metric"></A> Select which <A HREF="glossary.asp#def_metric">metric</A> you want to
apply to this configuration.</P>
<P> <SPAN STYLE="font-weight : bold;">Add:</SPAN><A NAME="routing_static_add"></A> Click to add the configuration to the static <A HREF="glossary.asp#def_ip_address">IP
address</A> table at the bottom of the page.</P>
<P> <SPAN STYLE="font-weight : bold;">Update:</SPAN><A NAME="routing_static_update"></A> Select one of the entries in the static <A HREF="glossary.asp#def_ip_address">IP
address</A> table at the bottom of the page and, after changing
parameters, click <SPAN STYLE="font-style : italic;">Update</SPAN> to
confirm the changes.</P>
<P> <SPAN STYLE="font-weight : bold;">Delete:</SPAN><A NAME="routing_static_delete"></A> Select one of the entries in the static <A HREF="glossary.asp#def_ip_address">IP
address</A> table at the bottom of the page and click <SPAN STYLE="font-style : italic;">Delete</SPAN> to remove the entry.</P>
<P><strong>Cancel: </strong> Click the Cancel button to erase all fields and enter new information. </P>
<P> <A HREF="help_routing.asp">back to top</A></P></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br> <a name="routing_dynamic"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">Dynamic</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P><SPAN STYLE="font-weight : bold;">Transmit:</SPAN><A NAME="routing_dynamic_transmit"></A> Click the radio buttons to set the desired transmit parameters,
disabled, <A HREF="glossary.asp#def_RIP">RIP</A> 1, or <A HREF="glossary.asp#def_RIP">RIP</A> 2.</P>
<P> <SPAN STYLE="font-weight : bold;">Receive:</SPAN><A NAME="routing_dynamic_receive"></A> Click the radio buttons to set the desired transmit parameters,
disabled, <A HREF="glossary.asp#def_RIP">RIP</A> 1, or <A HREF="glossary.asp#def_RIP">RIP</A> 2.</P>
<P> <A HREF="help_routing.asp">back to top</A></P></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br> <a name="routing_routing_table"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">Routing Table</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>This screen enables you to view the routing table for the router. The
routing table is a database created by the router that displays the
network interconnection topology.</P>
<P> <SPAN STYLE="font-weight : bold;">Network Address:</SPAN><A NAME="routing_table_network_address"></A> Displays the network <A HREF="glossary.asp#def_ip_address">IP address</A> of the connected node.</P>
<P> <SPAN STYLE="font-weight : bold;">Network Mask:</SPAN><A NAME="routing_table_network_mask"></A> Displays the <A HREF="glossary.asp#def_subnet_mask">network (subnet) mask</A> of the connected node.</P>
<P> <SPAN STYLE="font-weight : bold;">Gateway Address:</SPAN><A NAME="routing_table_gateway_address"></A> Displays the <A HREF="glossary.asp#def_gateway">gateway address</A> of the connected node.</P>
<P> <SPAN STYLE="font-weight : bold;">Interface:</SPAN><A NAME="routing_table_interface"></A> Displays whether the node is connected via a <A HREF="glossary.asp#def_WAN">WAN</A> or <A HREF="glossary.asp#def_LAN">LAN </A>or WAN Physical.</P>
<P> <SPAN STYLE="font-weight : bold;">Metric:</SPAN><A NAME="routing_table_metric"></A> Displays the <A HREF="glossary.asp#def_metric">metric</A> of the
connected node.</P>
<P> <SPAN STYLE="font-weight : bold;">Type:</SPAN><A NAME="routing_table_type"></A> Displays whether the node has a static or dynamic <A HREF="glossary.asp#def_ip_address">IP
address</A>.</P>
<P> <A HREF="help_routing.asp">back to top</A></P></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br></td>
</tr>
</table></td>
<td background="bg1_r.gif">&nbsp;</td>
</tr>
<tr>
<td><img src="c1_bl.gif" width="21" height="20" /></td>
<td align="right" background="bg1_b.gif"><img src="copyright.gif" width="264" height="20" /></td>
<td><img src="c1_br.gif" width="21" height="20" /></td>
</tr>
</table>
</BODY>
</HTML>