<HTML>
<HEAD>
<!-- $MVD$:app("RoboHELP HTML Edition by Blue Sky Software, portions by MicroVision Dev. Inc.","769") -->
<!-- $MVD$:template("","0","0") -->
<!-- $MVD$:fontset("Arial","Arial") -->
<!-- $MVD$:fontset("Times New Roman","Times New Roman") -->
<!-- $MVD$:fontset("Arial Narrow","Arial Narrow") -->
<TITLE>Glossary</TITLE>
<link rel="stylesheet" href="style.css" type="text/css">
<script type="text/javascript">
<!--
function MM_preloadImages() { //v3.0
var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
function MM_swapImgRestore() { 
var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_findObj(n, d) { 
var p,i,x; if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
if(!x && d.getElementById) x=d.getElementById(n); return x;
}
function MM_swapImage() { 
var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}

</script>
</HEAD>
<BODY bgcolor=#FFFFFF onLoad="MM_preloadImages('but_help_access_1.gif','but_help_main_1.gif','but_help_management_1.gif','but_help_routing_1.gif','but_help_status_1.gif','but_help_tools_1.gif','but_help_wireless_1.gif')">
<table width="750" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="21"><img src="c1_tl.gif" width="21" height="21" /></td>
<td width="708" background="bg1_t.gif"><img src="top_1.gif" width="390" height="21" /></td>
<td width="21"><img src="c1_tr.gif" width="21" height="21" /></td>
</tr>
<tr>
<td valign="top" background="bg1_l.gif"><img src="top_2.gif" width="21" height="69" /></td>
<td background="bg.gif"><table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="13%"><img src="logo.gif" width="270" height="69" /></td>
<td width="87%" align="right"><img src="description.gif" /></td>
</tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="20%" height="429" valign="top"><table width="100%" border="0" align="center" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><b>Help</b></td>
</tr>
<tr>
<td bgcolor="#000000" ><table width="56%" border="0" cellpadding="0" cellspacing="0" bgcolor="#1D1D1D">
<tr>
<td><a href="help_access.asp"><img src="but_help_access_0.gif" name="Image24" width="155" height="27" border="0" id="Image24" onmouseover="MM_swapImage('Image24','','but_help_access_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_main.asp"><img src="but_help_main_0.gif" name="Image2" width="155" height="27" border="0" id="Image2" onmouseover="MM_swapImage('Image2','','but_help_main_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_manage.asp"><img src="but_help_management_0.gif" name="Image21" width="155" height="27" border="0" id="Image21" onmouseover="MM_swapImage('Image21','','but_help_management_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_routing.asp"><img src="but_help_routing_0.gif" name="Image30" width="155" height="27" border="0" id="Image22" onmouseover="MM_swapImage('Image30','','but_help_routing_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_status.asp"><img src="but_help_status_0.gif" name="Image23" width="155" height="27" border="0" id="Image23" onmouseover="MM_swapImage('Image23','','but_help_status_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_tools.asp"><img src="but_help_tools_0.gif" name="Image1" width="155" height="27" border="0" id="Image1" onmouseover="MM_swapImage('Image1','','but_help_tools_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_wlan.asp"><img src="but_help_wireless_0.gif" name="Image31" width="155" height="27" border="0" id="Image31" onmouseover="MM_swapImage('Image31','','but_help_wireless_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
</table></td>
</tr>
</table>
<p></p>
<p>&nbsp;</p>
<p>&nbsp;</p></td>
<td width="2%"><img src="spacer.gif" width="10" height="15" /></td>
<td width="78%" valign="top"><table width="550" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2">Glossary</td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><p><span class="bluetextbold3">Access Point<A NAME="def_access_point"></A><br>
</span>Access points are way stations in a wireless LAN that are connected
to an Ethernet hub or server. Users can roam within the range of
access points and their wireless device connections are passed from
one access point to the next.</p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">Authentication<A NAME="def_authentication"></A><br>
</span>Authentication refers to the verification of a transmitted message's integrity.</p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">DMZ<A NAME="def_DMZ"></A><br>
</span>DMZ (DeMilitarized Zone) is a part of an network that is located
between a secure LAN and an insecure WAN. DMZs provide a way for some
clients to have unrestricted access to the Internet.</p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">Beacon Interval<A NAME="def_beacon_interval"></A><br>
</span>Refers to the interval between packets sent sent by access points for
the purposes of synchronizing wireless LANs.</p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">DHCP<A NAME="def_dhcp"></A><br>
</span>DHCP (Dynamic Host Configuration Protocol) software automatically
assigns IP addresses to client stations logging onto a TCP/IP
network, which eliminates the need to manually assign permanent IP addresses.</p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">DNS<A NAME="def_DNS"></A><br>
</span>DNS stands for Domain Name System. DNS converts machine names to the
IP addresses that all machines on the net have. It translates from
name to address and from address to name. </p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">Domain Name<A NAME="def_domain_name"></A><br>
</span>The domain name typically refers to an Internet site address.</p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">DTIM<A NAME="def_DTIM"></A><br>
</span>DTIM (Delivery Traffic Indication Message) provides client stations
with information on the next opportunity to monitor for broadcast or
multicast messages. </p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">Filter<A NAME="def_filter"></A><br>
</span>Filters are schemes which only allow specified data to be
transmitted. For example, the router can filter specific IP addresses
so that users cannot connect to those addresses.</p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">Firewall<A NAME="def_firewall"></A><br>
</span>Firewalls are methods used to keep networks secure from malicious
intruders and unauthorized access. Firewalls use filters to prevent
unwanted packets from being transmitted. Firewalls are typically used
to provide secure access to the Internet while keeping an
organization's public Web server separate from the internal LAN. </p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">Firmware<A NAME="def_firmware"></A><br>
</span>Firmware refers to memory chips that retain their content without
electrical power (for example, BIOS ROM). The router firmware stores
settings made in the interface.</p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">Fragmentation<A NAME="def_fragmentation"></A><br>
</span>Refers to the breaking up of data packets during transmission. </p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">FTP<A NAME="def_FTP"></A><br>
</span>FTP (File Transfer Protocol) is used to transfer files over a TCP/IP
network, and is typically used for transferring large files or
uploading the HTML pages for a Web site to the Web server.</p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">Gateway<a name="def_gateway"></a><br>
</span>Gateways are computers that convert protocols enabling different
networks, applications, and operating systems to exchange information. </p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">Host Name<A NAME="def_host_name"></A><br>
</span>The name given to a computer or client station that acts as a source
for information on the network.</p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">HTTP<A NAME="def_HTTP"></A><br>
</span>HTTP (HyperText Transport Protocol) is the communications protocol
used to connect to servers on the World Wide Web. HTTP establishes a
connection with a Web server and transmits HTML pages to client
browser (for example Windows IE). HTTP addresses all begin with the
prefix 'http://' prefix (for example, <SPAN STYLE="font-style : italic;">http://www.trendnet.com</SPAN>). </p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">ICMP<A NAME="def_ICMP"></A><br>
</span>ICMP (Internet Control Message Protocol) is a TCP/IP protocol used to
send error and control messages over the LAN (for example, it is used
by the router to notify a message sender that the destination node is
not available).</p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">IP<A NAME="def_IP"></A><br>
</span>IP (Internet Protocol) is the protocol in the TCP/IP communications
protocol suite that contains a network address and allows messages to
be routed to a different network or subnet. However, IP does not
ensure delivery of a complete message&#151;TCP provides the function
of ensuring delivery. </p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">IP Address<A NAME="def_ip_address"></A><br>
</span>The IP (Internet Protocol) address refers to the address of a
computer attached to a TCP/IP network. Every client and server
station must have a unique IP address. Clients are assigned either a
permanent address or have one dynamically assigned to them via DHCP.
IP addresses are written as four sets of numbers separated by periods
(for example, 211.23.181.189).</p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">ISP<A NAME="def_ISP"></A><br>
</span>An ISP is an organization providing Internet access service via
modems, ISDN (Integrated Services Digital Network), and private lines.</p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">LAN<A NAME="def_LAN"></A><br>
</span>LANs (Local Area Networks) are networks that serve users within
specific geographical areas, such as in a company building. LANs are
comprised of servers, workstations, a network operating system, and
communications links such as the router. </p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">MAC Address<A NAME="def_MAC_address"></A><br>
</span>A MAC address is a unique serial number burned into hardware
adapters, giving the adapter a unique identification.</p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">Metric<A NAME="def_metric"></A><br>
</span>A number that indicates how long a packet takes to get to its destination. </p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">MTU<a name="def_MTU"></a><br>
</span>MTU (Maximum Transmission/Transfer Unit) is the largest packet size
that can be sent over a network. Messages larger than the MTU are
divided into smaller packets.</p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">(Network) Administrator<A NAME="def_administrator"></A><br>
</span>The network administrator is the person who manages the LAN within an
organization. The administrator's job includes ensuring network
security, keeping software, hardware, and firmware up-to-date, and
keeping track of network activity.</p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">NTP<A NAME="def_NTP"></A><br>
</span>NTP (Network Time Protocol) is used to synchronize the realtime clock
in a computer. Internet primary and secondary servers synchronize to
Coordinated Universal Time (UTC). </p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">Packet<A NAME="def_packet"></A><br>
</span>A packet is a portion of data that is transmitted in network
communications. Packets are also sometimes called frames and
datagrams. Packets contain not only data, but also the destination IP address.</p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">Ping<A NAME="def_Ping"></A><br>
</span>Ping (Packet INternet Groper) is a utility used to find out if a
particular IP address is present online, and is usually used by
networks for debugging. </p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">Port<A NAME="def_port"></A><br>
</span>Ports are the communications pathways in and out of computers and
network devices (routers and switches). Most PCs have serial and
parallel ports, which are external sockets for connecting devices
such as printers, modems, and mice. All network adapters use ports to
connect to the LAN. Ports are typically numbered.</p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">PPPoE<A NAME="def_PPPoE"></A><br>
</span>PPPoE (Point-to-Point Protocol Over Ethernet) is used for running PPP
protocol (normally used for dial-up Internet connections) over an Ethernet. </p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">Preamble<A NAME="def_preamble"></A><br>
</span>Preamble refers to the length of a CRC (Cyclic Redundancy Check)
block that monitors communications between roaming wireless enabled
devices and access points.</p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">Protocol<A NAME="def_protocol"></A><br>
</span>A protocol is a rule that governs the communication of data. </p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">RIP<A NAME="def_RIP"></A><br>
</span>RIP (Routing Information Protocol) is a routing protocol that is
integrated in the TCP/IP protocol. RIP finds a route that is based on
the smallest number of hops between the source of a packet and its destination.</p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">RTS<A NAME="def_RTS"></A><br>
</span>RTS (Request To Send) is a signal sent from the transmitting station
to the receiving station requesting permission to transmit data. </p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">Server<A NAME="def_server"></A><br>
</span>Servers are typically powerful and fast machines that store programs
and data. The programs and data are shared by client machines
(workstations) on the network.</p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">SMTP<A NAME="def_SMTP"></A><br>
</span>SMTP (Simple Mail Transfer Protocol) is the standard Internet e-mail
protocol. SMTP is a TCP/IP protocol defining message format and
includes a message transfer agent that stores and forwards mail. </p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<P><span class="bluetextbold3">SNMP<A NAME="def_SNMP"></A><br>
</span>SNMP (Simple Network Management Protocol) is a widely used network
monitoring and control protocol. SNMP hardware or software components
transmit network device activity data to the workstation used to
oversee the network. </P>
<P><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></P>
<P><span class="bluetextbold3">SSID<A NAME="def_ssid"></A><br>
</span>SSID (Service Set Identifier) is a security measure used in WLANs.
The SSID is a unique identifier attached to packets sent over WLANs.
This identifier emulates a password when a wireless device attempts
communication on the WLAN. Because an SSID distinguishes WLANS from
each other, access points and wireless devices trying to connect to a
WLAN must use the same SSID. </P>
<P><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></P>
<P><span class="bluetextbold3">Subnet Mask<A NAME="def_subnet_mask"></A><br>
</span>Subnet Masks (SUBNETwork masks) are used by IP protocol to direct
messages into a specified network segment (i.e., subnet). A subnet
mask is stored in the client machine, server or router and is
compared with an incoming IP address to determine whether to accept
or reject the packet. </P>
<P><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></P>
<p><span class="bluetextbold3">SysLog Server<A NAME="def_SysLog_Server"></A><br>
</span>A SysLog server monitors incoming Syslog messages and decodes the
messages for logging purposes.</p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">TCP<A NAME="def_TCP"></A><br>
</span>(Transmission Control Protocol) is the transport protocol in TCP/IP
that ensures messages over the network are transmitted accurately and completely. </p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<P><span class="bluetextbold3">TCP/IP<br>
</span>TCP/IP (Transmission Control Protocol/Internet Protocol) is the main
Internet communications protocol. The TCP part ensures that data is
completely sent and received at the other end. Another part of the
TCP/IP protocol set is UDP, which is used to send data when accuracy
and guaranteed packet delivery are not as important (for example, in
realtime video and audio transmission). </P>
<P> The IP component of TCP/IP provides data routability, meaning that
data packets contain the destination station and network addresses,
enabling TCP/IP messages to be sent to multiple networks within the
LAN or in the WAN.</P>
<P><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></P>
<span class="bluetextbold3">Telnet<A NAME="def_Telnet"></A><br>
</span>Telnet is a terminal emulation protocol commonly used on the Internet
and TCP- or IP-based networks.
<P> Telnet is used for connecting to remote devices and running programs.
Telnet is an integral component of the TCP/IP communications protocol.</P>
<P><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></P>
<P><span class="bluetextbold3">UDP<A NAME="def_UDP"></A><br>
</span>(User Datagram Protocol) is a protocol within TCP/IP that is used to
transport information when accurate delivery isn't necessary (for
example, realtime video and audio where packets can be dumped as
there is no time for retransmitting the data). </P>
<P><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></P>
<P><span class="bluetextbold3">Virtual Servers<A NAME="def_virtual_server"></A><br>
</span>Virtual servers are client servers (such as Web servers) that share
resources with other virtual servers (i.e., it is not a dedicated server). </P>
<P><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></P>
<p><span class="bluetextbold3">WEP<A NAME="def_WEP"></A><br>
</span>WEP (Wired Equivalent Privacy) is the de facto security protocol for
wireless LANs, providing the &quot;equivalent&quot; security
available in hardwired networks.</p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">Wireless LAN<A NAME="def_wireless_lan"></A><br>
</span><SPAN STYLE="font-style : normal;">Wireless LANs (WLANs) </SPAN>are
local area networks that use wireless communications for transmitting
data. Transmissions are usually in the 2.4 GHz band. WLAN devices do
not need to be lined up for communications like infrared devices.
WLAN devices use access points which are connected to the wired LAN
and provide connectivity to the LAN. The radio frequency of WLAN
devices is strong enough to be transmitted through non-metal walls
and objects, and can cover an area up to a thousand feet. Laptops and
notebooks use wireless LAN PCMCIA cards while PCs use plug-in cards
to access the WLAN. </p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">WLAN<A NAME="def_WLAN"></A><br>
</span><SPAN STYLE="font-style : normal;">WLANs (Wireless LANs) </SPAN>are
local area networks that use wireless communications for transmitting
data. Transmissions are usually in the 2.4 GHz band. WLAN devices do
not need to be lined up for communications like infrared devices.
WLAN devices use access points which are connected to the wired LAN
and provide connectivity to the LAN. The radio frequency of WLAN
devices is strong enough to be transmitted through non-metal walls
and objects, and can cover an area up to a thousand feet. Laptops and
notebooks use wireless LAN PCMCIA cards while PCs use plug-in cards
to access the WLAN.</p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<p><span class="bluetextbold3">WAN<font color="#009900"><A NAME="def_WAN"></A></font> </span> <br>
WAN (Wide Area Network) is a communications network that covers a
wide geographic area such as a country (contrasted with a LAN, which
covers a small area such as a company building). </p>
<p><a href="javascript:history.back(-1)">back</a> | <a href="#">top</a></p>
<P>&nbsp;</P></td>
</tr>
</table></td>
</tr>
</table>
</td>
</tr>
</table></td>
<td background="bg1_r.gif">&nbsp;</td>
</tr>
<tr>
<td><img src="c1_bl.gif" width="21" height="20" /></td>
<td align="right" background="bg1_b.gif"><img src="copyright.gif" width="264" height="20" /></td>
<td><img src="c1_br.gif" width="21" height="20" /></td>
</tr>
</table>
<P>&nbsp;</P>
</BODY>
</HTML>
