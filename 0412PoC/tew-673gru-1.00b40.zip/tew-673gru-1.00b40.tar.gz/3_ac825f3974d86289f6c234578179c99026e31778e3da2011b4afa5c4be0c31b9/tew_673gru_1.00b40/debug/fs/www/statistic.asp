<html>
<head>
<meta http-equiv="Content-Type" content="text/html;">
<title>TRENDNET | TEW-673GRU | Status | Statistic</title>
<link rel="stylesheet" href="style.css" type="text/css">
<script language="JavaScript" src="public_msg.js"></script>
<script language="JavaScript" src="public.js"></script>
<script language="JavaScript">
var lan_ifconfig_info ="<% CmoGetStatus("lan_ifconfig_info"); %>";
var wan_ifconfig_info ="<% CmoGetStatus("wan_ifconfig_info"); %>";
var wlan_ifconfig_info ="<% CmoGetStatus("wlan_ifconfig_info"); %>";
var wlan1_ifconfig_info	="<% CmoGetStatus("wlan1_ifconfig_info"); %>";
var lan_stats = lan_ifconfig_info.split("/");
var wan_stats = wan_ifconfig_info.split("/");
var wlan_stats = wlan_ifconfig_info.split("/");
var wlan1_stats = wlan1_ifconfig_info.split("/");
var stats_string1;
function show_send_stats(){
var lsent, lreceived;
var wsent, wreceived;
var wlsent, wlreceived;
var wl1sent, wl1received;

lreceived = lan_stats[0];
lsent = lan_stats[1];	





wreceived = wan_stats[0];
wsent = wan_stats[1];





wlreceived = wlan_stats[0];
wlsent = wlan_stats[1];	




wl1received = wlan1_stats[0];
wl1sent = wlan1_stats[1];	



stats_string1 = '<tr>';
stats_string1 += '<td bgcolor="#F0F0F0" width="85"><b>Send</b></td>';
stats_string1 += '<td width="133" bgcolor="#F0F0F0">'+ lsent +'</td>';
stats_string1 += '<td width="80" bgcolor="#F0F0F0">'+ wsent +'</td>';
stats_string1 += '<td width="129" bgcolor="#F0F0F0">'+ wlsent +'</td>';
stats_string1 += '<td width="129" bgcolor="#F0F0F0">'+ wl1sent +'</td>';
stats_string1 += '</tr>';	
}
function show_recive_stats(){
var lsent, lreceived;
var wsent, wreceived;
var wlsent, wlreceived;
var wl1sent, wl1received;

lreceived = lan_stats[0];
lsent = lan_stats[1];	





wreceived = wan_stats[0];
wsent = wan_stats[1];





wlreceived = wlan_stats[0];
wlsent = wlan_stats[1];	




wl1received = wlan1_stats[0];
wl1sent = wlan1_stats[1];	




stats_string1 = '<tr>';
stats_string1 += '<td bgcolor="#F0F0F0" width="85"><b>Receive</b></td>';
stats_string1 += '<td width="133" bgcolor="#F0F0F0">'+ lreceived +'</td>';
stats_string1 += '<td width="80" bgcolor="#F0F0F0">'+ wreceived +'</td>';
stats_string1 += '<td width="129" bgcolor="#F0F0F0">'+ wlreceived +'</td>';
stats_string1 += '<td width="129" bgcolor="#F0F0F0">'+ wl1received +'</td>';
stats_string1 += '</tr>'; 
}
</script>
</head>
<body onLoad="MM_preloadImages('but_wizard_1.gif','but_status_1.gif','but_tools_1.gif','but_main_1.gif','but_wireless_1.gif','but_routing_1.gif','but_access_1.gif','but_management_1.gif')">
<table width="750" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="21"><img src="c1_tl.gif" width="21" height="21" /></td>
<td width="708" background="bg1_t.gif"><img src="top_1.gif" width="390" height="21" /></td>
<td width="21"><img src="c1_tr.gif" width="21" height="21" /></td>
</tr>
<tr>
<td valign="top" background="bg1_l.gif"><img src="top_2.gif" width="21" height="69" /></td>
<td background="bg.gif"><table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="13%"><img src="logo.gif" width="270" height="69" /></td>
<td width="87%" align="right"><img src="description.gif" /></td>
</tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="20%" height="429" valign="top"><table width="56%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td><a href="lan.asp"><img src="but_main_0.gif" name="Image2" border="0" id="Image2" onMouseOver="MM_swapImage('Image2','','but_main_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="wireless_basic.asp"><img src="but_wireless_0.gif" name="Image3" border="0" id="Image3" onMouseOver="MM_swapImage('Image3','','but_wireless_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a><a href="w_basic.asp"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="status.asp"><img src="but_status_1.gif" name="Image1" border="0" id="Image1" onMouseOver="MM_swapImage('Image1','','but_status_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="2" class="submenubg">
<tr>
<td width="13%" align="right"><font color="#FFFFFF">&bull;</font></td>
<td width="87%"><a href="status.asp" class="submenus"><b>Device Information </b></a></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="log.asp" class="submenus"><b>Log</b></a></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="log_setting.asp" class="submenus"><b>Log Setting </b></a></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="statistic.asp" class="submenus"><b><u>Statistic</u></b></a></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="wla_conn.asp" class="submenus"><b>Wireless</b></a></td>
</tr>
</table></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="static_routing.asp"><img src="but_routing_0.gif" name="Image4" border="0" id="Image4" onMouseOver="MM_swapImage('Image4','','but_routing_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="filters.asp"><img src="but_access_0.gif" name="Image5" border="0" id="Image5" onMouseOver="MM_swapImage('Image5','','but_access_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="remote_management.asp"><img src="but_management_0.gif" border="0" id="Image6" onMouseOver="MM_swapImage('Image6','','but_management_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="restart.asp"><img src="but_tools_0.gif" border="0" id="Image7" onMouseOver="MM_swapImage('Image7','','but_tools_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="#" onClick="show_wizard('wizard.asp')"><img src="but_wizard_0.gif" name="Image71" border="0" id="Image71" onMouseOver="MM_swapImage('Image71','','but_wizard_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="15" height="15"></td>
</tr>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p></td>
<td width="2%"><img src="spacer.gif" width="15" height="15" /></td>
<td width="78%" valign="top"><table width="98%" border="0" cellpadding="0" cellspacing="0" class="tabBigTitle">
<tr>
<td class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%"><font color="#FFFFFF" class="textheader" style="margin-left:0; padding-left:0">Statistic</font></td>
<td width="5%" align="right"><input name="button" type="button" class="ButtonHelp" onclick="MM_openBrWindow('help_status.asp#status_statistic','','scrollbars=yes,resizable=yes,width=800,height=550')" value=" Help " />
</td>
</tr>
</table></td>
</tr>
<tr>
<td valign="top"><table width="98%" border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#333333">
<div class="box"> 
<tr>
<td bgcolor="#CCCCCC"><b>Utilization</b> (bytes)</td>
<td width="85" bgcolor="#CCCCCC"><b>LAN </b></td> 
<td width="88" bgcolor="#CCCCCC"><b>WAN</b></td>
<td width="119" bgcolor="#CCCCCC"><b>Wireless 2.4GHz</b></td>
<td width="111" bgcolor="#CCCCCC"><b>Wireless 5GHz</b></td>
</tr>
</div> 
<div class="box"> 
<script>
show_send_stats();
document.write(stats_string1);
</script>
</div>
<div class="box"> 
<script>
show_recive_stats();
document.write(stats_string1);
</script>
</div>
<div class="box"> 
<tr>
<td bgcolor="#CCCCCC">&nbsp;</td>
<td colspan="4" bgcolor="#DDDDDD"><form id="form1" name="form1" method="post" action="reset_packet_counter.cgi">
<input type="hidden" name="html_response_page" value="statistic.asp">
<input type="hidden" name="html_response_return_page" value="statistic.asp">
<input name="clear" type="submit" class="ButtonSmall" value="Reset">
</form></td>
</tr>
</div>
</table>
<br>
</td>
</tr>
</table></td>
</tr>
</table></td>
<td background="bg1_r.gif">&nbsp;</td>
</tr>
<tr>
<td><img src="c1_bl.gif" width="21" height="20" /></td>
<td align="right" background="bg1_b.gif"><img src="copyright.gif" width="264" height="20" /></td>
<td><img src="c1_br.gif" width="21" height="20" /></td>
</tr>
</table>
</body>
</html>
