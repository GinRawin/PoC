<html>
<head>
<meta http-equiv="Content-Type" content="text/html;">
<title>TRENDNET | TEW-673GRU | Main | LAN &amp; DHCP Server</title>
<link rel="stylesheet" href="style.css" type="text/css">
<script language="JavaScript" src="public_msg.js"></script>
<script language="JavaScript" src="public.js"></script>
<script language="JavaScript">
function onPageLoad(){
get_by_id("html_response_page").value = get_by_id("html_response_return_page").value;
}
function do_count_down(){
get_by_id("button").disabled = true;
get_by_id("show_sec").innerHTML = count;
if (count == 0) {	
get_by_id("button").disabled = false;
return;
}
}
function back(){
window.location.href ="login.asp";
}
</script>
<style type="text/css">
<!--
.style1 {color: #FF6600}
-->
</style>
</head>
<body onLoad="MM_preloadImages('but_help1_1.gif')">
<table width="750" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="21"><img src="c1_tl.gif" width="21" height="21" /></td>
<td width="708" background="bg1_t.gif"><img src="top_1.gif" width="390" height="21" /></td>
<td width="21"><img src="c1_tr.gif" width="21" height="21" /></td>
</tr>
<tr>
<td valign="top" background="bg1_l.gif"><img src="top_2.gif" width="21" height="69" /></td>
<td background="bg.gif"><table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="13%"><img src="logo.gif" width="270" height="69" /></td>
<td width="87%" align="right"><img src="description.gif" /></td>
</tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="78%" valign="top"><table width="98%" border="0" cellpadding="0" cellspacing="0" class="tabBigTitle">
<tr>
<td class="headerbg2">Login Failed</td>
</tr>
<tr>
<td valign="top"><TABLE width="98%" border="0" align="center" cellpadding="3" cellspacing="1">
<tr>
<td bgcolor="#DDDDDD"><p>&nbsp;</p>
<table width="650" border="0" align="center">
<tr>
<td height="15"><div id=box_header>
<H1 align="left"><span class="style1">&nbsp;</span>
<!-- insert name=title -->
</H1>
<div align="left">
<p align="center">
<script>
document.write("User Name or Password incorrect");
</script>
<!-- repeat name=msg -->
</p>
<p align="center">
<input name="Button" id="button" type=button class=ButtonSmall value="Login Again" onClick="back()">
</p>
</div>
</div></td>
</tr>
</table>
<p>&nbsp;</p></td>
</tr>
</table> 
<br></td></tr>
</table>
<br></td>
</tr>
</table></td>
<td background="bg1_r.gif">&nbsp;</td>
</tr>
<tr>
<td><img src="c1_bl.gif" width="21" height="20" /></td>
<td align="right" background="bg1_b.gif"><img src="copyright.gif" width="264" height="20" /></td>
<td><img src="c1_br.gif" width="21" height="20" /></td>
</tr>
</table>
</body>
</html>
