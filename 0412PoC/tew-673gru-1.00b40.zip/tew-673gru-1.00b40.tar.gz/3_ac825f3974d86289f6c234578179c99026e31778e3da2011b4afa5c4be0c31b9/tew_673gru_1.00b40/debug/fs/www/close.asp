<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body bgcolor="#FFFFFF">
<% CmoGetCfg("html_response_message","none"); %>
<br>
<form>
<input type="button" value="Close" name="close" onClick="window.close()">
</form>
</body></html>