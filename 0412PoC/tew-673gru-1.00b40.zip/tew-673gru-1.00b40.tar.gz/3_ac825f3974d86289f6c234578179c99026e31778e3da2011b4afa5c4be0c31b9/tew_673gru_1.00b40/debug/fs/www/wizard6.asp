<html>
<head>
<title>TRENDNET | TEW-673GRU | Wizard</title>
<meta http-equiv="Content-Type" content="text/html;">
<link rel="stylesheet" href="style.css" type="text/css">
<script language="JavaScript" src="public_msg.js"></script>
<script language="JavaScript" src="public.js"></script>
<script language="JavaScript">
function loadSettings(){
set_checked("<% CmoGetCfg("asp_temp_34","none"); %>", get_by_name("asp_temp_34"));
set_checked("<% CmoGetCfg("asp_temp_37","none"); %>", get_by_name("asp_temp_37"));
get_by_id("show_ssid").value = get_by_id("asp_temp_35").value;
get_by_id("show_ssid_5g").value = get_by_id("asp_temp_38").value;
}






function set_channel(){
var channel_list = "<% CmoGetStatus("wlan0_channel_list"); %>";
var channel_list_5g = "<% CmoGetStatus("wlan1_channel_list"); %>";
var current_channel = "<% CmoGetCfg("asp_temp_36","none"); %>";
var current_channel_5g = "<% CmoGetCfg("asp_temp_39","none"); %>";
var ch = channel_list.split(",");
var ch_5g = channel_list_5g.split(",");
var obj = get_by_id("asp_temp_36");
var obj_5g = get_by_id("asp_temp_39");
var count = 0;
var count2 = 0;
for (var i = 0; i < ch.length; i++){	
var oOption = document.createElement("OPTION");	
oOption.text = ch[i];
oOption.value = ch[i];	
obj.options[count++] = oOption;
if (ch[i] == current_channel){
oOption.selected = true;
} 
}
for (var i = 0; i < ch_5g.length; i++){	
var oOption2 = document.createElement("OPTION");	
oOption2.text = ch_5g[i];
oOption2.value = ch_5g[i];	
obj_5g.options[count2++] = oOption2;
if (ch_5g[i] == current_channel_5g){
oOption2.selected = true;
} 
}
}

















function send_request(){
if (check_ssid("show_ssid")&&check_ssid("show_ssid_5g")){
get_by_id("asp_temp_35").value = get_by_id("show_ssid").value;
get_by_id("asp_temp_38").value = get_by_id("show_ssid_5g").value
send_submit("form1");
}
}
</script>
<style type="text/css">
<!--
.style1 {
font-size: 14px;
font-weight: bold;
}
.style2 {font-size: 14px}
-->
</style>
</head>
<body >
<table width="450" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="21"><img src="c1_tl.gif" width="21" height="21" /></td>
<td width="708" background="bg1_t.gif"><img src="top_1.gif" width="390" height="21" /></td>
<td width="21"><img src="c1_tr.gif" width="21" height="21" /></td>
</tr>
<tr>
<td valign="top" background="bg1_l.gif"><img src="top_2.gif" width="21" height="69" /></td>
<td background="bg.gif"><table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="78%" valign="top"><table width="98%" border="0" cellpadding="0" cellspacing="0" class="tabBigTitle">
<tr>
<td class="headerbg2">Set Wireless LAN Connection</td>
</tr>
<tr>
<td valign="top"><TABLE width="98%" height=200 border="0" align=center cellpadding="3" cellspacing="1">
<TBODY>
<TR>
<TD align="center" valign="top" bgcolor="#DDDDDD"><TABLE width="100%" align=center border=0>
<TBODY>
<TR>
<TD><form name="form1" id="form1" method="post" action="apply.cgi">
<input type="hidden" id="html_response_page" name="html_response_page" value="wizard7.asp">
<input type="hidden" id="html_response_return_page" name="html_response_return_page" value="wizard5.asp">
<input type="hidden" id="reboot_type" name="reboot_type" value="none">
<input type="hidden" id="asp_temp_35" name="asp_temp_35" value="<% CmoGetCfg("asp_temp_35","none"); %>">
<input type="hidden" id="asp_temp_38" name="asp_temp_38" value="<% CmoGetCfg("asp_temp_38","none"); %>">
<table width="100%" border="0" cellpadding="3" cellspacing="1" >
<tr align="left">
<td colspan="2" align="right" class="bggrey"><div align="left"><strong><font face="Arial">2.4Ghz</font></strong></div></td>
</tr>
<tr>
<td width="144" nowrap class="wizleft">Wireless LAN</td>
<td width="235" class="wizright">
<input type="radio" name="asp_temp_34" value="1">
Enable
<input type="radio" name="asp_temp_34" value="0">
Disable</td>
</tr>
<tr>
<td class="wizleft">SSID</td>
<td class="wizright"><input type="text" id="show_ssid" name="show_ssid" size="20" maxlength="32"></td>
</tr>
<tr>
<td class="wizleft">Channel </td>
<td class="wizright"><select size="1" id="asp_temp_36" name="asp_temp_36">
</select></td>
</tr>
<tr align="left">
<td colspan="2" align="right" class="bggrey"><div align="left"><strong><font face="Arial">5Ghz</font></strong></div></td>
</tr>
<tr>
<td width="144" nowrap class="wizleft">Wireless LAN</td>
<td width="235" class="wizright">
<input type="radio" value="1" name="asp_temp_37" >
Enable
<input type="radio" value="0" name="asp_temp_37" >
Disable</td>
</tr>
<tr>
<td class="wizleft">SSID</td>
<td class="wizright"><input name="show_ssid_5g" type="text" id="show_ssid_5g" size="20" maxlength="32" value=""></td>
</tr>
<tr>
<td class="wizleft">Channel </td>
<td class="wizright"><select size="1" id="asp_temp_39" name="asp_temp_39">
</select>
</td>
</tr>
</table>
<br>
<table border="0" align="center" cellpadding="2" cellspacing="2">
<tr>
<td align="center" nowrap><input name="back" type="button" class="ButtonSmall" onClick="window.location='<% CmoGetCfg("asp_temp_59","none"); %>'" value="&lt; Back">
<input name="next" type="button" class="ButtonSmall" onClick="send_request()" value="Next &gt;">
<input name="exit" type="button" class="ButtonSmall" onClick="exit_wizard()" value="Exit"></td>
</tr>
</table>
</form></TD>
</TR>
<TR>
<TD>&nbsp;</TD>
</TR>
</TBODY>
</TABLE></TD>
</TR>
</TBODY>
</TABLE>
<br>
</td>
</tr>
</table></td>
</tr>
</table></td>
<td background="bg1_r.gif">&nbsp;</td>
</tr>
<tr>
<td><img src="c1_bl.gif" width="21" height="20" /></td>
<td height="20" background="bg1_b.gif">&nbsp;</td>
<td><img src="c1_br.gif" width="21" height="20" /></td>
</tr>
</table>
</body>
<script>
loadSettings();
set_channel();
</script>
</html>
