<HTML>
<HEAD>
<!-- $MVD$:app("RoboHELP HTML Edition by Blue Sky Software, portions by MicroVision Dev. Inc.","769") -->
<!-- $MVD$:template("","0","0") -->
<!-- $MVD$:fontset("Arial","Arial") -->
<!-- $MVD$:fontset("Times New Roman","Times New Roman") -->
<!-- $MVD$:fontset("Arial Narrow","Arial Narrow") -->
<TITLE>Access</TITLE>
<link rel="stylesheet" href="style.css" type="text/css"><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script type="text/javascript">
<!--
function MM_preloadImages() { //v3.0
var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
function MM_swapImgRestore() { 
var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_findObj(n, d) { 
var p,i,x; if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
if(!x && d.getElementById) x=d.getElementById(n); return x;
}
function MM_swapImage() { 
var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
-->
</script>
<style type="text/css">
<!--
.style3 {color: #275b9c}
-->
</style>
</HEAD>
<BODY onLoad="MM_preloadImages('but_wizard_1.gif','but_status_1.gif','but_basicsetting_1.gif','but_ipsetting_1.gif','but_advancedsetting_1.gif','but_security_1.gif','but_tools_1.gif','but_help_access_1.gif','but_help_main_1.gif','but_management_1.gif','but_help_routing_1.gif','but_help_status_1.gif','but_tools_1.gif','but_help_wireless_1.gif')">
<table width="750" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="21"><img src="c1_tl.gif" width="21" height="21" /></td>
<td width="708" background="bg1_t.gif"><img src="top_1.gif" width="390" height="21" /></td>
<td width="21"><img src="c1_tr.gif" width="21" height="21" /></td>
</tr>
<tr>
<td valign="top" background="bg1_l.gif"><img src="top_2.gif" width="21" height="69" /></td>
<td background="bg.gif"><table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="13%"><img src="logo.gif" width="270" height="69" /></td>
<td width="87%" align="right"><img src="description.gif" /></td>
</tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="20%" height="429" valign="top"><table width="100%" border="0" align="center" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><b>Help</b></td>
</tr>
<tr>
<td bgcolor="#000000" ><table width="56%" border="0" cellpadding="0" cellspacing="0" bgcolor="#1D1D1D">
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_main.asp"><img src="but_help_main_0.gif" name="Image2" width="155" height="27" border="0" id="Image2" onmouseover="MM_swapImage('Image2','','but_help_main_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr> 
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_wlan.asp"><img src="but_help_wireless_0.gif" name="Image31" width="155" height="27" border="0" id="Image31" onmouseover="MM_swapImage('Image31','','but_help_wireless_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_status.asp"><img src="but_help_status_0.gif" name="Image23" width="155" height="27" border="0" id="Image23" onmouseover="MM_swapImage('Image23','','but_help_status_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_routing.asp"><img src="but_help_routing_0.gif" name="Image30" width="155" height="27" border="0" id="Image22" onmouseover="MM_swapImage('Image30','','but_help_routing_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_access.asp"><img src="but_help_access_1.gif" name="Image24" width="155" height="27" border="0" id="Image24" onmouseover="MM_swapImage('Image24','','but_help_access_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="2" >
<tr>
<td width="13%" align="right"><font color="#FFFFFF">&bull;</font></td>
<td width="87%"><b><a href="help_access.asp#access_user_group" class="submenus">MAC Filter</a></b></td>
</tr>
<!--<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="inbound_filter.asp" class="submenus"><b>Inbound Filter </b></a></td>
</tr>-->
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><b><a href="help_access.asp#access_url_group" class="submenus">URL Blocking</a></b></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><b><a href="help_access.asp#access_ip_filter" class="submenus">IP Filter</a></b></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><b><a href="help_access.asp#access_domain_filter" class="submenus">Domain Blocing</a></b></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><b><a href="help_access.asp#access_protocol_filter" class="submenus">Protocol Filter</a></b></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><b><a href="help_access.asp#access_virtual_server" class="submenus">Virtual Server</a></b></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><p> <b><a href="help_access.asp#access_special_ap" class="submenus">Special AP</a></b></p></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><b><a href="help_access.asp#access_DMZ" class="submenus">DMZ</a></b></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><b><a href="help_access.asp#access_Firewall_setting" class="submenus">Firewall Settings</a></b></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><b><a href="help_access.asp#access_QoS" class="submenus">QoS</a></b></td>
</tr>
</table></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_manage.asp"><img src="but_management_0.gif" name="Image21" width="155" height="27" border="0" id="Image21" onmouseover="MM_swapImage('Image21','','but_management_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_tools.asp"><img src="but_tools_0.gif" name="Image1" width="155" height="27" border="0" id="Image1" onmouseover="MM_swapImage('Image1','','but_tools_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
</table></td>
</tr>
</table>
<p></p>
<p>&nbsp;</p>
<p>&nbsp;</p></td>
<td width="2%"><img src="spacer.gif" width="10" height="15" /></td>
<td width="78%" valign="top"><table width="550" border="0" align="center" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"> <table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">Access</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" /> </td>
</tr>
</table> </td>
</tr>
<tr>
<td bgcolor="#000000"><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>This page enables you to define access restrictions, set up <A HREF="glossary.asp#def_protocol">protocol</A> and <A HREF="glossary.asp#def_IP">IP</A> <A HREF="glossary.asp#def_filter">filters</A>,
create <A HREF="glossary.asp#def_virtual_server">virtual servers</A>,
define access for special applications such as games, and set <A HREF="glossary.asp#def_firewall">firewall</A> rules.</P>
<P> Click the items below for more information:</P>
<UL>
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet"> <b><A HREF="#access_user_group">MAC Filter</A></b></P>
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet"> <b><A HREF="#access_url_group">URL Blocking</A></b></P>
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet"> <b><A HREF="#access_ip_filter">IP Filter</A></b></P>
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet"> <b><A HREF="#access_domain_filter">Domain Blocing</A></b></P>
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet"> <b><A HREF="#access_protocol_filter">Protocol Filter</A></b></P>
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet"> <b><A HREF="#access_virtual_server">Virtual Server</A></b></P>
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet"> <b><A HREF="#access_special_ap">Special AP</A></b></P>
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet"> <b><A HREF="#access_DMZ">DMZ</A></b></P> 
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet style3"><b><A HREF="#access_Firewall_setting ">Firewall settings </A></b></P> 
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet style3"><b><A HREF="#access_QoS ">QoS </A></b></P> 
</UL>
</td>
</tr>
</table></td>
</tr>
</table>
<br>
<br><a name="access_user_group"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">Mac Filter</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" /> </td>
</tr>
</table> </td>
</tr>
<tr>
<td bgcolor="#000000"><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>This screen enables you to allow and deny user access based upon a MAC list you create.</P>
<P> <SPAN STYLE="font-weight : bold;">MAC Filter:</SPAN><A NAME="access_usergroup_MAC_filter"></A> Enables you to allow or deny Internet access to users within the LAN based upon
the <A HREF="glossary.asp#def_MAC_address">MAC address</A> of their network
interface. Click the radio button next to <SPAN STYLE="font-style : italic;">Disabled</SPAN> to disable the MAC filter function.</P>
<UL>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">Disable:</SPAN> Disable the MAC filter function.</P>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">Allow:</SPAN> Only allow computers with MAC address listed below to access the internet. </P>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">Deny:</SPAN> Only deny computers with MAC address listed below to access the internet. </P>
</UL>
<P> <SPAN STYLE="font-weight : bold;">MAC Table:</SPAN><A NAME="access_usergroup_user_table"></A> Use this section to create a user profile to which Internet access is denied
or allowed.</P>
<P> The user profiles are listed in the table at the bottom of the page.</P>
<P CLASS="Note"> <SPAN STYLE="font-weight : bold;">Note:</SPAN> When selecting items
in the table at the bottom, <A HREF="#addprotfilter">click</A> anywhere in the item. The line is selected, and the fields
automatically load the item's parameters, which you can edit.</P>
<UL>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">Name:</SPAN> Type the name of the user
to be permitted/denied access.</P>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">MAC Address:</SPAN> Type the <A HREF="glossary.asp#def_MAC_address">MAC
address</A> of the user's network interface.</P>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">Add:</SPAN> Click to add the user to
the list at the bottom of the page.</P>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">Update:</SPAN> Click to update information
for the user, if you have changed any of the fields.</P>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">Delete:</SPAN> Select a user from the
table at the bottom of the list and click <SPAN STYLE="font-style : italic;">Delete</SPAN> to remove the user profile.</P> 
<li><strong>Cancel: </strong>Click the <em>Cancel </em> button to erase all fields and enter new information.</li>
</UL>
<P> <A HREF="help_access.asp">back to top</A></P></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br><a name="access_url_group"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">URL Blocking</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" /> </td>
</tr>
</table> </td>
</tr>
<tr>
<td bgcolor="#000000"><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>URL Blocking is used to deny computers within the LAN (Local Area Network) from accessing specific web sites by its URL (Uniform Resource Locator). A URL is a specially formatted text string that defines a location on the Internet. If any part of the URL contains the blocked word, the site will not be accessible and the web page will not be displayed.</P>
<UL>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;"><strong>Disable: </strong>Disable the Domain/URL Blocking function. </P>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;"><strong>Allow: </strong>Allow users to access all Domain/URL Blocking in the &quot;Domain/URL List &quot;.</p>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;"><strong>Deny: </strong> Deny users to access all Domain/URL Blocking in the &quot;Domain/URL List &quot;.</p>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;"><strong>Domains List: </strong> List Domain/URL you will Denied or Allowed. </p>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;"><strong>Delete: </strong>Select a Domain/URL from the table at the bottom of the list and click Delete to remove the Domain/URL. <strong></strong></p>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;"><strong>Add: </strong>Click the Add button to add Domain/URL to the Domains list. </p>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;"><strong>Cancel: </strong> Click the Cancel button to erase all fields and enter new information. </p>
</UL>
<P> <A HREF="help_access.asp">back to top</A></P></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br><a name="access_ip_filter"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">IP Filter</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" /> </td>
</tr>
</table> </td>
</tr>
<tr>
<td bgcolor="#000000"><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>This screen enables you to define a minimum and maximum <A HREF="glossary.asp#def_ip_address">IP
address</A> range filter; all IP addresses falling in the range are
not allowed Internet access.</P>
<P> The IP filter profiles are listed in the table at the bottom of the page.</P>
<P CLASS="Note"> <SPAN STYLE="font-weight : bold;">Note:</SPAN> When selecting items
in the table at the bottom, <A HREF="#addprotfilter">click</A> anywhere in the item. The line is selected, and the fields
automatically load the item's parameters, which you can edit.</P>
<P> <SPAN STYLE="font-weight : bold;">Enable:</SPAN><A NAME="access_ip_filter_enable"></A> Click to enable or disable the <A HREF="glossary.asp#def_ip_address">IP
address</A> <A HREF="glossary.asp#def_filter">filter</A>.</P>
<P> <SPAN STYLE="font-weight : bold;">Range Start:</SPAN><A NAME="access_ip_filter_range_start"></A> Type the minimum address for the IP range. I<A HREF="glossary.asp#def_ip_address">P
addresses</A> falling between this value and the Range End are not
allowed to access the Internet.</P>
<P> <SPAN STYLE="font-weight : bold;">Range End:</SPAN><A NAME="access_ip_filter_range_end"></A> Type the minimum address for the IP range. I<A HREF="glossary.asp#def_ip_address">P
addresses</A> falling between this value and the Range Start are not
allowed to access the Internet.</P>
<P> <SPAN STYLE="font-weight : bold;">Add:</SPAN> Click to add the IP
range to the table at the bottom of the screen.</P>
<P> <SPAN STYLE="font-weight : bold;">Update:</SPAN> Click to update
information for the range if you have selected a list item and have
made changes.</P>
<P> <SPAN STYLE="font-weight : bold;">Delete:</SPAN> Select a list item
and click <SPAN STYLE="font-style : italic;">Delete</SPAN> to remove
the item from the list.</P>
<P> <SPAN STYLE="font-weight : bold;">New:</SPAN> Click <SPAN STYLE="font-style : italic;">New</SPAN> to erase all fields and enter new information.</P>
<P> <A HREF="help_access.asp">back to top</A></P></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br><a name="access_domain_filter"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">Domain Blocking</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" /> </td>
</tr>
</table> </td>
</tr>
<tr>
<td bgcolor="#000000"><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>Domain Blocking is used to deny or allow computers within the LAN (Local Area Network) from accessing specific domains on the Internet. Domain blocking will deny or allow all requests such as http and ftp to a specific domain.
Select Allow users to access all domains except "Blocked Domains" if you allow users to access all domains except the domains in the Blocked Domains list.
Select Deny users to access all domains except "Permitted Domains" if you only want users to access Permitted Domains.</P>
<P><strong>Disable: </strong>Disable the Domain/URL Blocking function. <strong></strong></P>
<p><strong>Allow: </strong>Allow users to access all domains in the &quot;Domains List &quot;.<strong></strong></p>
<p><strong>Deny: </strong> Deny users to access all domains in the &quot;Domains List &quot;.<strong></strong></p>
<p><strong>Domains List: </strong> List Domain/URL you will Denied or Allowed. <strong></strong></p>
<p><strong>Delete: </strong>Select a Domain/URL from the table at the bottom of the list and click Delete to remove the Domain/URL. <strong></strong></p>
<p><strong>Add: </strong>Click the Add button to add domain to the Domains list. <strong></strong></p>
<p><strong>Cancel: </strong> Click the Cancel button to erase all fields and enter new information. </p>
<P> <A HREF="help_access.asp">back to top</A></P></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br><a name="access_protocol_filter"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">Protocol Filter</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" /> </td>
</tr>
</table> </td>
</tr>
<tr>
<td bgcolor="#000000"><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>This screen enables you to allow and deny access based upon a
communications <A HREF="glossary.asp#def_protocol">protocol</A> list
you create.</P>
<P> The protocol filter profiles are listed in the table at the bottom of
the page.</P>
<P CLASS="Note"> <SPAN STYLE="font-weight : bold;">Note:</SPAN> <A NAME="addprotfilter"></A>When
selecting items in the table at the bottom, click anywhere in the
item. The line is selected, and the fields automatically load the
item's parameters, which you can edit:</P>
<table border="0" align="center" cellpadding="3" cellspacing="0" bgcolor="#999999">
<tr>
<td><span class="graphic"><IMG SRC="global.gif" VSPACE="0" HSPACE="0" BORDER="0"></span></td>
</tr>
</table>
<P> <SPAN STYLE="font-weight : bold;">Protocol Filter: </SPAN>Enables you
to allow or deny Internet access to users based upon the
communications <A HREF="glossary.asp#def_protocol">protocol</A> of
the origin. Click the radio button next to <SPAN STYLE="font-style : italic;">Disabled</SPAN> to disable the protocol filter.</P>
<UL>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">Disable:</SPAN> All protocols in the
list are allowed to connect to the Internet via the LAN. (Create list items
in section under <A HREF="#access_protocol_filter_apf">Add Protocol Filter</A>.)</P>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">Enable:</SPAN> Deny to access internet
from LAN when The list below item be enable. (Create list items in section
under <A HREF="#access_protocol_filter_apf">Add Protocol Filter</A>.)</P>
</UL>
<P> <SPAN STYLE="font-weight : bold;">Add Protocol Filter:</SPAN><A NAME="access_protocol_filter_apf"></A> Use this section to create a profile for the protocol you want to
permit or deny Internet access to.</P>
<UL>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">Enable:</SPAN> Click to enable or
disable the <A HREF="glossary.asp#def_protocol">protocol</A> <A HREF="glossary.asp#def_filter">filter</A>.</P>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">Name:</SPAN> Type a descriptive
name for the <A HREF="glossary.asp#def_protocol">protocol</A> <A HREF="glossary.asp#def_filter">filter</A>.</P>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">Protocol:</SPAN> Select the
protocol (<A HREF="glossary.asp#def_TCP">TCP</A>, <A HREF="glossary.asp#def_UDP">UDP</A>,
or <A HREF="glossary.asp#def_ICMP">ICMP</A>) you want to allow/deny
Internet access to from the drop-down list.</P>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">Port Range:</SPAN> Type the <A HREF="glossary.asp#def_port">port</A> range that you want to block in the two text boxes.</P> 
<li><strong>IP Range: </strong> Type the IP range. IP addresses falling between this value and the Range End are not allowed to access the Internet.</li>
<li><SPAN STYLE="font-weight : bold;">Add: </SPAN><SPAN STYLE="font-weight : normal;">Click
to add the </SPAN><A HREF="glossary.asp#def_protocol">protocol</A> <A HREF="glossary.asp#def_filter">filter</A><SPAN STYLE="font-weight : normal;"> to the list at the bottom of the page.</SPAN></li>
<li><SPAN STYLE="font-weight : bold;">Update:</SPAN> Click to update
information for the <A HREF="glossary.asp#def_protocol">protocol</A> <A HREF="glossary.asp#def_filter">filter</A>,
if you have changed any of the fields.</li>
<li><SPAN STYLE="font-weight : bold;">Delete:</SPAN> Select a <A HREF="glossary.asp#def_filter">filter</A> profile from the table at the bottom of the list and click <SPAN STYLE="font-style : italic;">Delete</SPAN> to remove the profile.</li>
<li><strong>Cancel: </strong> Click the Cancel button to erase all fields and enter new information.</li>
</UL>
<P> <A HREF="help_access.asp">back to top</A></P></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br><a name="access_virtual_server"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">Virtual Server</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" /> </td>
</tr>
</table> </td>
</tr>
<tr>
<td bgcolor="#000000"><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>This screen enables you to create a <A HREF="glossary.asp#def_virtual_server">virtual
server</A> via the router. If the router is set as a virtual server,
remote users requesting Web or <A HREF="glossary.asp#def_FTP">FTP</A> services through the <A HREF="glossary.asp#def_WAN">WAN</A> are
directed to local servers in the <A HREF="glossary.asp#def_LAN">LAN</A>.
The router redirects the request via the <A HREF="glossary.asp#def_protocol">protocol</A> and <A HREF="glossary.asp#def_port">port</A> numbers to the correct
LAN server.</P>
<P> The Virtual Sever profiles are listed in the table at the bottom of
the page.</P>
<P CLASS="Note"> <SPAN STYLE="font-weight : bold;">Note:</SPAN> When selecting items
in the table at the bottom, <A HREF="#addprotfilter">click</A> anywhere in the item. The line is selected, and the fields
automatically load the item's parameters, which you can edit.</P>
<P> <SPAN STYLE="font-weight : bold;">Enable:</SPAN><A NAME="access_virtual_server_enable"></A> Click to enable or disable the <A HREF="glossary.asp#def_virtual_server">virtual
server</A>.</P>
<P> <SPAN STYLE="font-weight : bold;">Name:</SPAN><A NAME="access_virtual_server_name"></A> Type a descriptive name for the <A HREF="glossary.asp#def_virtual_server">virtual
server</A>.</P>
<P> <SPAN STYLE="font-weight : bold;">Protocol:</SPAN><A NAME="access_virtual_server_protocol"></A> Select the <A HREF="glossary.asp#def_protocol">protocol</A> (<A HREF="glossary.asp#def_TCP">TCP</A> , <A HREF="glossary.asp#def_UDP">UDP or *(</A><A HREF="glossary.asp#def_TCP">TCP</A> and <A HREF="glossary.asp#def_UDP">UDP</A><A HREF="glossary.asp#def_UDP">) </A>) you want to use for the <A HREF="glossary.asp#def_virtual_server">virtual
server</A>.</P>
<P> <SPAN STYLE="font-weight : bold;">Private Port:</SPAN><A NAME="access_virtual_server_private_port"></A> Type the <A HREF="glossary.asp#def_port">port</A> number of the
computer on the <A HREF="glossary.asp#def_LAN">LAN</A> that is being
used to act as a <A HREF="glossary.asp#def_virtual_server">virtual server</A>.</P>
<P> <SPAN STYLE="font-weight : bold;">Public Port:</SPAN><A NAME="access_virtual_server_public_port"></A> Type the <A HREF="glossary.asp#def_port">port</A> number on the <A HREF="glossary.asp#def_WAN">WAN</A> that will be used to provide access to the <A HREF="glossary.asp#def_virtual_server">virtual
server</A>.</P>
<P> <SPAN STYLE="font-weight : bold;">LAN Server:</SPAN><A NAME="access_virtual_server_LAN_server"></A> Type the <A HREF="glossary.asp#def_LAN">LAN</A> <A HREF="glossary.asp#def_ip_address">IP
address</A> that will be assigned to the <A HREF="glossary.asp#def_virtual_server">virtual
server</A>.</P>
<P> <SPAN STYLE="font-weight : bold;">Add:</SPAN> Click to add the <A HREF="glossary.asp#def_virtual_server">virtual
server</A> to the table at the bottom of the screen.</P>
<P> <SPAN STYLE="font-weight : bold;">Update:</SPAN> Click to update
information for the <A HREF="glossary.asp#def_virtual_server">virtual server</A> if you have selected a list item and have made changes.</P>
<P> <SPAN STYLE="font-weight : bold;">Delete:</SPAN> Select a list item
and click <SPAN STYLE="font-style : italic;">Delete</SPAN> to remove
the item from the list.</P>
<P><strong>Cancel: </strong> Click the Cancel button to erase all fields and enter new information. </P>
<P> <A HREF="help_access.asp">back to top</A></P></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br><a name="access_special_ap"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2">
<table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">Special AP</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" /> </td>
</tr>
</table>
</td>
</tr>
<tr>
<td bgcolor="#000000">
<table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0">
<P>This screen enables you to specify special applications.</P>
<P> The special applications profiles are listed in the table at the
bottom of the page.</P>
<P CLASS="Note"> <SPAN STYLE="font-weight : bold;">Note:</SPAN> When selecting items
in the table at the bottom, <A HREF="#addprotfilter">click</A> anywhere in the item. The line is selected, and the fields
automatically load the item's parameters, which you can edit.</P>
<P> <SPAN STYLE="font-weight : bold;">Enable:</SPAN><A NAME="access_special_AP_enable"></A> Click to enable or disable the application profile. When enabled,
users will be able to connect to the application via the router <A HREF="glossary.asp#def_WAN">WAN</A> connection. Click Disabled on a profile to prevent users from
accessing the application on the WAN.</P>
<P> <SPAN STYLE="font-weight : bold;">Name:</SPAN><A NAME="access_special_AP_name"></A> Type a descriptive name for the application.</P>
<P> <SPAN STYLE="font-weight : bold;">Trigger:</SPAN><A NAME="access_special_AP_trigger"></A> Defines the outgoing communication that determines whether the user
has legitimate access to the application.</P>
<UL>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">Protocol:</SPAN> Select the <A HREF="glossary.asp#def_protocol">protocol</A> (<A HREF="glossary.asp#def_TCP">TCP</A>, <A HREF="glossary.asp#def_UDP">UDP</A>, or <A HREF="glossary.asp#def_ICMP">ICMP</A>)
that can be used to access the application.</P>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">Port Range:</SPAN> Type the <A HREF="glossary.asp#def_port">port</A> range that can be used to access the application in the text boxes.</P>
</UL>
<P> <SPAN STYLE="font-weight : bold;">Incoming:</SPAN><A NAME="access_special_AP_incoming"></A> Defines which incoming communications users are permitted to connect with.</P>
<UL>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">Protocol:</SPAN> Select the <A HREF="glossary.asp#def_protocol">protocol</A> (<A HREF="glossary.asp#def_TCP">TCP</A>, <A HREF="glossary.asp#def_UDP">UDP</A>, or <A HREF="glossary.asp#def_ICMP">ICMP</A>)
that can be used by the incoming communication.</P>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">Port:</SPAN> Type the <A HREF="glossary.asp#def_port">port</A> number that can be used for the incoming communication.</P>
</UL>
<P> <SPAN STYLE="font-weight : bold;">Add:</SPAN> Click to add the
special application profile to the table at the bottom of the screen.</P>
<P> <SPAN STYLE="font-weight : bold;">Update:</SPAN> Click to update
information for the special application if you have selected a list
item and have made changes.</P>
<P> <SPAN STYLE="font-weight : bold;">Delete:</SPAN> Select a list item
and click <SPAN STYLE="font-style : italic;">Delete</SPAN> to remove
the item from the list.</P>
<P><strong>Cancel: </strong> Click the Cancel button to erase all fields and enter new information. </P>
<P> <A HREF="help_access.asp">back to top</A></P>
</td>
</tr>
</table>
</td>
</tr>
</table>
<br>
<br><a name="access_DMZ"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">DMZ</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" /> </td>
</tr>
</table> </td>
</tr>
<tr>
<td bgcolor="#000000"><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>This screen enables you to create a <A HREF="glossary.asp#def_DMZ">DMZ</A> for those computers that cannot access Internet applications properly
through the router and associated security settings.</P>
<P> <SPAN STYLE="font-weight : bold;">Enable:</SPAN><A NAME="access_dmz_enable"></A> Click to enable or disable the <A HREF="glossary.asp#def_DMZ">DMZ</A>.</P>
<P> <SPAN STYLE="font-weight : bold;">DMZ Host IP:</SPAN><A NAME="access_dmz_host_ip"></A> Type a <A HREF="glossary.asp#def_host_name">host</A> <A HREF="glossary.asp#def_ip_address">IP
address</A> for the <A HREF="glossary.asp#def_DMZ">DMZ</A>. The
computer with this IP address acts as a DMZ host with unlimited
Internet access.</P>
<P CLASS="Note"> <SPAN STYLE="font-weight : bold;">Note:</SPAN> Any clients added to
the DMZ exposes the clients to security risks such as viruses and
unauthorized access.</P>
<P> <SPAN STYLE="font-weight : bold;">Apply:</SPAN> Click to save the settings.</P>
<P> <A HREF="help_access.asp">back to top</A></P></td>
</tr>
</table></td>
</tr>
</table>
<br><a name="access_Firewall_setting"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader"> Firewall Settings </td>
<td width="21%"><input name="button2" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table></td>
</tr>
<tr>
<td bgcolor="#000000"><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>This screen enables users to set up the firewall. The WLAN Router provides basic firewall functions, by filtering all the packets
that enter the WLAN Router using a set of rules. The rules are listed in sequential order--the lower the rule number, the higher the priority the rule has. </P>
<p><strong>Enable: </strong>Click to enable or disable the firewall rule profile.</p>
<p><strong>Name: </strong> Type a descriptive name for the firewall rule profile.</p>
<p><strong>Action: </strong> Select whether to allow or deny packets that conform to the rule. </p>
<p><strong>Source: </strong> Defines the source of the incoming packet that the rule is applied to.
<UL>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">Interface:</SPAN> Select which interface (WAN or LAN) the rule is applied to.</P>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">IP Range Start: </SPAN> Type the start IP address that the rule is applied to.</P>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">IP Range End: </SPAN> Type the end IP address that the rule is applied to.</P>
</UL>
<p><strong>Destination:</strong> Defines the destination of the incoming packet that the rule is applied to.</P>
<UL>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">Interface:</SPAN> Select which interface (WAN or LAN) the rule is applied to.</P>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">IP Range Start: </SPAN> Type the start IP address that the rule is applied to.</P>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">IP Range End: </SPAN> Type the end IP address that the rule is applied to.</P>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">Protocol: </SPAN> Select the protocol (TCP, UDP, or ICMP) of the destination.</P>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">Port Range: </SPAN> Select the port range.
</UL>
<P><strong>Add:</strong> Click to add the rule profile to the table at the bottom of the screen.
<P><strong>Update:</strong> Click to update information for the rule if the user has selected a listed item and has made changes.</P>
<P><strong>Delete:</strong> Select a listed item and click Delete button to remove the entry from the list.</P>
<P><strong>Cancel:</strong> Click the Cancel button to erase all fields and enter new information.</P>
<P><strong>Priority Up:</strong> Select a rule from the list and click �Priority Up?to increase the priority of the rule.</P>
<P><strong>Priority Down:</strong> Select a rule from the list and click �Priority Down?to decrease the priority of the rule.</P>
<P><strong>Update Priority:</strong> After increasing or decreasing the priority of a rule, click �Update Priority?to save the changes.</P>
<P> <A HREF="help_access.asp">back to top</A></P></td>
</tr>
</table></td>
</tr>
</table>
<br><a name="access_QoS"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader"> QoS </td>
<td width="21%"><input name="button2" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table></td>
</tr>
<tr>
<td bgcolor="#000000"><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>Use this section to configure QoS Engine. The QoS Engine improves your online gaming experience by ensuring that your game traffic is prioritized over other network traffic, such as FTP or Web.</P>
<p><strong>Enable Traffic Shaping :</strong>When this option is enabled, the router restricts the flow of outbound traffic so as not to exceed the WAN uplink bandwidth. </p>
<!--p><strong>Automatic Uplink Speed: </strong> When enabled, this option causes the router to automatically 
measure the useful uplink bandwidth each time the WAN interface 
is re-established (after a reboot, for example). </p-->
<!--p><strong>Measured Uplink Speed : </strong> This is the uplink speed measured when the WAN interface was 
last re-established. The value may be lower than that reported 
by your ISP as it does not include all of the network protocol 
overheads associated with your ISP's network. Typically, this 
figure will be between 87% and 91% of the stated uplink speed 
for xDSL connections and around 5 kbps lower for cable network 
connections. </p-->
<p><strong>Manual Uplink Speed :</strong> the option allows you to set the uplink speed manually. 
Uplink speed is the speed at which data can be transferred from the router to your ISP. 
This is determined by your ISP. ISPs often specify speed as a downlink/uplink pair; for example, 1.5Mbps/284kbps. 
For this example, you would enter "284". Alternatively you can test your uplink speed with a service such as 
<a href="http://www.dslreports.com/">http://www.dslreports.com/</a>. Note however that sites such as DSL Reports, 
because they do not consider as many network protocol overheads, will generally note speeds slightly lower than the Measured Uplink Speed or the ISP rated speed. </p>
<p><strong>Enable QoS Engine :</strong>Enable this option for better performance and experience with online games and other interactive applications, such as VoIP.</p>
<p><strong>Automatic Classification </strong>This option is enabled by default so that your router will automatically determine which programs should have network priority.
For best performance, use the Automatic Classification option to automatically set the priority for your applications. </p>
<p><strong>Dynamic Fragmentation :</strong>This option should be enabled when you have a slow Internet uplink. It helps to reduce the impact that large low priority network packets can have on more urgent ones by breaking the large packets into several smaller packets.</p>
<p><strong>QoS Engine Rules :</strong>A QoS Engine Rule identifies a specific message flow and assigns a priority to that flow.
For most applications, automatic classification will be adequate, and specific QoS Engine Rules will not be required. 
Conflicting rules are not permitted. Conflicting rules are those that share any combination of source address/port, destination address/port, and protocol. Rejecting conflicting rules ensures the that every flow defined in a rule receives the expected priority and avoids indeterminate prioritization that could reduce QoS effectiveness. </p>
<P> <A HREF="help_access.asp">back to top</A></P></td>
</tr>
</table></td>
</tr>
</table>
<br></td>
</tr>
</table></td>
<td background="bg1_r.gif">&nbsp;</td>
</tr>
<tr>
<td><img src="c1_bl.gif" width="21" height="20" /></td>
<td align="right" background="bg1_b.gif"><img src="copyright.gif" width="264" height="20" /></td>
<td><img src="c1_br.gif" width="21" height="20" /></td>
</tr>
</table>
</BODY>
</HTML>
