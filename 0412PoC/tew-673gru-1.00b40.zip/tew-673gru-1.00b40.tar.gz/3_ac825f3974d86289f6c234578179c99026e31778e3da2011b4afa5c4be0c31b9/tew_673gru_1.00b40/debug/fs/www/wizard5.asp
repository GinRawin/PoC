<html>
<head>
<title>TRENDNET | TEW-673GRU | Wizard</title>
<meta http-equiv="Content-Type" content="text/html;">
<link rel="stylesheet" href="style.css" type="text/css">
<script language="JavaScript" src="public_msg.js"></script>
<script language="JavaScript" src="public.js"></script>
<SCRIPT LANGUAGE="JavaScript">
function loadSettings(){
var wan_mode = get_by_id("wan_type").value;
var wan_pppoe_mode = get_by_id("wan_pppoe_dynamic_00").value;
var rus_pppoe = get_by_id("wan_pppoe_russia_enable").value;
var rus_pptp = get_by_id("wan_pptp_russia_enable").value;
if(wan_mode=="pppoe" && rus_pppoe =="1"){
get_by_name("ConnType")[7].checked = true;
}else if(wan_mode=="pptp" && rus_pptp =="1"){
get_by_name("ConnType")[8].checked = true;
}else if(wan_mode=="l2tp" && rus_l2tp =="1"){
get_by_name("ConnType")[9].checked = true;
}else if(wan_mode=="bigpond"){
get_by_name("ConnType")[6].checked = true;
}else if(wan_mode=="l2tp"){
get_by_name("ConnType")[5].checked = true;
}else if(wan_mode=="static"){
get_by_name("ConnType")[1].checked = true;
}else if(wan_mode=="dhcpc"){
get_by_name("ConnType")[0].checked = true;
}else if(wan_mode=="pppoe"){
if(wan_pppoe_mode =="0"){
get_by_name("ConnType")[3].checked = true;
}else{
get_by_name("ConnType")[2].checked = true;
}
}else if(wan_mode=="pptp"){
get_by_name("ConnType")[4].checked = true;
}
}
function send_request(){
get_by_id("asp_temp_59").value = get_checked_value(get_by_name("ConnType"));
get_by_id("html_response_page").value = get_by_id("asp_temp_59").value;
send_submit("form1");
}
</script>
</head>
<body onLoad="loadSettings();">
<table width="450" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="21"><img src="c1_tl.gif" width="21" height="21" /></td>
<td width="708" background="bg1_t.gif"><img src="top_1.gif" width="390" height="21" /></td>
<td width="21"><img src="c1_tr.gif" width="21" height="21" /></td>
</tr>
<tr>
<td valign="top" background="bg1_l.gif"><img src="top_2.gif" width="21" height="69" /></td>
<td background="bg.gif"><table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="78%" valign="top"><table width="98%" border="0" cellpadding="0" cellspacing="0" class="tabBigTitle">
<tr>
<td nowrap class="headerbg2">Select Internet Connection Type</td>
</tr>
<tr>
<td valign="top"><TABLE width="98%" height=200 border="0" align=center cellpadding="3" cellspacing="1">
<TBODY>
<TR>
<TD align="center" valign="top" bgcolor="#DDDDDD"><TABLE width="100%" align=center border=0>
<TBODY>
<TR>
<TD><form id="form1" name="form1" method="post" action="apply.cgi">
<input type="hidden" id="html_response_page" name="html_response_page">
<input type="hidden" id="html_response_return_page" name="html_response_return_page" value="wizard5.asp">
<input type="hidden" id="reboot_type" name="reboot_type" value="none">
<input type="hidden" id="asp_temp_59" name="asp_temp_59" value="<% CmoGetCfg("asp_temp_59","none"); %>">
<input type="hidden" id="asp_temp_60" name="asp_temp_60" value="<% CmoGetCfg("asp_temp_60","none"); %>">
<input type="hidden" id="wan_type" name="wan_type" value="<% CmoGetCfg("wan_proto","none"); %>">
<input type="hidden" id="wan_pppoe_dynamic_00" name="wan_pppoe_dynamic_00" value="<% CmoGetCfg("wan_pppoe_dynamic_00","none"); %>">
<input type="hidden" id="wan_pppoe_russia_enable" name="wan_pppoe_russia_enable" value="<% CmoGetCfg("wan_pppoe_russia_enable");%>">
<input type="hidden" id="wan_pptp_russia_enable" name="wan_pptp_russia_enable" value="<% CmoGetCfg("wan_pptp_russia_enable","none"); %>">
<table width="100%" border="0" cellpadding="3" cellspacing="1">
<tr>
<td><b><font>
<input type="radio" name="ConnType" value="wizard5a.asp">
Obtain IP automatically (DHCP client)</font></b></td>
</tr>
<tr>
<td><b><font>
<input type="radio" name="ConnType" value="wizard5b.asp">
Fixed IP address</font></b></td>
</tr>
<tr>
<td><b><font>
<input type="radio" name="ConnType" value="wizard5c.asp">
PPPoE to obtain IP automatically</font></b></td>
</tr>
<tr>
<td><b><font>
<input type="radio" name="ConnType" value="wizard5d.asp">
PPPoE with a fixed IP address</font></b></td>
</tr>
<tr>
<td><b><font>
<input type="radio" name="ConnType" value="wizard5e.asp">
PPTP</font></b></td>
</tr>
<tr>
<td><b><font>
<input type="radio" name="ConnType" value="wizard5f.asp">
L2TP</font></b></td>
</tr>
<tr>
<td><b><font>
<input type="radio" name="ConnType" value="wizard5g.asp">
BigPond Cable</font></b></td>
</tr>
<tr>
<td><b><font>
<input type="radio" name="ConnType" value="wizard5h.asp">
Russia PPPoE</font></b></td>
</tr>
<tr>
<td><b><font>
<input type="radio" name="ConnType" value="wizard5i.asp">
Russia PPTP</font></b></td>
</tr>
<tr>
<td><b><font>
<input type="radio" name="ConnType" value="wizard5j.asp">
Russia L2TP</font></b></td>
</tr>
</table>
<br>
<table border="0" align="center" cellpadding="2" cellspacing="2">
<tr>
<td align="center"><input name="back" type="button" class="ButtonSmall" onClick="window.location='wizard3.asp'" value="&lt; Back">
<input name="next" type="button" class="ButtonSmall" onclick="send_request();" value="Next &gt;">
<input name="exit" type="button" class="ButtonSmall" onClick=exit_wizard() value="Exit"></td>
</tr>
</table>
</form></TD>
</TR>
<TR>
<TD>&nbsp;</TD>
</TR>
</TBODY>
</TABLE></TD>
</TR>
</TBODY>
</TABLE>
<br>
</td>
</tr>
</table></td>
</tr>
</table></td>
<td background="bg1_r.gif">&nbsp;</td>
</tr>
<tr>
<td><img src="c1_bl.gif" width="21" height="20" /></td>
<td height="20" background="bg1_b.gif">&nbsp;</td>
<td><img src="c1_br.gif" width="21" height="20" /></td>
</tr>
</table>
</body>
</html>
