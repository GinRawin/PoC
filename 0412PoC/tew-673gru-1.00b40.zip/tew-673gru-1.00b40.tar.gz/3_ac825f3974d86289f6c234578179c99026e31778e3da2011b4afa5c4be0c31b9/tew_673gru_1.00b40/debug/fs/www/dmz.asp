<html>
<head>
<meta http-equiv="Content-Type" content="text/html;">
<title>TRENDNET | TEW-673GRU | Access | DMZ</title>
<link rel="stylesheet" href="style.css" type="text/css">
<script language="JavaScript" src="public_msg.js"></script>
<script language="JavaScript" src="public.js"></script>
<SCRIPT LANGUAGE="JavaScript">
function loadSettings(){
set_checked("<% CmoGetCfg("dmz_enable","none"); %>",get_by_name("dmz_enable"));
}
function send_request(){	
var ip = get_by_id("dmz_ipaddr").value;
var ip_addr_msg = replace_msg(all_ip_addr_msg,"DMZ Host IP");
var temp_ip_obj = new addr_obj(ip.split("."), ip_addr_msg, false, false);
var temp_LAN_ip_obj = new addr_obj(get_by_id("cur_ipaddr").value.split("."), all_ip_addr_msg, false, false);
var temp_mask_obj = new addr_obj(get_by_id("cur_netmask").value.split("."), subnet_mask_msg, false, false);
if(get_by_name("dmz_enable")[0].checked){	
if ((ip != "")&&(ip != "0.0.0.0")){
if(ip_num(temp_LAN_ip_obj.addr) == ip_num(temp_ip_obj.addr)){
alert(addstr(msg[MSG43],"DMZ Host IP"));
return false;
}
if (!check_address(temp_ip_obj)){
return false;
}
if (!check_domain(temp_LAN_ip_obj, temp_mask_obj, temp_ip_obj)){
alert(addstr(msg[MSG3],"DMZ Host IP"));
return false;
}
}
else{
get_by_id("dmz_enable").value = 0;
get_by_id("dmz_ipaddr").value = "0.0.0.0";
}
}	
send_submit("form1");	
}
function MM_openBrWindow(theURL,winName,features) { 
window.open(theURL,winName,features);
}
</SCRIPT>
</head>
<body onLoad="MM_preloadImages('but_wizard_1.gif','but_status_1.gif','but_tools_1.gif','but_main_1.gif','but_wireless_1.gif','but_routing_1.gif','but_access_1.gif','but_management_1.gif');loadSettings()">
<table width="750" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="21"><img src="c1_tl.gif" width="21" height="21" /></td>
<td width="708" background="bg1_t.gif"><img src="top_1.gif" width="390" height="21" /></td>
<td width="21"><img src="c1_tr.gif" width="21" height="21" /></td>
</tr>
<tr>
<td valign="top" background="bg1_l.gif"><img src="top_2.gif" width="21" height="69" /></td>
<td background="bg.gif"><table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="13%"><img src="logo.gif" width="270" height="69" /></td>
<td width="87%" align="right"><img src="description.gif" /></td>
</tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="20%" height="429" valign="top"><table width="56%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td><a href="lan.asp"><img src="but_main_0.gif" name="Image91" border="0" id="Image91" onMouseOver="MM_swapImage('Image91','','but_main_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="wireless_basic.asp"><img src="but_wireless_0.gif" name="Image101" border="0" id="Image101" onMouseOver="MM_swapImage('Image101','','but_wireless_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a><a href="w_basic.asp"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="status.asp"><img src="but_status_0.gif" name="Image111" border="0" id="Image111" onMouseOver="MM_swapImage('Image111','','but_status_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="static_routing.asp"><img src="but_routing_0.gif" name="Image121" border="0" id="Image121" onMouseOver="MM_swapImage('Image121','','but_routing_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="filters.asp"><img src="but_access_1.gif" name="Image131" border="0" id="Image131" onMouseOver="MM_swapImage('Image131','','but_access_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="2" class="submenubg">
<tr>
<td width="13%" align="right"><font color="#FFFFFF">&bull;</font></td>
<td width="87%"><a href="filters.asp" class="submenus"><b>Filter </b></a></td>
</tr>
<!--<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="inbound_filter.asp" class="submenus"><b>Inbound Filter </b></a></td>
</tr>-->
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="virtual_server.asp" class="submenus"><b>Virtual Server </b></a></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="special_ap.asp" class="submenus"><b>Special AP </b></a></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="dmz.asp" class="submenus"><b><u>DMZ</u></b></a></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="firewall_setting.asp" class="submenus"><b>Firewall Settings</b></a></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="qos.asp" class="submenus"><b>QoS</b></a></td>
</tr> 
</table></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="remote_management.asp"><img src="but_management_0.gif" border="0" id="Image14" onMouseOver="MM_swapImage('Image14','','but_management_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="restart.asp"><img src="but_tools_0.gif" border="0" id="Image15" onMouseOver="MM_swapImage('Image15','','but_tools_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="#" onClick="show_wizard('wizard.asp')"><img src="but_wizard_0.gif" name="Image161" border="0" id="Image161" onMouseOver="MM_swapImage('Image161','','but_wizard_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="15" height="15"></td>
</tr>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p></td>
<td width="2%"><img src="spacer.gif" width="15" height="15" /></td>
<td width="78%" valign="top"><table width="98%" border="0" cellpadding="0" cellspacing="0" class="tabBigTitle">
<tr>
<td class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%"><font color="#FFFFFF" class="textheader" style="margin-left:0; padding-left:0">DMZ</font></td>
<td width="21%"><td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="MM_openBrWindow('help_access.asp#access_DMZ','','scrollbars=yes,resizable=yes,width=800,height=550')" value=" Help " /></td>
</tr>
</table></td>
</tr>
<tr>
<td valign="top">
<form id="form1" name="form1" method="post" action="apply.cgi">
<input type="hidden" id="html_response_page" name="html_response_page" value="back.asp">
<input type="hidden" id="html_response_message" name="html_response_message" value="Settings Saved."> 
<input type="hidden" id="html_response_return_page" name="html_response_return_page" value="dmz.asp">
<input type="hidden" id="reboot_type" name="reboot_type" value="filter">
<input type="hidden" id="cur_ipaddr" name="cur_ipaddr" value="<% CmoGetCfg("lan_ipaddr","none"); %>">
<input type="hidden" id="cur_netmask" name="cur_netmask" value="<% CmoGetCfg("lan_netmask","none"); %>">
<table width="98%" border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#333333">
<tr>
<td align="right" nowrap class="bgblue">DMZ Enable</td>
<td class="bggrey" ><input type="radio" id="dmz_enable" name="dmz_enable" value="1">Enabled<input type="radio" name="dmz_enable" value="0">
Disabled</td>
</tr>
<tr>
<td align="right" class="bgblue">DMZ Host IP</td>
<td width="424" class="bggrey"><input type="text" id="dmz_ipaddr" name="dmz_ipaddr" size="16" maxlength="15" value="<% CmoGetCfg("dmz_ipaddr","none"); %>"></td>
</tr>
<tr>
<td align="right" class="bgblue">&nbsp;</td>
<td class="bggrey2"><input type="button" value="Apply" id="apply" name="apply" class="ButtonSmall" onClick="send_request()">
<input name="cancel" type="button" class="ButtonSmall" onClick="window.location='dmz.asp'" value="Cancel"></td>
</tr>
</table>
</form>
<br>
</td>
</tr>
</table></td>
</tr>
</table></td>
<td background="bg1_r.gif">&nbsp;</td>
</tr>
<tr>
<td><img src="c1_bl.gif" width="21" height="20" /></td>
<td align="right" background="bg1_b.gif"><img src="copyright.gif" width="264" height="20" /></td>
<td><img src="c1_br.gif" width="21" height="20" /></td>
</tr>
</table>
</body>
</html>
