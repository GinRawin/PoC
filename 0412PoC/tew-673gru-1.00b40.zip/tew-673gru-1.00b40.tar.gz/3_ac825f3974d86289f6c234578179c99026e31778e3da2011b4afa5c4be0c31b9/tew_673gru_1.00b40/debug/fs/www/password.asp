<html>
<head>
<meta http-equiv="Content-Type" content="text/html;">
<title>TRENDNET | TEW-673GRU | Main | Password</title>
<link rel="stylesheet" href="style.css" type="text/css">
<script language="JavaScript" src="public_msg.js"></script>
<script language="JavaScript" src="public.js"></script>
<SCRIPT LANGUAGE="JavaScript">
function check_admin(){ 
if (get_by_id("adm_pwd1").value != get_by_id("adm_pwd2").value){
alert(msg[MSG8]);
return false;
}
return true;
}
function check_user(){ 
if (get_by_id("user_pwd1").value != get_by_id("user_pwd2").value){
alert(msg[MSG9]);
return false;
}
return true;
}
function send_request(){
if (check_admin() && check_user()){
send_submit("form1");
}
}
function key_word(newobj,obj){
get_by_id(obj).value = newobj.value;
}
</SCRIPT>
</head>
<body onLoad="MM_preloadImages('but_wizard_1.gif','but_status_1.gif','but_tools_1.gif','but_main_1.gif','but_wireless_1.gif','but_routing_1.gif','but_access_1.gif','but_management_1.gif')">
<table width="750" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="21"><img src="c1_tl.gif" width="21" height="21" /></td>
<td width="708" background="bg1_t.gif"><img src="top_1.gif" width="390" height="21" /></td>
<td width="21"><img src="c1_tr.gif" width="21" height="21" /></td>
</tr>
<tr>
<td valign="top" background="bg1_l.gif"><img src="top_2.gif" width="21" height="69" /></td>
<td background="bg.gif"><table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="13%"><img src="logo.gif" width="270" height="69" /></td>
<td width="87%" align="right"><img src="description.gif" /></td>
</tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="20%" height="429" valign="top"><table width="56%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td><a href="lan.asp"><img src="but_main_1.gif" name="Image91" border="0" id="Image91" onMouseOver="MM_swapImage('Image91','','but_main_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="2" class="submenubg">
<tr>
<td width="13%" align="right"><font color="#FFFFFF">&bull;</font></td>
<td width="87%"><a href="lan.asp" class="submenus"><b>LAN &amp; DHCP Server </b></a></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="wan.asp" class="submenus"><b>WAN</b></a></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="password.asp" class="submenus"><b><u>Password</u></b></a></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="time.asp" class="submenus"><b>Time</b></a></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="ddns.asp" class="submenus"><b>Dynamic DNS </b></a></td>
</tr>
</table></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="wireless_basic.asp"><img src="but_wireless_0.gif" name="Image101" border="0" id="Image101" onMouseOver="MM_swapImage('Image101','','but_wireless_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a><a href="w_basic.asp"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="status.asp"><img src="but_status_0.gif" name="Image111" border="0" id="Image111" onMouseOver="MM_swapImage('Image111','','but_status_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="static_routing.asp"><img src="but_routing_0.gif" name="Image121" border="0" id="Image121" onMouseOver="MM_swapImage('Image121','','but_routing_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="filters.asp"><img src="but_access_0.gif" name="Image131" border="0" id="Image131" onMouseOver="MM_swapImage('Image131','','but_access_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="remote_management.asp"><img src="but_management_0.gif" border="0" id="Image14" onMouseOver="MM_swapImage('Image6','','but_management_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="restart.asp"><img src="but_tools_0.gif" border="0" id="Image15" onMouseOver="MM_swapImage('Image7','','but_tools_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="#" onClick="show_wizard('wizard.asp')"><img src="but_wizard_0.gif" name="Image161" border="0" id="Image161" onMouseOver="MM_swapImage('Image161','','but_wizard_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="15" height="15"></td>
</tr>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p></td>
<td width="2%"><img src="spacer.gif" width="15" height="15" /></td>
<td width="78%" valign="top"><table width="98%" border="0" cellpadding="0" cellspacing="0" class="tabBigTitle">
<tr>
<td class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%"><font color="#FFFFFF" class="textheader" style="margin-left:0; padding-left:0">Password</font></td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="MM_openBrWindow('help_main.asp#main_password','','scrollbars=yes,resizable=yes,width=800,height=550')" value=" Help " />
</td>
</tr>
</table></td>
</tr>
<tr>
<td valign="top"><form id="form1" name="form1" method="post" action="apply.cgi">
<input type="hidden" name="html_response_page" value="back.asp">
<input type="hidden" name="html_response_message" value="The setting is saved.">
<input type="hidden" name="html_response_return_page" value="password.asp">
<input type="hidden" id="admin_password" name="admin_password" value="WDB8WvbXdHtZyM8Ms2RENgHlacJghQyG">
<input type="hidden" id="user_password" name="user_password" value="WDB8WvbXdHtZyM8Ms2RENgHlacJghQyG">
<table width="98%" border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#333333">
<tr>
<td colspan="2" class="greybluebg"><b>Administrator </b><font size="2">(The
login name is &quot;admin&quot;)</font></td>
</tr>
<tr>
<td class="bgblue">New Password</td>
<td width="430" class="bggrey"><input type="password" name="adm_pwd1" id="adm_pwd1" size="20" maxlength="15" value="WDB8WvbXdHtZyM8Ms2RENgHlacJghQyG" onChange="key_word(this,'admin_password');"></td>
</tr>
<tr>
<td class="bgblue">Confirm Password</td>
<td class="bggrey"><input type="password" name="adm_pwd2" id="adm_pwd2" size="20" maxlength="15" value="WDB8WvbXdHtZyM8Ms2RENgHlacJghQyG"></td>
</tr>
<tr>
<td colspan="2" class="greybluebg">User <font size="2">(The
login name is &quot;user&quot;)</font></td>
</tr>
<tr>
<td class="bgblue">New Password</td>
<td class="bggrey"><input type="password" name="user_pwd1" id="user_pwd1" size="20" maxlength="15" value="WDB8WvbXdHtZyM8Ms2RENgHlacJghQyG" onChange="key_word(this,'user_password');"></td>
</tr>
<tr>
<td height="26" class="bgblue">Confirm Password</td>
<td height="26" class="bggrey"><input type="password" name="user_pwd2" id="user_pwd2" size="20" maxlength="15" value="WDB8WvbXdHtZyM8Ms2RENgHlacJghQyG"></td>
</tr>
<tr>
<td height="26" class="bgblue">&nbsp;</td>
<td height="26" class="bggrey2"><input name="cancel" type="button" class="ButtonSmall" id="cancel" onClick="window.location='password.asp'" value="Cancel">
<input name="apply" type="button" class="ButtonSmall" id="apply" onClick="send_request()" value="Apply">
</td>
</tr>
</table>
</form>
<br>
</td>
</tr>
</table></td>
</tr>
</table></td>
<td background="bg1_r.gif">&nbsp;</td>
</tr>
<tr>
<td><img src="c1_bl.gif" width="21" height="20" /></td>
<td align="right" background="bg1_b.gif"><img src="copyright.gif" width="264" height="20" /></td>
<td><img src="c1_br.gif" width="21" height="20" /></td>
</tr>
</table>
</body>
</html>
