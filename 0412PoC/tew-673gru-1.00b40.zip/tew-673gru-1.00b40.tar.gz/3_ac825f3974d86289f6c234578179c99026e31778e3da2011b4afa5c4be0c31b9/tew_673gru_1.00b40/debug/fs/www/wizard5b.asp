<html>
<head>
<title>TRENDNET | TEW-673GRU | Wizard</title>
<meta http-equiv="Content-Type" content="text/html;">
<link rel="stylesheet" href="style.css" type="text/css">
<script language="JavaScript" src="public_msg.js"></script>
<script language="JavaScript" src="public.js"></script>
<script language="JavaScript">
function loadSettings(){
var dat = get_by_id("wan_curr_ipaddr").value.split("/");
if(dat[0] !="0.0.0.0" && get_by_id("asp_temp_05").value == "0.0.0.0"){
get_by_id("asp_temp_05").value = dat[0];
}
if(dat[1] !="0.0.0.0" && get_by_id("asp_temp_06").value == "0.0.0.0"){
get_by_id("asp_temp_06").value = dat[1];
}
}
function send_request(){
var ip = get_by_id("asp_temp_05").value;	
var mask = get_by_id("asp_temp_06").value;
var gateway = get_by_id("asp_temp_07").value;
var dns1 = get_by_id("asp_temp_09").value;
var dns2 = get_by_id("asp_temp_10").value;
var ip_addr_msg = replace_msg(all_ip_addr_msg,"IP address");
var gateway_msg = replace_msg(all_ip_addr_msg,"Gateway address");
var dns1_addr_msg = replace_msg(all_ip_addr_msg,"DNS Server 1");
var dns2_addr_msg = replace_msg(all_ip_addr_msg,"DNS Server 2");
var temp_ip_obj = new addr_obj(ip.split("."), ip_addr_msg, false, false);
var temp_mask_obj = new addr_obj(mask.split("."), subnet_mask_msg, false, false);
var temp_gateway_obj = new addr_obj(gateway.split("."), gateway_msg, false, false);
var temp_dns1_obj = new addr_obj(dns1.split("."), dns1_addr_msg, false, false);
var temp_dns2_obj = new addr_obj(dns2.split("."), dns2_addr_msg, true, false);
if (!check_lan_setting(temp_ip_obj, temp_mask_obj, temp_gateway_obj)){
return false;
}
if (!check_address(temp_dns1_obj)){
return false;
}	
if (dns2 != "" && dns2 != "0.0.0.0"){
if (!check_address(temp_dns2_obj)){
return false;
}
}
if((get_by_id("asp_temp_09").value =="" || get_by_id("asp_temp_09").value =="0.0.0.0")&& (get_by_id("asp_temp_10").value =="" || get_by_id("asp_temp_10").value =="0.0.0.0")){
get_by_id("asp_temp_08").value = 0;
}else{
get_by_id("asp_temp_08").value = 1;
}
send_submit("form1");
}
</script>
</head>
<body onLoad="loadSettings();">
<table width="450" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="21"><img src="c1_tl.gif" width="21" height="21" /></td>
<td width="708" background="bg1_t.gif"><img src="top_1.gif" width="390" height="21" /></td>
<td width="21"><img src="c1_tr.gif" width="21" height="21" /></td>
</tr>
<tr>
<td valign="top" background="bg1_l.gif"><img src="top_2.gif" width="21" height="69" /></td>
<td background="bg.gif"><table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="78%" valign="top"><table width="98%" border="0" cellpadding="0" cellspacing="0" class="tabBigTitle">
<tr>
<td class="headerbg2">Set Fixed IP Address</td>
</tr>
<tr>
<td valign="top"><TABLE width="98%" height=200 border="0" align=center cellpadding="3" cellspacing="1">
<TBODY>
<TR>
<TD align="center" valign="top" bgcolor="#DDDDDD"><TABLE width="100%" align=center border=0>
<TBODY>
<TR>
<TD><form id="form1" name="form1" method="post" action="apply.cgi">
<input type="hidden" id="html_response_page" name="html_response_page" value="wizard6.asp">
<input type="hidden" id="html_response_return_page" name="html_response_return_page" value="<% CmoGetCfg("html_response_return_page","none"); %>">
<input type="hidden" id="reboot_type" name="reboot_type" value="none">
<input type="hidden" id="wan_curr_ipaddr" name="wan_curr_ipaddr" value="<% CmoGetStatus("wan_current_ipaddr_00"); %>">
<input type="hidden" id="asp_temp_02" name="asp_temp_02" value="static">
<input type="hidden" id="asp_temp_08" name="asp_temp_08" value="<% CmoGetCfg("asp_temp_08","none"); %>">
<table width="100%" border="0" cellpadding="3" cellspacing="1">
<tr>
<td nowrap class="wizleft" >WAN IP Address</td>
<td class="wizright"><input type="text" id="asp_temp_05" name="asp_temp_05" size="16" maxlength="15" value="<% CmoGetCfg("asp_temp_05","none"); %>"></td>
</tr>
<tr>
<td class="wizleft" >WAN Subnet Mask</td>
<td class="wizright"><input type="text" id="asp_temp_06" name="asp_temp_06" size="16" maxlength="15" value="<% CmoGetCfg("asp_temp_06","none"); %>"></td>
</tr>
<tr>
<td nowrap class="wizleft">WAN Gateway Address</td>
<td class="wizright"><input type="text" id="asp_temp_07" name="asp_temp_07" size="16" maxlength="15" value="<% CmoGetCfg("asp_temp_07","none"); %>"></td>
</tr>
<tr>
<td class="wizleft" >DNS Server Address
1 </td>
<td class="wizright"> <input type="text" id="asp_temp_09" name="asp_temp_09" size="16" maxlength="15" value="<% CmoGetCfg("asp_temp_09","none"); %>"> </td>
</tr>
<tr>
<td class="wizleft" >DNS Server Address
2 </td>
<td class="wizright"> <input type="text" id="asp_temp_10" name="asp_temp_10" size="16" maxlength="15" value="<% CmoGetCfg("asp_temp_10","none"); %>"> </td>
</tr>
</table>
<br>
<table border="0" align="center" cellpadding="2" cellspacing="2">
<tr>
<td align="center"><input name="back" type="button" class="ButtonSmall" onClick="window.location='<% CmoGetCfg("html_response_return_page","none"); %>'" value="&lt; Back">
<input name="next" type="button" class="ButtonSmall" onClick="send_request()" value="Next &gt;">
<input name="exit" type="button" class="ButtonSmall" onClick="exit_wizard()" value="Exit"></td>
</tr>
</table>
</form></TD>
</TR>
<TR>
<TD>&nbsp;</TD>
</TR>
</TBODY>
</TABLE></TD>
</TR>
</TBODY>
</TABLE>
<br>
</td>
</tr>
</table></td>
</tr>
</table></td>
<td background="bg1_r.gif">&nbsp;</td>
</tr>
<tr>
<td><img src="c1_bl.gif" width="21" height="20" /></td>
<td height="20" background="bg1_b.gif">&nbsp;</td>
<td><img src="c1_br.gif" width="21" height="20" /></td>
</tr>
</table>
</body>
</html>
