<HTML>
<HEAD>
<!-- $MVD$:app("RoboHELP HTML Edition by Blue Sky Software, portions by MicroVision Dev. Inc.","769") -->
<!-- $MVD$:template("","0","0") -->
<!-- $MVD$:fontset("Arial","Arial") -->
<!-- $MVD$:fontset("Times New Roman","Times New Roman") -->
<!-- $MVD$:fontset("Arial Narrow","Arial Narrow") -->
<TITLE>Status</TITLE>
<link rel="stylesheet" href="style.css" type="text/css"><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script type="text/javascript">
<!--
function MM_preloadImages() { //v3.0
var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
function MM_swapImgRestore() { 
var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_findObj(n, d) { 
var p,i,x; if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
if(!x && d.getElementById) x=d.getElementById(n); return x;
}
function MM_swapImage() { 
var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
-->
</script>
</HEAD>
<BODY onLoad="MM_preloadImages('but_help_access_1.gif','but_help_main_1.gif','but_management_1.gif','but_help_routing_1.gif','but_help_status_1.gif','but_tools_1.gif','but_help_wireless_1.gif')">
<table width="750" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="21"><img src="c1_tl.gif" width="21" height="21" /></td>
<td width="708" background="bg1_t.gif"><img src="top_1.gif" width="390" height="21" /></td>
<td width="21"><img src="c1_tr.gif" width="21" height="21" /></td>
</tr>
<tr>
<td valign="top" background="bg1_l.gif"><img src="top_2.gif" width="21" height="69" /></td>
<td background="bg.gif"><table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="13%"><img src="logo.gif" width="270" height="69" /></td>
<td width="87%" align="right"><img src="description.gif" /></td>
</tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="20%" height="429" valign="top"><table width="100%" border="0" align="center" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><b>Help</b></td>
</tr>
<tr>
<td bgcolor="#000000" ><table width="56%" border="0" cellpadding="0" cellspacing="0" bgcolor="#1D1D1D">
<tr>
<td><a href="help_main.asp"><img src="but_help_main_0.gif" name="Image2" width="155" height="27" border="0" id="Image2" onmouseover="MM_swapImage('Image2','','but_help_main_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_wlan.asp"><img src="but_help_wireless_0.gif" name="Image31" width="155" height="27" border="0" id="Image31" onmouseover="MM_swapImage('Image31','','but_help_wireless_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_status.asp"><img src="but_help_status_1.gif" name="Image23" width="155" height="27" border="0" id="Image23" onmouseover="MM_swapImage('Image23','','but_help_status_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="2" >
<tr>
<td width="13%" align="right"><font color="#FFFFFF">&bull;</font></td>
<td width="87%"><b><a href="help_status.asp#status_device_info" class="submenus">Device Information</a><a href="help_access.asp#access_user_group" class="submenus"></a></b></td>
</tr>
<!--<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="inbound_filter.asp" class="submenus"><b>Inbound Filter </b></a></td>
</tr>-->
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><b><a href="help_status.asp#status_log" class="submenus">Log</a><a href="help_access.asp#access_url_group" class="submenus"></a></b></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><b><a href="help_status.asp#status_log_settings" class="submenus">Log Settings</a><a href="help_access.asp#access_ip_filter" class="submenus"></a></b></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><b><a href="help_status.asp#status_statistic" class="submenus">Statistics</a><a href="help_access.asp#access_domain_filter" class="submenus"></a></b></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><b><a href="help_status.asp#status_wireless" class="submenus">Wireless</a><a href="help_access.asp#access_protocol_filter" class="submenus"></a></b></td>
</tr>
</table></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_routing.asp"><img src="but_help_routing_0.gif" name="Image30" width="155" height="27" border="0" id="Image22" onmouseover="MM_swapImage('Image30','','but_help_routing_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_access.asp"><img src="but_help_access_0.gif" name="Image24" width="155" height="27" border="0" id="Image24" onmouseover="MM_swapImage('Image24','','but_help_access_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_manage.asp"><img src="but_management_0.gif" name="Image21" width="155" height="27" border="0" id="Image21" onmouseover="MM_swapImage('Image21','','but_management_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_tools.asp"><img src="but_tools_0.gif" name="Image1" width="155" height="27" border="0" id="Image1" onmouseover="MM_swapImage('Image1','','but_tools_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
</table></td>
</tr>
</table>
<p></p>
<p>&nbsp;</p>
<p>&nbsp;</p></td>
<td width="2%"><img src="spacer.gif" width="10" height="15" /></td>
<td width="78%" valign="top"><table width="550" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">Status</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>This screen enables you to view the status of the router <A HREF="glossary.asp#def_LAN">LAN</A>, <A HREF="glossary.asp#def_WAN">WAN</A> and <A HREF="glossary.asp#def_wireless_lan">wireless
LAN</A> connections, and view logs and statistics pertaining to
connections and <A HREF="glossary.asp#def_packet">packet</A> transfers.</P>
<P> Click the items below for more information:</P>
<UL>
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet"> <b><A HREF="#status_device_info">Device Information</A></b></P>
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet"> <b><A HREF="#status_log">Log</A></b></P>
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet"> <b><A HREF="#status_log_settings">Log Settings</A></b></P>
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet"> <b><A HREF="#status_statistic">Statistics</A></b></P>
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet"> <b><A HREF="#status_wireless">Wireless</A></b></P>
</UL></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br>
<a name="status_device_info"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">Device Information</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>This screen enables you to view the router <A HREF="glossary.asp#def_LAN">LAN</A>, <A HREF="glossary.asp#def_wireless_lan">wireless LAN</A>, and <A HREF="glossary.asp#def_WAN">WAN</A> configuration.</P>
<p> <SPAN STYLE="font-weight : bold;">Firmware Version:</SPAN><A NAME="status_firmware_version"></A> <SPAN STYLE="font-style : normal;">D</SPAN>isplays the latest build of the wireless router <A HREF="glossary.asp#def_firmware">firmware</A> interface. After updating the
firmware in <A HREF="help_tools.asp#tools_firmware">Tools - Firmware</A>, check
this to ensure that your firmware was successfully updated.</P>
<p><SPAN STYLE="font-weight : bold;">WAN:</SPAN><A NAME="status_devinfo_WAN"></A> This field displays the router's <A HREF="glossary.asp#def_WAN">WAN</A> interface <A HREF="glossary.asp#def_MAC_address">MAC address</A>, <A HREF="glossary.asp#def_dhcp">DHCP</A> client status, <A HREF="glossary.asp#def_ip_address">IP address</A>, <A HREF="glossary.asp#def_subnet_mask">subnet mask</A>, default <A HREF="glossary.asp#def_gateway">gateway</A>, and <A HREF="glossary.asp#def_DNS">DNS</A>.</P>
<P> Click <SPAN STYLE="font-style : italic;">DHCP Release</SPAN> to release all IP addresses assigned to client stations connected to the WAN via the router. Click <SPAN STYLE="font-style : italic;">DHCP Renew</SPAN> to reassign IP addresses to client stations connected to the WAN.</P>
<P><SPAN STYLE="font-weight : bold;">Wireless:</SPAN><A NAME="status_devinfo_wireless"></A> Displays the router's wireless connection information, including the
router's wireless interface <A HREF="glossary.asp#def_MAC_address">MAC
address</A>, the connection status, the <A HREF="glossary.asp#def_ssid">SSID</A> status, which channel is being used, and whether <A HREF="glossary.asp#def_WEP">WEP</A> is enabled or not.</P>
<P><SPAN STYLE="font-weight : bold;">LAN:</SPAN><A NAME="status_devinfo_lan"></A> This field displays the router's <A HREF="glossary.asp#def_LAN">LAN</A> interface <A HREF="glossary.asp#def_MAC_address">MAC address</A>, <A HREF="glossary.asp#def_ip_address">IP address</A>, <A HREF="glossary.asp#def_subnet_mask">subnet mask</A>, and <A HREF="glossary.asp#def_dhcp">DHCP</A> server status. Click <SPAN STYLE="font-style : italic;"><A HREF="help_main.asp#lanski_dhcp_server">DHCP Table</A></SPAN> to view a list of client stations currently connected to the router LAN interface. </P>
<P> <A HREF="help_status.asp">back to top</A></P></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br>
<a name="status_log"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">Log</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>This screen enables you to view a running log of router system
statistics, events, and activities. The log displays up to 200
entries. Older entries are overwritten by new entries. You can save
logs via the <A HREF="#status_log_settings">Log Settings</A> screen (<A HREF="#status_logset_sent_to">Send
to</A>). The Log screen commands are as follows:</P>
<UL>
<LI CLASS="mvd-P">
<P STYLE="margin-top : 0.0pt;margin-bottom : 0.0pt;"> <SPAN STYLE="font-weight : normal;">Click </SPAN><SPAN STYLE="font-style : italic;font-weight : normal;">First
Page</SPAN><SPAN STYLE="font-weight : normal;"> to view the first
page of the log</SPAN></P>
<LI CLASS="mvd-P">
<P STYLE="margin-top : 0.0pt;margin-bottom : 0.0pt;"> <SPAN STYLE="font-weight : normal;">Click </SPAN><SPAN STYLE="font-style : italic;font-weight : normal;">Last
Page</SPAN><SPAN STYLE="font-weight : normal;"> to view the final
page of the log</SPAN></P>
<LI CLASS="mvd-P">
<P STYLE="margin-top : 0.0pt;margin-bottom : 0.0pt;"> <SPAN STYLE="font-weight : normal;">Click </SPAN><SPAN STYLE="font-style : italic;font-weight : normal;">Previous
Page</SPAN><SPAN STYLE="font-weight : normal;"> to view the page
just before the current page</SPAN></P>
<LI CLASS="mvd-P">
<P STYLE="margin-top : 0.0pt;margin-bottom : 0.0pt;"> <SPAN STYLE="font-weight : normal;">Click </SPAN><SPAN STYLE="font-style : italic;font-weight : normal;">Next
Page</SPAN><SPAN STYLE="font-weight : normal;"> to view the page
just after the current page</SPAN></P>
<LI CLASS="mvd-P">
<P STYLE="margin-top : 0.0pt;margin-bottom : 0.0pt;"> <SPAN STYLE="font-weight : normal;">Click </SPAN><SPAN STYLE="font-style : italic;font-weight : normal;">Clear
Log</SPAN><SPAN STYLE="font-weight : normal;"> to delete the
contents of the log and begin a new log</SPAN></P>
<LI CLASS="mvd-P">
<P STYLE="margin-top : 0.0pt;margin-bottom : 0.0pt;"> <SPAN STYLE="font-weight : normal;">Click </SPAN><SPAN STYLE="font-style : italic;font-weight : normal;">Refresh</SPAN><SPAN STYLE="font-weight : normal;"> to renew log statistics</SPAN></P>
</UL>
<P> <SPAN STYLE="font-weight : bold;">Time:</SPAN><A NAME="status_log_time"></A> Displays the time and date that the log entry was created.</P>
<P> <SPAN STYLE="font-weight : bold;">Message:</SPAN><A NAME="status_log_message"></A> Displays summary information about the log entry.</P>
<P> <SPAN STYLE="font-weight : bold;">Note:</SPAN><A NAME="status_log_note"></A> Displays the <A HREF="glossary.asp#def_ip_address">IP address</A> of
the communication.</P>
<P> <A HREF="help_status.asp">back to top</A></P></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br>
<a name="status_log_settings"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"> <table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">Log Settings</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>This screen enables you to set router logging parameters.</P>
<P><strong>SMTP Authentication: </strong>Select Enabled if your SMTP server requires you to login in order to send email. Type in account name and password in SMTP Account field and SMTP Password field. </P>
<p><strong>SMTP Account: </strong> If SMTP Authentication is enabled, type in the SMTP account name here. </p>
<p><strong>SMTP Password: </strong> If SMTP Authentication is enabled, type in the password of the SMTP account here. </p>
<P> <SPAN STYLE="font-weight : bold;">SMTP Server:</SPAN><A NAME="status_logset_smtp_server"></A> Type the <A HREF="glossary.asp#def_SMTP">SMTP</A> server address for
the email that the log will be sent to in the next field.</P>
<P> <SPAN STYLE="font-weight : bold;">Send to:</SPAN><A NAME="status_logset_sent_to"></A> Type an email address for the log to be sent to. Click <SPAN STYLE="font-style : italic;">Email
Log Now</SPAN> to immediately send the current log.</P>
<P> <SPAN STYLE="font-weight : bold;">E-mail Log :</SPAN> When log is full.</P>
<P> <SPAN STYLE="font-weight : bold;">Syslog Server:</SPAN><A NAME="status_logset_syslog_server"></A> Type the <A HREF="glossary.asp#def_ip_address">IP address</A> of the <A HREF="glossary.asp#def_SysLog_Server">Syslog
Server</A> if you want the router to listen and receive incoming
SysLog messages.</P>
<P> <SPAN STYLE="font-weight : bold;">Log Type:</SPAN><A NAME="status_logset_log_type"></A> Enables you to select what items will be included in the log:</P>
<UL>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">System Activity: </SPAN>Displays
information related to router operation.</P>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">Debug Information:</SPAN> Displays
information related to errors and system malfunction.</P>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">Attacks:</SPAN> Displays
information about any malicious activity on the network.</P>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">Dropped Packets:</SPAN> Displays
information about <A HREF="glossary.asp#def_packet">packets</A> that
have not been transferred successfully.</P>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">Notice:</SPAN> Displays important
notices by the system <A HREF="glossary.asp#def_administrator">administrator</A>.</P>
</UL>
<P> <A HREF="help_status.asp">back to top</A></P></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br>
<a name="status_statistic"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader"><font color="#FFFFFF">Statistic</font></td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table></td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>This screen displays a table that shows the rate of packet
transmission via the router <A HREF="glossary.asp#def_LAN">LAN</A>, <A HREF="glossary.asp#def_wireless_lan">wireless
LAN</A>, and <A HREF="glossary.asp#def_WAN">WAN</A> ports (in bytes
per second).</P>
<P> Click <SPAN STYLE="font-style : italic;">Reset</SPAN> to erase all
statistics and begin logging statistics again.</P>
<P> <SPAN STYLE="font-weight : bold;">Utilization:</SPAN><A NAME="status_statistics_utilization"></A> Separates packet transmission statistics into send and receive
categories. Peak indicates the maximum packet transmission recorded
since logging began, while transmission since recording began.</P>
<P> <strong>Cancel: </strong>Click the <em>Cancel </em> button to erase all fields and enter new information. </P>
<P> <A HREF="help_status.asp">back to top</A></P></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br>
<a name="status_wireless"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">Wireless</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>This screen enables you to view information about wireless devices
that are connected to the router wireless interface.</P>
<P> <SPAN STYLE="font-weight : bold;">Connected Time:</SPAN><A NAME="status_wireless_connected_time"></A> Displays how long the wireless device has been connected to the <A HREF="glossary.asp#def_LAN">LAN</A> via the router.</P>
<P> <SPAN STYLE="font-weight : bold;">MAC Address:</SPAN><A NAME="status_wireless_mac_address"></A> Displays the devices <A HREF="glossary.asp#def_wireless_lan">wireless LAN</A> interface <A HREF="glossary.asp#def_MAC_address">MAC address</A>.</P>
<P> <A HREF="help_status.asp">back to top</A></P></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br></td>
</tr>
</table></td>
<td background="bg1_r.gif">&nbsp;</td>
</tr>
<tr>
<td><img src="c1_bl.gif" width="21" height="20" /></td>
<td align="right" background="bg1_b.gif"><img src="copyright.gif" width="264" height="20" /></td>
<td><img src="c1_br.gif" width="21" height="20" /></td>
</tr>
</table>
</BODY>
</HTML>
