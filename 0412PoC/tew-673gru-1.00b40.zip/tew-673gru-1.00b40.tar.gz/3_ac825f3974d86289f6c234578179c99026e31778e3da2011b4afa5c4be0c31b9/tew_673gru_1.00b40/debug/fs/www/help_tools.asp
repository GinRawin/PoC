<HTML>
<HEAD>
<!-- $MVD$:app("RoboHELP HTML Edition by Blue Sky Software, portions by MicroVision Dev. Inc.","769") -->
<!-- $MVD$:template("","0","0") -->
<!-- $MVD$:fontset("Arial","Arial") -->
<!-- $MVD$:fontset("Times New Roman","Times New Roman") -->
<!-- $MVD$:fontset("Arial Narrow","Arial Narrow") -->
<TITLE>Tools</TITLE>
<link rel="stylesheet" href="style.css" type="text/css"><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script type="text/javascript">
<!--
function MM_preloadImages() { 
var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
function MM_swapImgRestore() { 
var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_findObj(n, d) { 
var p,i,x; if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
if(!x && d.getElementById) x=d.getElementById(n); return x;
}
function MM_swapImage() { 
var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
-->
</script>
</HEAD>
<BODY onLoad="MM_preloadImages('but_help_access_1.gif','but_help_main_1.gif','but_management_1.gif','but_help_routing_1.gif','but_help_status_1.gif','but_tools_1.gif','but_help_wireless_1.gif')">
<table width="750" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="21"><img src="c1_tl.gif" width="21" height="21" /></td>
<td width="708" background="bg1_t.gif"><img src="top_1.gif" width="390" height="21" /></td>
<td width="21"><img src="c1_tr.gif" width="21" height="21" /></td>
</tr>
<tr>
<td valign="top" background="bg1_l.gif"><img src="top_2.gif" width="21" height="69" /></td>
<td background="bg.gif"><table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="13%"><img src="logo.gif" width="270" height="69" /></td>
<td width="87%" align="right"><img src="description.gif" /></td>
</tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="20%" height="429" valign="top"><table width="100%" border="0" align="center" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><b>Help</b></td>
</tr>
<tr>
<td bgcolor="#000000" ><table width="56%" border="0" cellpadding="0" cellspacing="0" bgcolor="#1D1D1D">
<tr>
<td><a href="help_main.asp"><img src="but_help_main_0.gif" name="Image2" width="155" height="27" border="0" id="Image2" onmouseover="MM_swapImage('Image2','','but_help_main_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_wlan.asp"><img src="but_help_wireless_0.gif" name="Image31" width="155" height="27" border="0" id="Image31" onmouseover="MM_swapImage('Image31','','but_help_wireless_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_status.asp"><img src="but_help_status_0.gif" name="Image23" width="155" height="27" border="0" id="Image23" onmouseover="MM_swapImage('Image23','','but_help_status_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_routing.asp"><img src="but_help_routing_0.gif" name="Image30" width="155" height="27" border="0" id="Image22" onmouseover="MM_swapImage('Image30','','but_help_routing_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_access.asp"><img src="but_help_access_0.gif" name="Image24" width="155" height="27" border="0" id="Image24" onmouseover="MM_swapImage('Image24','','but_help_access_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_manage.asp"><img src="but_management_0.gif" name="Image21" width="155" height="27" border="0" id="Image21" onmouseover="MM_swapImage('Image21','','but_management_1.gif',1)" onmouseout="MM_swapImgRestore()" /></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_tools.asp"><img src="but_tools_1.gif" name="Image1" width="155" height="27" border="0" id="Image1" onmouseover="MM_swapImage('Image1','','but_tools_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="2" >
<tr>
<td width="13%" align="right"><font color="#FFFFFF">&bull;</font></td>
<td width="87%"><b><a href="help_tools.asp#tools_restart" class="submenus">Restart</a><a href="help_access.asp#access_user_group" class="submenus"></a></b></td>
</tr>
<!--<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="inbound_filter.asp" class="submenus"><b>Inbound Filter </b></a></td>
</tr>-->
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><b><a href="help_tools.asp#tools_settings" class="submenus">Settings</a><a href="help_access.asp#access_url_group" class="submenus"></a></b></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><b><a href="help_tools.asp#tools_firmware" class="submenus">Firmware</a></b>.<b><a href="help_access.asp#access_ip_filter" class="submenus"></a></b></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><b><a href="help_tools.asp#tools_ping_test" class="submenus">Ping Test</a><a href="help_access.asp#access_domain_filter" class="submenus"></a></b></td>
</tr>
</table></td>
</tr>
</table></td>
</tr>
</table>
<p></p>
<p>&nbsp;</p>
<p>&nbsp;</p></td>
<td width="2%"><img src="spacer.gif" width="10" height="15" /></td>
<td width="78%" valign="top"><table width="550" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">Tools</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>This page enables you to restart the system, save and load different
settings as profiles, restore factory default settings, run a <A HREF="#tools_setup_wizard">setup
wizard</A> to configure router settings, upgrade the <A HREF="glossary.asp#def_firmware">firmware</A>,
and <A HREF="glossary.asp#def_Ping">ping</A> remote IP addresses.</P>
<P> Click the items below for more information:</P>
<UL>
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet"> <b><A HREF="#tools_restart">Restart</A></b></P>
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet"> <b><A HREF="#tools_settings">Settings</A></b></P>
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet"> <b><A HREF="#tools_firmware">Firmware</A></b>.</P>
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet"> <b><A HREF="#tools_ping_test">Ping Test</A></b></P> 
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet"> <b><A HREF="#tools_usb_setting">USB Settings</A></b></P>
</UL></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br> <a name="tools_restart"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">Restart</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>Click <SPAN STYLE="font-style : italic;">Restart</SPAN> to restart
the system in the event the system is not performing correctly.</P>
<P STYLE="text-align : left;" ALIGN=LEFT> <A HREF="help_tools.asp">back to top</A></P></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br> <a name="tools_settings"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">Settings</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>This screen enables you to save your settings as a profile and load profiles
for different circumstances. You can also load the factory default settings,
and run a setup wizard to configure the router and router interface. </P>
<P> <SPAN STYLE="font-weight : bold;">Save Settings:</SPAN> Click to save
the current configuration as a profile that you can load when necessary.</P>
<P> <SPAN STYLE="font-weight : bold;">Load Settings:</SPAN> Click <SPAN STYLE="font-style : italic;">Browse</SPAN> and go to the location of a stored profile. Click <SPAN STYLE="font-style : italic;">Load</SPAN> to load the profile's settings.</P>
<P> <SPAN STYLE="font-weight : bold;">Restore Factory Default Settings:</SPAN> Click to restore the default settings. All configuration changes you
have made will be lost.</P>
<P>&nbsp; </P>
<P> <A HREF="help_tools.asp">back to top</A></P></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br> <a name="tools_firmware"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">Firmware</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>This screen enables you to keep the router firmware up to date.</P>
<P> Follow these instructions:</P>
<OL>
<LI CLASS="mvd-P">
<P> Download the latest firmware from the manufacturer's Web site, and
save it to your disk.</P>
<LI CLASS="mvd-P">
<P> Click <SPAN STYLE="font-style : italic;">Browse</SPAN> and go to the
location of the downloaded firmware file.</P>
<LI CLASS="mvd-P">
<P> Select the file and click Upgrade to update the firmware to the
latest release.</P>
</OL>
<P> <A HREF="help_tools.asp">back to top</A></P></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br> <a name="tools_ping_test"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">Ping Test</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>The <A HREF="glossary.asp#def_Ping">ping</A> test enables you to determine whether an <A HREF="glossary.asp#def_ip_address">IP address</A> or <A HREF="glossary.asp#def_host_name">host</A> is present on the Internet. Type the host name or IP address in the text box and click Ping.</P>
<P> <A HREF="help_tools.asp">back to top</A></P></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br>
<br> <a name="tools_usb_setting"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">USB Settings</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>There are two options supported in this section, Network USB and WCN Configuration. Select Network USB option if you would like to share the connected USB device on your network; select WCN Configuration option if you would like to configure a USB device with existing settings (e.g. a wireless USB adapter). To use the Network USB option correctly, please make sure the utility or driver is installed on each computer that will access the connected USB device.</P>
<P> <A HREF="help_tools.asp">back to top</A></P></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br></td>
</tr>
</table></td>
<td background="bg1_r.gif">&nbsp;</td>
</tr>
<tr>
<td><img src="c1_bl.gif" width="21" height="20" /></td>
<td align="right" background="bg1_b.gif"><img src="copyright.gif" width="264" height="20" /></td>
<td><img src="c1_br.gif" width="21" height="20" /></td>
</tr>
</table>
</BODY>
</HTML>