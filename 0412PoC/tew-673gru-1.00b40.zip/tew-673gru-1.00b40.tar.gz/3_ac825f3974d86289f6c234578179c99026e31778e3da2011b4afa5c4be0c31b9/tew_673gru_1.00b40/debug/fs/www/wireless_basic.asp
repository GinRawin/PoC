<html>
<head>
<meta http-equiv="Content-Type" content="text/html;">
<title>TRENDNET | TEW-673GRU | Wireless | Basic</title>
<link rel="stylesheet" href="style.css" type="text/css">
<script language="JavaScript" src="public_msg.js"></script>
<script language="JavaScript" src="public.js"></script>
<SCRIPT LANGUAGE="JavaScript">
function loadSettings(){
set_checked("<% CmoGetCfg("wlan0_enable","none"); %>", get_by_name("wlan0_enable"));
set_checked("<% CmoGetCfg("wlan1_enable","none"); %>", get_by_name("wlan1_enable"));
set_checked("<% CmoGetCfg("wlan0_ssid_broadcast","none"); %>", get_by_name("wlan0_ssid_broadcast"));
set_checked("<% CmoGetCfg("wlan1_ssid_broadcast","none"); %>", get_by_name("wlan1_ssid_broadcast"));
set_selectIndex("<% CmoGetCfg("wlan0_dot11_mode","none"); %>", get_by_id("dot11_mode"));
set_selectIndex("<% CmoGetCfg("wlan1_dot11_mode","none"); %>", get_by_id("dot11_mode_5g"));
set_checked("<% CmoGetCfg("wlan0_wmm_enable","none"); %>", get_by_name("wlan0_wmm_enable"));
set_checked("<% CmoGetCfg("wlan1_wmm_enable","none"); %>", get_by_name("wlan1_wmm_enable"));
set_selectIndex("<% CmoGetCfg("wlan0_11n_protection","none"); %>", get_by_id("11n_protection"));
set_selectIndex("<% CmoGetCfg("wlan1_11n_protection","none"); %>", get_by_id("11n_protection_5g"));
get_by_id("show_ssid").value = get_by_id("wlan0_ssid").value;
get_by_id("show_ssid_5g").value = get_by_id("wlan1_ssid").value;
set_channel();
set_channel_5g();	
disable_wireless();	
disable_wireless_5g();
}
function disable_wireless(){
var enable = get_by_name("wlan0_enable");	
get_by_id("show_ssid").disabled = enable[1].checked;
get_by_id("wlan0_channel").disabled = enable[1].checked;
get_by_id("dot11_mode").disabled = enable[1].checked;
get_by_id("11n_protection").disabled = enable[1].checked;
get_by_name("wlan0_ssid_broadcast")[0].disabled = enable[1].checked;
get_by_name("wlan0_ssid_broadcast")[1].disabled = enable[1].checked;
get_by_name("wlan0_wmm_enable")[0].disabled = enable[1].checked;
get_by_name("wlan0_wmm_enable")[1].disabled = enable[1].checked;
get_by_name("apply").disabled = enable[1].checked;
get_by_name("cancel").disabled = enable[1].checked;
}
function disable_wireless_5g(){
var enable = get_by_name("wlan1_enable");	
get_by_id("show_ssid_5g").disabled = enable[1].checked;
get_by_id("wlan1_channel").disabled = enable[1].checked;
get_by_id("dot11_mode_5g").disabled = enable[1].checked;
get_by_id("11n_protection_5g").disabled = enable[1].checked;
get_by_name("wlan1_ssid_broadcast")[0].disabled = enable[1].checked;
get_by_name("wlan1_ssid_broadcast")[1].disabled = enable[1].checked;
get_by_name("wlan1_wmm_enable")[0].disabled = enable[1].checked;
get_by_name("wlan1_wmm_enable")[1].disabled = enable[1].checked;
}
function set_channel(){
var channel_list = "<% CmoGetStatus("wlan0_channel_list"); %>";
var current_channel = "<% CmoGetCfg("wlan0_channel","none"); %>";
var ch = channel_list.split(",");
var ch_text = new Array("2.412","2.417","2.422","2.427","2.432","2.437","2.442","2.447","2.452","2.457","2.462","2.467","2.472");
var obj = get_by_id("wlan0_channel");
var count = 0;
for (var i = 0; i < ch.length; i++){	
var ooption = document.createElement("option");	
ooption.text = ch_text[i] + " GHz - CH " + ch[i];
ooption.value = ch[i];	
obj.options[count++] = ooption;
if (ch[i] == current_channel){
ooption.selected = true;
} 
}
}
function set_channel_5g(){
var channel_list = "<% CmoGetStatus("wlan1_channel_list"); %>";
var current_channel = "<% CmoGetCfg("wlan1_channel","none"); %>";
var ch = channel_list.split(",");
var obj = get_by_id("wlan1_channel");
var count = 0;
for (var i = 0; i < ch.length; i++){	
var ooption = document.createElement("option");	
var option_list=new Array();	
ooption.text = ch[i];

if (ooption.text == ""){ 
break;
}

option_list = ch[i].split(" ",5);
ooption.value = option_list[4];	
obj.options[count++] = ooption;
if (option_list[4] == current_channel){
ooption.selected = true;
} 
}
}
function send_request(){
var enable = get_by_name("wlan0_enable");
var enable_5g = get_by_name("wlan1_enable");
var ssid_broadcast = get_by_name("wlan0_ssid_broadcast");
var ssid_broadcast_5g = get_by_name("wlan1_ssid_broadcast");
if (check_ssid("show_ssid")){	
get_by_id("wlan0_ssid").value = get_by_id("show_ssid").value;
}
else{
return false;
}
if (check_ssid("show_ssid_5g")){	
get_by_id("wlan1_ssid").value = get_by_id("show_ssid_5g").value;
}
else{
return false;
}
if((enable[1].checked)&&(enable_5g[1].checked)){
get_by_id("wps_enable").value = 0;
}
if(ssid_broadcast[1].checked && ssid_broadcast_5g[1].checked){
if(confirm("To disable SSID Broadcast will cause WPS not work. Are you sure you want to continue with the new setting?"))
{
get_by_id("wps_enable").value = 0;
}
else 
{
return ;
}
}
if (get_by_id("dot11_mode").value == "11bg" && get_by_id("11n_protection").value == "auto"){
alert("Wireless mode is set to 802.11b/g , channel width can't be set to auto 20/40");
return false;
}
else if (get_by_id("dot11_mode_5g").value == "11a" && get_by_id("11n_protection_5g").value == "auto"){
alert("Wireless mode is set to 802.11a , channel width can't be set to auto 20/40");
return false;
}
else{
get_by_id("wlan0_dot11_mode").value = get_by_id("dot11_mode").value;
get_by_id("wlan1_dot11_mode").value = get_by_id("dot11_mode_5g").value;
get_by_id("wlan0_11n_protection").value = get_by_id("11n_protection").value;
get_by_id("wlan1_11n_protection").value = get_by_id("11n_protection_5g").value;
}
get_by_id("wps_configured_mode").value = 5;	
send_submit("form1");
}
</SCRIPT>
</head>
<body onLoad="MM_preloadImages('but_wizard_1.gif','but_status_1.gif','but_tools_1.gif','but_main_1.gif','but_wireless_1.gif','but_routing_1.gif','but_access_1.gif','but_management_1.gif');loadSettings()">
<table width="750" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="21"><img src="c1_tl.gif" width="21" height="21" /></td>
<td width="708" background="bg1_t.gif"><img src="top_1.gif" width="390" height="21" /></td>
<td width="21"><img src="c1_tr.gif" width="21" height="21" /></td>
</tr>
<tr>
<td valign="top" background="bg1_l.gif"><img src="top_2.gif" width="21" height="69" /></td>
<td background="bg.gif"><table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="13%"><img src="logo.gif" width="270" height="69" /></td>
<td width="87%" align="right"><img src="description.gif" /></td>
</tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="20%" height="429" valign="top"><table width="56%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td><a href="lan.asp"><img src="but_main_0.gif" name="Image2" border="0" id="Image2" onMouseOver="MM_swapImage('Image2','','but_main_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="wireless_basic.asp"><img src="but_wireless_1.gif" name="Image3" border="0" id="Image3" onMouseOver="MM_swapImage('Image3','','but_wireless_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="2" class="submenubg">
<tr>
<td width="13%" align="right"><font color="#FFFFFF">&bull;</font></td>
<td width="87%"><a href="wireless_basic.asp" class="submenus"><b><u>Basic</u></b></a></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="wireless_auth.asp" class="submenus"><b>Security</b></a></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="wireless_advanced.asp" class="submenus"><b>Advanced</b></a></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="wlan_wps.asp" class="submenus"><b>WiFi Protected Setup</b></a></td>
</tr>
</table></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="status.asp"><img src="but_status_0.gif" name="Image1" border="0" id="Image1" onMouseOver="MM_swapImage('Image1','','but_status_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="static_routing.asp"><img src="but_routing_0.gif" name="Image4" border="0" id="Image4" onMouseOver="MM_swapImage('Image4','','but_routing_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="filters.asp"><img src="but_access_0.gif" name="Image5" border="0" id="Image5" onMouseOver="MM_swapImage('Image5','','but_access_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="remote_management.asp"><img src="but_management_0.gif" border="0" id="Image6" onMouseOver="MM_swapImage('Image6','','but_management_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="restart.asp"><img src="but_tools_0.gif" border="0" id="Image7" onMouseOver="MM_swapImage('Image7','','but_tools_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="#" onClick="show_wizard('wizard.asp')"><img src="but_wizard_0.gif" name="Image71" border="0" id="Image71" onMouseOver="MM_swapImage('Image71','','but_wizard_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="15" height="15"></td>
</tr>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p></td>
<td width="2%"><img src="spacer.gif" width="15" height="15" /></td>
<td width="78%" valign="top"><table width="98%" border="0" cellpadding="0" cellspacing="0" class="tabBigTitle">
<tr>
<td class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%"><font color="#FFFFFF" class="textheader" style="margin-left:0; padding-left:0">Basic</font></td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="MM_openBrWindow('help_wlan.asp#wireless_basic','','scrollbars=yes,resizable=yes,width=800,height=550')" value=" Help " />
</td>
</tr>
</table></td>
</tr>
<tr>
<td valign="top"><form id="form1" name="form1" method="post" action="apply.cgi">
<input type="hidden" id="html_response_page" name="html_response_page" value="back.asp">
<input type="hidden" id="html_response_message" name="html_response_message" value="The setting is saved.">
<input type="hidden" id="html_response_return_page" name="html_response_return_page" value="wireless_basic.asp">
<input type="hidden" id="wlan0_ssid" name="wlan0_ssid" value="<% CmoGetCfg("wlan0_ssid","none"); %>">
<input type="hidden" id="wlan1_ssid" name="wlan1_ssid" value="<% CmoGetCfg("wlan1_ssid","none"); %>">
<input type="hidden" name="wps_enable" id="wps_enable" value="<% CmoGetCfg("wps_enable","none"); %>">
<input type="hidden" id="wps_configured_mode" name="wps_configured_mode" value="<% CmoGetCfg("wps_configured_mode","none"); %>">
<input type="hidden" id="reboot_type" name="reboot_type" value="wireless">
<table width="98%" border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#333333">
<tr>
<td colspan="2" align="right" class="bggrey"><div align="left"><strong><font face="Arial">2.4GHz</font></strong></div></td>
</tr>
<tr>
<td align="right" class="bgblue"><font face="Arial">Wireless </font></td>
<td class="bggrey">
<input type="radio" value="1" name="wlan0_enable" onclick="disable_wireless()">
Enabled&nbsp;&nbsp;&nbsp;
<input type="radio" value="0" name="wlan0_enable" onclick="disable_wireless()">
Disabled</td>
</tr> 
<tr>
<td align="right" class="bgblue"><font face="Arial">SSID </font></td>
<td class="bggrey"><input name="show_ssid" type="text" id="show_ssid" size="20" maxlength="32" value=""></td>
</tr>
<tr>
<td align="right" class="bgblue"><font face="Arial">Channel </font></td>
<td class="bggrey"><font face="Arial" size="2">
<select size="1" id="wlan0_channel" name="wlan0_channel">
</select>
(Domain:
<script>
var domain= "<% CmoGetCfg("wlan0_domain","none"); %>";
if(domain =="0x10"){
document.write("FCC");
}else if(domain =="0x30"){
document.write("ETSI");	
}	
</script>
)</font> </td>
</tr>
<tr>
<td class="bgblue"><div align="right">802.11 Mode</div></td>
<td class="bggrey"><select id="dot11_mode" name="dot11_mode">
<option value="11bg">2.4GHz 802.11b/g mixed mode</option>
<option value="11bgn">2.4GHz 802.11b/g/n mixed mode</option>
<option value="11n">2.4GHz 802.11n only mode</option>
</select> 
<input type="hidden" id="wlan0_dot11_mode" name="wlan0_dot11_mode" value="<% CmoGetCfg("wlan0_dot11_mode","none"); %>"></td>
</tr>
<tr id="show_channel_width">
<td class="bgblue"><div align="right">Channel Width</div></td>
<td class="bggrey"><select id="11n_protection" name="11n_protection">
<option value="20">20 MHz</option>
<option value="auto">Auto 20/40 MHz</option>
</select>
<input type="hidden" id="wlan0_11n_protection" name="wlan0_11n_protection" value="<% CmoGetCfg("wlan0_11n_protection","none"); %>">
</td>
</tr> 
<tr>
<td align="right" class="bgblue"><font face="Arial"> SSID Broadcast </font></td>
<td class="bggrey"><font face="Arial" size="2"> </font><font face=verdana size=2><b> <font face=verdana size=2><b>
<input type="radio" name="wlan0_ssid_broadcast" value="1">
</b></font> </b></font>Enabled<font face=verdana size=2><b> 
<input type="radio" name="wlan0_ssid_broadcast" value="0">
</b></font>Disabled</td>
</tr>
<tr>
<td align="right" class="bgblue"><font face="Arial"> WMM </font></td>
<td class="bggrey"><font face="Arial" size="2"> </font><font face=verdana size=2><b>
<input type="radio" name="wlan0_wmm_enable" value="1">
</b></font>Enabled<font face=verdana size=2><b>
<input type="radio" name="wlan0_wmm_enable" value="0">
</b></font>Disabled</td>
</tr>
<tr>
<td colspan="2" align="right" class="bggrey"><div align="left"><strong><font face="Arial">5GHz</font></strong></div></td>
</tr>
<tr>
<td align="right" class="bgblue"><font face="Arial">5G Wireless </font></td>
<td class="bggrey">
<input type="radio" value="1" name="wlan1_enable" onclick="disable_wireless_5g()">
Enabled&nbsp;&nbsp;&nbsp;
<input type="radio" value="0" name="wlan1_enable" onclick="disable_wireless_5g()">
Disabled</td>
</tr> 
<tr>
<td align="right" class="bgblue"><font face="Arial">SSID </font></td>
<td class="bggrey"><input name="show_ssid_5g" type="text" id="show_ssid_5g" size="20" maxlength="32" value=""></td>
</tr>
<tr>
<td align="right" class="bgblue"><font face="Arial">Channel </font></td>
<td class="bggrey"><font face="Arial" size="2">
<select size="1" id="wlan1_channel" name="wlan1_channel">
</select>
(Domain:
<script>
var domain= "<% CmoGetCfg("wlan0_domain","none"); %>";
if(domain =="0x10"){
document.write("FCC");
}else if(domain =="0x30"){
document.write("ETSI");	
}	
</script>
)</font> </td>
</tr>
<tr>
<td class="bgblue"><div align="right">802.11 Mode</div></td>
<td class="bggrey"><select id="dot11_mode_5g" name="dot11_mode_5g">
<option value="11na">5GHz 802.11a/n mixed mode</option>
<option value="11a">5GHz 802.11a only mode</option>
</select> 
<input type="hidden" id="wlan1_dot11_mode" name="wlan1_dot11_mode" value="<% CmoGetCfg("wlan1_dot11_mode","none"); %>"></td>
</tr>
<tr id="show_channel_width">
<td class="bgblue"><div align="right">Channel Width</div></td>
<td class="bggrey"><select id="11n_protection_5g" name="11n_protection_5g">
<option value="20">20 MHz</option>
<option value="auto">Auto 20/40 MHz</option>
</select>
<input type="hidden" id="wlan1_11n_protection" name="wlan1_11n_protection" value="<% CmoGetCfg("wlan1_11n_protection","none"); %>">
</td>
</tr>
<tr>
<td align="right" class="bgblue"><font face="Arial"> SSID Broadcast </font></td>
<td class="bggrey"><font face="Arial" size="2"> </font><font face=verdana size=2><b> <font face=verdana size=2><b>
<input type="radio" name="wlan1_ssid_broadcast" value="1">
</b></font> </b></font>Enabled<font face=verdana size=2><b> 
<input type="radio" name="wlan1_ssid_broadcast" value="0">
</b></font>Disabled</td>
</tr>
<tr>
<td align="right" class="bgblue"><font face="Arial"> WMM </font></td>
<td class="bggrey"><font face="Arial" size="2"> </font><font face=verdana size=2><b>
<input type="radio" name="wlan1_wmm_enable" value="1">
</b></font>Enabled <font face=verdana size=2><b>
<input type="radio" name="wlan1_wmm_enable" value="0">
</b></font>Disabled</td>
</tr>
<tr>
<td align="right" class="bgblue">&nbsp;</td>
<td bgcolor="#FFFFFF" class="bggrey2"><input name="cancel_5g" type="button" class="ButtonSmall" id="cancel" onClick="window.location='wireless_basic.asp'" value="Cancel">
<input name="apply" type="button" class="ButtonSmall" id="apply" onClick="send_request()" value="Apply">
</td>
</tr> 
</table>
</form>
<br>
</td>
</tr>
</table></td>
</tr>
</table></td>
<td background="bg1_r.gif">&nbsp;</td>
</tr>
<tr>
<td><img src="c1_bl.gif" width="21" height="20" /></td>
<td align="right" background="bg1_b.gif"><img src="copyright.gif" width="264" height="20" /></td>
<td><img src="c1_br.gif" width="21" height="20" /></td>
</tr>
</table>
</body>
</html>
