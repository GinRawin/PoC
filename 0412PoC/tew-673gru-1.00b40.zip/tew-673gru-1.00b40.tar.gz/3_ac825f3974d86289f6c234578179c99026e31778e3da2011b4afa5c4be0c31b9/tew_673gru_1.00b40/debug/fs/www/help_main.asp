<HTML>
<HEAD>
<!-- $MVD$:app("RoboHELP HTML Edition by Blue Sky Software, portions by MicroVision Dev. Inc.","769") -->
<!-- $MVD$:template("","0","0") -->
<!-- $MVD$:fontset("Arial","Arial") -->
<!-- $MVD$:fontset("Times New Roman","Times New Roman") -->
<!-- $MVD$:fontset("Arial Narrow","Arial Narrow") -->
<TITLE>Main</TITLE>
<link rel="stylesheet" href="style.css" type="text/css">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script type="text/javascript">
<!--
function MM_preloadImages() { //v3.0
var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
function MM_swapImgRestore() { 
var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_findObj(n, d) { 
var p,i,x; if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
if(!x && d.getElementById) x=d.getElementById(n); return x;
}
function MM_swapImage() { 
var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
-->
</script>
</HEAD>
<BODY onLoad="MM_preloadImages('but_help_access_1.gif','but_help_main_1.gif','but_management_1.gif','but_help_routing_1.gif','but_help_status_1.gif','but_tools_1.gif','but_help_wireless_1.gif')">
<table width="750" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="21"><img src="c1_tl.gif" width="21" height="21" /></td>
<td width="708" background="bg1_t.gif"><img src="top_1.gif" width="390" height="21" /></td>
<td width="21"><img src="c1_tr.gif" width="21" height="21" /></td>
</tr>
<tr>
<td valign="top" background="bg1_l.gif"><img src="top_2.gif" width="21" height="69" /></td>
<td background="bg.gif"><table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="13%"><img src="logo.gif" width="270" height="69" /></td>
<td width="87%" align="right"><img src="description.gif" /></td>
</tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="20%" height="429" valign="top"><table width="100%" border="0" align="center" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><b>Help</b></td>
</tr>
<tr>
<td bgcolor="#000000" ><table width="56%" border="0" cellpadding="0" cellspacing="0" bgcolor="#1D1D1D">
<tr>
<td><a href="help_main.asp"><img src="but_help_main_1.gif" name="Image2" width="155" height="27" border="0" id="Image2" onmouseover="MM_swapImage('Image2','','but_help_main_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="2" >
<tr>
<td width="13%" align="right"><font color="#FFFFFF">&bull;</font></td>
<td width="87%"><b><a href="help_main.asp#lanski_dhcp_server" class="submenus">LAN &amp; DHCP Server</a></b></td>
</tr>
<!--<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="inbound_filter.asp" class="submenus"><b>Inbound Filter </b></a></td>
</tr>-->
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><b><a href="help_main.asp#main_wan" class="submenus">WAN</a></b></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><b><a href="help_main.asp#main_password" class="submenus">Password</a></b></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><b><a href="help_main.asp#main_time" class="submenus">Time</a><a href="help_access.asp#access_domain_filter" class="submenus"></a></b></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><b><a href="help_main.asp#main_ddns" class="submenus">Dynamic DNS</a><a href="help_access.asp#access_protocol_filter" class="submenus"></a></b></td>
</tr>
</table></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_wlan.asp"><img src="but_help_wireless_0.gif" name="Image31" width="155" height="27" border="0" id="Image31" onmouseover="MM_swapImage('Image31','','but_help_wireless_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_status.asp"><img src="but_help_status_0.gif" name="Image23" width="155" height="27" border="0" id="Image23" onmouseover="MM_swapImage('Image23','','but_help_status_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_routing.asp"><img src="but_help_routing_0.gif" name="Image30" width="155" height="27" border="0" id="Image22" onmouseover="MM_swapImage('Image30','','but_help_routing_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_access.asp"><img src="but_help_access_0.gif" name="Image24" width="155" height="27" border="0" id="Image24" onmouseover="MM_swapImage('Image24','','but_help_access_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_manage.asp"><img src="but_management_0.gif" name="Image21" width="155" height="27" border="0" id="Image21" onmouseover="MM_swapImage('Image21','','but_management_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_tools.asp"><img src="but_tools_0.gif" name="Image1" width="155" height="27" border="0" id="Image1" onmouseover="MM_swapImage('Image1','','but_tools_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
</table></td>
</tr>
</table>
<p></p>
<p>&nbsp;</p>
<p>&nbsp;</p></td>
<td width="2%"><img src="spacer.gif" width="10" height="15" /></td>
<td width="78%" valign="top"><table width="550" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">Main</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>The main screen enables you to configure the <A HREF="glossary.asp#def_LAN">LAN</A> &amp; <A HREF="glossary.asp#def_dhcp">DHCP</A> Server, set <A HREF="glossary.asp#def_WAN">WAN</A> parameters, create <A HREF="glossary.asp#def_administrator">Administrator</A> and User passwords, and set the local time, time zone, and default <A HREF="glossary.asp#def_NTP">NTP</A> server.</P>
<P> Click the items below for more information:</P>
<UL>
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet"> <b><A HREF="#lanski_dhcp_server">LAN &amp; DHCP Server</A></b></P>
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet"> <b><A HREF="#main_wan">WAN</A></b></P>
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet"> <b><A HREF="#main_password">Password</A></b></P>
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet"> <b><A HREF="#main_time">Time</A></b></P>
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet"> <b><A HREF="#main_ddns">Dynamic DNS</A></b></P>
</UL></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br> <a name="lanski_dhcp_server"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">LAN &amp; DHCP Server</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>This page enables you to set <A HREF="glossary.asp#def_LAN">LAN</A> and <A HREF="glossary.asp#def_dhcp">DHCP</A> properties, such as the <A HREF="glossary.asp#def_host_name">host
name</A>, <A HREF="glossary.asp#def_ip_address">IP address</A>, <A HREF="glossary.asp#def_subnet_mask">subnet
mask</A>, and <A HREF="glossary.asp#def_domain_name">domain name</A>.
LAN and DHCP profiles are listed in the DHCP table at the bottom of
the screen.</P>
<P> <SPAN STYLE="font-weight : bold;">Host Name:</SPAN><A NAME="lan&amp;dhcp_server_hostname"></A> Type the <A HREF="glossary.asp#def_host_name">host name</A> in the
text box. The host name is required by some <A HREF="glossary.asp#def_ISP">ISP</A>s.
The default host name is &quot;TEW-673GRU&quot;</P>
<P> <SPAN STYLE="font-weight : bold;">IP Address:</SPAN><A NAME="lan_dhcp_server_ipaddress"></A> This is the <A HREF="glossary.asp#def_ip_address">IP address</A> of
the router. The default IP address is 192.168.10.1.</P>
<P> <SPAN STYLE="font-weight : bold;">Subnet Mask:</SPAN><A NAME="lan_dhcp_server_subnet_mask"></A> Type the <A HREF="glossary.asp#def_subnet_mask">subnet mask</A> for
the router in the text box. The default subnet mask is <SPAN STYLE="font-style : normal;">255.255.255.0.</SPAN></P>
<P> <SPAN STYLE="font-weight : bold;">DHCP Server:</SPAN><A NAME="lan_dhcp_server_dhcp_server"></A> Enables the <A HREF="glossary.asp#def_dhcp">DHCP</A> server to allow
the router to automatically assign IP addresses to devices connecting
to the <A HREF="glossary.asp#def_LAN">LAN</A>
port or connected wirelessly to the TEW-673GRU .. DHCP is enabled by default.</P>
<P> All DHCP client computers are listed in the table at the bottom of
the screen, 
The table displays
the host name, IP address, and <A HREF="glossary.asp#def_MAC_address">MAC
address</A> of the client.</P>
<P> <SPAN STYLE="font-weight : bold;">Start IP:</SPAN><A NAME="lan_dhcp_server_start_ip"></A> Type an <A HREF="glossary.asp#def_ip_address">IP address</A> to serve
as the start of the IP range that <A HREF="glossary.asp#def_dhcp">DHCP</A> will use to assign IP addresses to all
wired and wireless
devices connected to the router.</P>
<P> <SPAN STYLE="font-weight : bold;">End IP:</SPAN><A NAME="lan_dhcp_server_end_ip"></A> Type an <A HREF="glossary.asp#def_ip_address">IP address</A> to serve
as the end of the IP range that <A HREF="glossary.asp#def_dhcp">DHCP</A> will use to assign IP addresses to all
wired and wireless
devices connected to the router.</P>
<P> <SPAN STYLE="font-weight : bold;">Domain Name:</SPAN><A NAME="lan_dhcp_server_domain_name"></A> Type the local <A HREF="glossary.asp#def_domain_name">domain name</A> of the network in the text box. This item is optional.</P>
<P> <strong>Lease Time: </strong>The lease time specifies the amount of connection time a network user be allowed with their current dynamic IP address. </P>
<P><strong>Static DHCP </strong><strong>: </strong>Reserves an IP address to a DHCP client. This ensures that the PC's IP address does not change. </P>
<P> <A HREF="help_main.asp">back to top</A></P></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br> <a name="main_wan"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">WAN</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>This screen enables you to set up the router <A HREF="glossary.asp#def_WAN">WAN</A> connection, specify the <A HREF="glossary.asp#def_IP">IP address</A> for the WAN, add 
<a href="http://192.168.10.1/glossary.asp#def_DNS">DNS </a> IP Addresses ,
enter the <A HREF="glossary.asp#def_MAC_address">MAC address</A>, and
set the <A HREF="glossary.asp#def_MTU">MTU</A>.</P>
<P> <SPAN STYLE="font-weight : bold;">Connection Type:</SPAN><A NAME="WAN_connection_type"></A> Select the connection type, either <A HREF="glossary.asp#def_dhcp">DHCP</A> client/Fixed IP or <A HREF="glossary.asp#def_PPPoE">PPPoE</A> , PPTP, L2TP, BigPond Cable, Russia PPPoE, Russia PPTP or Russia L2TP
from
the drop-down list.</P>
<P> When using DHCP client/Fixed IP, enter the following information in
the fields (some information is provided by your <A HREF="glossary.asp#def_ISP">ISP</A>):</P>
<P CLASS="Bullet"> <SPAN STYLE="font-weight : bold;">WAN IP:</SPAN><A NAME="WAN_WAN_IP"></A> Select whether you want the <a href="http://192.168.10.1/glossary.asp#def_ISP">ISP </a> to provide the <a href="http://192.168.10.1/glossary.asp#def_ip_address">IP address </a> automatically, or whether you want to assign a static IP address to the router <a href="http://192.168.10.1/glossary.asp#def_WAN">WAN </a>. <SPAN STYLE="font-weight : normal;"> When </SPAN><SPAN STYLE="font-style : italic;font-weight : normal;">Specify
IP </SPAN><SPAN STYLE="font-weight : normal;">is selected, type the </SPAN><A HREF="glossary.asp#def_ip_address"><SPAN STYLE="font-weight : normal;">IP
address</SPAN></A><SPAN STYLE="font-weight : normal;">, </SPAN><A HREF="glossary.asp#def_subnet_mask"><SPAN STYLE="font-weight : normal;">subnet
mask</SPAN></A><SPAN STYLE="font-weight : normal;">, and default </SPAN><A HREF="glossary.asp#def_gateway"><SPAN STYLE="font-weight : normal;">gateway</SPAN></A><SPAN STYLE="font-weight : normal;"> in the text boxes. Your </SPAN><A HREF="glossary.asp#def_ISP"><SPAN STYLE="font-weight : normal;">ISP</SPAN></A><SPAN STYLE="font-weight : normal;"> will provide you with this information.</SPAN></P>
<P CLASS="Bullet"> <SPAN STYLE="font-weight : bold;">DNS 1/2:</SPAN> <SPAN STYLE="font-weight : normal;">Type
up to two </SPAN><A HREF="glossary.asp#def_DNS"><SPAN STYLE="font-weight : normal;">DNS</SPAN></A><SPAN STYLE="font-weight : normal;"> numbers in the text boxes. Your </SPAN><A HREF="glossary.asp#def_ISP"><SPAN STYLE="font-weight : normal;">ISP</SPAN></A><SPAN STYLE="font-weight : normal;"> will provide you with this information.</SPAN></P>
<P CLASS="Bullet"> <SPAN STYLE="font-weight : bold;">MAC Address:</SPAN><A NAME="WAN_MAC_address"></A><SPAN STYLE="font-weight : normal;"> If required by your </SPAN><A HREF="glossary.asp#def_ISP"><SPAN STYLE="font-weight : normal;">ISP</SPAN></A><SPAN STYLE="font-weight : normal;">,
type the </SPAN><A HREF="glossary.asp#def_MAC_address"><SPAN STYLE="font-weight : normal;">MAC
address</SPAN></A><SPAN STYLE="font-weight : normal;"> of the router </SPAN><A HREF="glossary.asp#def_WAN"><SPAN STYLE="font-weight : normal;">WAN</SPAN></A><SPAN STYLE="font-weight : normal;"> interface in this field.</SPAN></P>
<P CLASS="Bullet">-----------------------------------------------------------------------------------------------------------------------------------</P>
<P> When using PPPoE, enter the following information in the fields (some
information is provided by your <A HREF="glossary.asp#def_ISP">ISP</A>):</P>
<P CLASS="Bullet"> <SPAN STYLE="font-weight : bold;">WAN IP:</SPAN><SPAN STYLE="font-weight : normal;"> Select whether you want the <A HREF="glossary.asp#def_ISP">ISP</A> to
provide the <A HREF="glossary.asp#def_ip_address">IP address</A> automatically, or whether you want to assign a static IP address to
the router <A HREF="glossary.asp#def_WAN">WAN</A>. When </SPAN><SPAN STYLE="font-style : italic;font-weight : normal;">Specify
IP </SPAN><SPAN STYLE="font-weight : normal;">is selected, type the
PPPoE </SPAN><A HREF="glossary.asp#def_ip_address"><SPAN STYLE="font-weight : normal;">IP
address</SPAN></A><SPAN STYLE="font-weight : normal;"> in the text
box. Your </SPAN><A HREF="glossary.asp#def_ISP"><SPAN STYLE="font-weight : normal;">ISP</SPAN></A><SPAN STYLE="font-weight : normal;"> will provide you with this information.</SPAN></P>
<p><strong>Service Name </strong><strong>: </strong> Type your <a href="http://192.168.10.1/glossary.asp#def_PPPoE">PPPoE </a> service name. </p>
<P CLASS="Bullet"> <SPAN STYLE="font-weight : bold;">User Name:</SPAN><SPAN STYLE="font-weight : normal;"> Type your <A HREF="glossary.asp#def_PPPoE">PPPoE</A> user name.</SPAN></P>
<P CLASS="Bullet"> <SPAN STYLE="font-weight : bold;">Password:</SPAN><SPAN STYLE="font-weight : normal;"> Type your <A HREF="glossary.asp#def_PPPoE">PPPoE</A> password.</SPAN></P>
<p><strong>Retype Password </strong><strong>: </strong> Type your <a href="http://192.168.10.1/glossary.asp#def_PPPoE">PPPoE </a> password again. </p>
<p><strong>DNS Primary: </strong>The primary Domain Name Server (DNS) IP address. This is provided by your ISP. <strong></strong></p>
<p><strong>DNS Secondary: </strong>The secondary Domain Name Server (DNS) IP address. This is provided by your ISP.</p>
<p> <strong>Auto-reconnect: </strong> Enables <em>Always-on </em>, <em>Manual </em> or <em>connect on demand </em> function. Connect on demand enables the the router to initiate a connection with your <a href="http://192.168.10.1/glossary.asp#def_ISP">ISP </a> when an Internet request is made to the router. When enabled, the router automatically connects to the Internet when you open your default browser. </p>
<P CLASS="Bullet"> <SPAN STYLE="font-weight : bold;">Idle Time Out:</SPAN><SPAN STYLE="font-weight : normal;"> Specify the time that will elapse before the router drops connection.</SPAN></P>
<p><strong>MTU </strong>: Type the <a href="http://192.168.10.1/glossary.asp#def_MTU">MTU </a> value in the text box. </p>
<p><span class="Bullet">-----------------------------------------------------------------------------------------------------------------------------------</span></p>
<P><SPAN STYLE="font-weight : bold;">PPTP:</SPAN><SPAN STYLE="font-weight : normal;"> Point-to-Point Tunneling Protocol uses TCP to deal data for tunnel maintenance, and uses PPP for sum up the information carried within the tunnel.
The data carried within the tunnel can be compressed or encrypted.
The encryption method used is RSA RC4. PPTP can operate
when the protocol is supported only on the client and the server located on the other end that the client is corresponds with.
No support is essential from any of the routers or servers within the network the two PCs are connecting across. </SPAN>
<P> <strong>L2TP:</strong> L2TP is often used as a tunneling mechanism to resell ADSL endpoint connectivity. An L2TP tunnel would sit between the user and the ISP the connection would be resold to, so the reselling ISP wouldn't appear as doing the transit. 
<P><strong>IP Address </strong><strong>: </strong> This is the <a href="http://192.168.10.1/glossary.asp#def_ip_address">IP address </a> of the router. The IP address is provided by ISP <strong></strong>
<p><strong>Subnet Mask </strong><strong>: </strong>The <a href="http://192.168.10.1/glossary.asp#def_subnet_mask">subnet mask </a> for the router in the text box which provided by ISP. <strong></strong></p>
<p><strong>Gateway: </strong>The gateway address of the network. Contact the ISP or network administrator for this information. <strong></strong></p>
<p><strong>DNS: </strong>Type the <a href="http://192.168.10.1/glossary.asp#def_DNS">DNS </a> IP addresses in the text boxes. Your <a href="http://192.168.10.1/glossary.asp#def_ISP">ISP </a> will provide you with this information. <strong></strong></p>
<p><strong>Server IP: </strong><strong></strong>Type the server IP address in the text box. Your ISP will provide you with this information. <strong></strong></p>
<p><strong>PPTP or L2TP Account: </strong>Type your PPTP or L2TP account number. <strong></strong></p>
<p><strong>PPTP or L2TP Password: </strong> Type your PPTP or L2TP password. <strong></strong></p>
<p><strong>PPTP or L2TP Retype password: </strong> Retype your PPTP or L2TP password again. <strong></strong></p>
<p><strong>Auto-reconnect: </strong> Enables <em>Always-on </em>, <em>Manual </em> or <em>connect on demand </em> function. Connect on demand enables the router to initiate a connection with your <a href="http://192.168.10.1/glossary.asp#def_ISP">ISP </a> when an Internet request is made to the router. When enabled, the router automatically connects to the Internet when you open your default browser. <strong></strong></p>
<p><strong>Idle Time Out: </strong>Specify the time that will elapse before the router drops connection. <strong></strong></p>
<p><strong>MTU: </strong>Type the <a href="http://192.168.10.1/glossary.asp#def_MTU">MTU </a> value in the text box. <strong></strong></p>
<p><strong>MPPE Enable: </strong><strong></strong>Select to enable Microsoft Point-to-Point Encryption <strong>. </strong>(Only for MSCHAPv2) </p>
<p><span class="Bullet">-----------------------------------------------------------------------------------------------------------------------------------</span></p>
<P><strong>Bigpond Cable:</strong> BigPond is Australia's largest Internet Service Provider and is Telstra's brand name for consumer broadband services. 
<P><br>
<strong>User Name: </strong> Type your <a href="http://192.168.10.1/glossary.asp#def_PPPoE">BigPond </a> user name. 
<p><strong>Password: </strong> Type your <a href="http://192.168.10.1/glossary.asp#def_PPPoE">BigPond </a> password. </p>
<p><strong>Retype Password </strong><strong>: </strong> Type your <a href="http://192.168.10.1/glossary.asp#def_PPPoE">BigPond </a> password again. </p>
<p><strong>Auth Server: </strong>sm-server : small mmo (sm) server </p>
<p>Dce-server : distributed computing environment (dce) server. </p>
<p><strong>Login Server IP: </strong><strong></strong>Type the server IP. Your ISP will provided this information. <strong></strong></p>
<p><strong>MAC Address: </strong> If required by your <a href="http://192.168.10.1/glossary.asp#def_ISP">ISP </a>, type the <a href="http://192.168.10.1/glossary.asp#def_MAC_address">MAC address </a> of the router <a href="http://192.168.10.1/glossary.asp#def_WAN">WAN </a> interface in this field. </p>
<p><span class="Bullet">-----------------------------------------------------------------------------------------------------------------------------------</span></p>
<P> <strong>Russia </strong><strong> PPPoE: </strong>When using PPPoE, enter the following information in the fields (some information is provided by your <a href="http://192.168.10.1/glossary.asp#def_ISP">ISP </a>)
<P><strong>WAN IP: </strong> Select whether you want the <a href="http://192.168.10.1/glossary.asp#def_ISP">ISP </a> to provide the <a href="http://192.168.10.1/glossary.asp#def_ip_address">IP address </a> automatically, or whether you want to assign a static IP address to the router <a href="http://192.168.10.1/glossary.asp#def_WAN">WAN </a>. When <em>Specify IP </em>is selected, type the PPPoE <a href="http://192.168.10.1/glossary.asp#def_ip_address">IP address </a> in the text box. Your <a href="http://192.168.10.1/glossary.asp#def_ISP">ISP </a> will provide you with this information. 
<p><strong>Service Name </strong><strong>: </strong> Type your <a href="http://192.168.10.1/glossary.asp#def_PPPoE">PPPoE </a> service name. </p>
<p><strong>User Name: </strong> Type your <a href="http://192.168.10.1/glossary.asp#def_PPPoE">PPPoE </a> user name. </p>
<p><strong>Password: </strong> Type your <a href="http://192.168.10.1/glossary.asp#def_PPPoE">PPPoE </a> password. </p>
<p><strong>Retype Password </strong><strong>: </strong> Type your <a href="http://192.168.10.1/glossary.asp#def_PPPoE">PPPoE </a> password again. <br>
<strong>Auto-reconnect: </strong> Enables <em>Always-on </em>, <em>Manual </em> or <em>connect on demand </em> function. Connect on demand enables the router to initiate a connection with your <a href="http://192.168.10.1/glossary.asp#def_ISP">ISP </a> when an Internet request is made to the router. When enabled, the router automatically connects to the Internet when you open your default browser. </p>
<p><strong>Idle Time Out: </strong> Specify the time that will elapse before the router drops connection. </p>
<strong>MTU </strong>: Type the <a href="http://192.168.10.1/glossary.asp#def_MTU">MTU </a> value in the text box. <br>
<p>WAN physical settings: Russia PPPoE supports dual WAN access. Configure the second WAN connection below: <br>
Dynamic IP: Select this option if the WAN IP address is obtained automatically. <br>
Static IP: Select this option if the WAN IP address is static. Then fill out the fields below: <br>
<strong>IP Address </strong><strong>: </strong> This is the <a href="http://192.168.10.1/glossary.asp#def_ip_address">IP address </a> of the router. The IP address is provided by ISP <strong></strong></p>
<p><strong>Subnet Mask </strong><strong>: </strong>The <a href="http://192.168.10.1/glossary.asp#def_subnet_mask">subnet mask </a> for the router in the text box which provided by ISP. <strong></strong></p>
<p><strong>Gateway: </strong>The gateway address of the network. Contact the ISP or network administrator for this information. <strong><br>
<br>
DNS Primary: </strong>The primary Domain Name Server (DNS) IP address. This is provided by your ISP. </p>
<p><strong>DNS Secondary: </strong>The secondary Domain Name Server (DNS) IP address. This is provided by your ISP. </p>
<p><span class="Bullet">-----------------------------------------------------------------------------------------------------------------------------------</span></p>
<P><strong>Russia </strong><strong> PPTP: </strong> When using PPTP, enter the following information in the fields (some information is provided by your <a href="http://192.168.10.1/glossary.asp#def_ISP">ISP </a>): <br>
<br>
<strong>IP Address </strong><strong>: </strong> This is the <a href="http://192.168.10.1/glossary.asp#def_ip_address">IP address </a> of the router. The IP address is provided by ISP <strong></strong>
<p><strong>Subnet Mask </strong><strong>: </strong>The <a href="http://192.168.10.1/glossary.asp#def_subnet_mask">subnet mask </a> for the router in the text box which provided by ISP. <strong></strong></p>
<p><strong>Gateway: </strong>The gateway address of the network. Contact the ISP or network administrator for this information. <strong></strong></p>
<p><strong>DNS: </strong>Type the <a href="http://192.168.10.1/glossary.asp#def_DNS">DNS </a> IP addresses in the text boxes. Your <a href="http://192.168.10.1/glossary.asp#def_ISP">ISP </a> will provide you with this information. <strong></strong></p>
<p><strong>Server IP: </strong><strong></strong>Type the server IP address in the text box. Your ISP will provide you with this information. <strong></strong></p>
<p><strong>PPTP Account: </strong>Type your PPTP account number. <strong></strong></p>
<p><strong>PPTP: </strong> Type your PPTP password. <strong></strong></p>
<p><strong>PPTP Retype password: </strong> Retype your PPTP password again. <strong></strong></p>
<strong>Auto-reconnect: </strong> Enables <em>Always-on </em>, <em>Manual </em> or <em>connect on demand </em> function. Connect on demand enables the router to initiate a connection with your <a href="http://192.168.10.1/glossary.asp#def_ISP">ISP </a> when an Internet request is made to the router.
<p>When enabled, the router automatically connects to the Internet when you open your default browser. <strong></strong></p>
<p><strong>Idle Time Out: </strong>Specify the time that will elapse before the router drops connection. <strong></strong></p>
<p><strong>MTU: </strong>Type the <a href="http://192.168.10.1/glossary.asp#def_MTU">MTU </a> value in the text box. <strong></strong></p>
<p><strong>MPPE Enable: </strong><strong></strong>Select to enable Microsoft Point-to-Point Encryption <strong>. </strong>(Only for MSCHAPv2) </p> 
<p><span class="Bullet">-----------------------------------------------------------------------------------------------------------------------------------</span></p>
<p><strong>Russia </strong><strong> L2TP: </strong><strong></strong>When using L2TP, enter the following information in the fields (some information is provided by your <a href="http://192.168.10.1/glossary.asp#def_ISP">ISP </a>): </p>
<p><strong>IP Address </strong><strong>: </strong> This is the <a href="http://192.168.10.1/glossary.asp#def_ip_address">IP address </a> of the router. The IP address is provided by ISP <strong></strong></p>
<p><strong>Subnet Mask </strong><strong>: </strong>The <a href="http://192.168.10.1/glossary.asp#def_subnet_mask">subnet mask </a> for the router in the text box which provided by ISP. <strong></strong></p>
<p><strong>Gateway: </strong>The gateway address of the network. Contact the ISP or network administrator for this information. <strong></strong></p>
<p><strong>DNS: </strong>Type the <a href="http://192.168.10.1/glossary.asp#def_DNS">DNS </a> IP addresses in the text boxes. Your <a href="http://192.168.10.1/glossary.asp#def_ISP">ISP </a> will provide you with this information. <strong></strong></p>
<p><strong>Server IP\Name: </strong> Type the server IP address in the text box. Your ISP will provide you with this information. <strong></strong></p>
<p><strong>L2TP Account: </strong>Type your L2TP account number. <strong></strong></p>
<p><strong>L2TP Password: </strong> Type your L2TP password. <strong></strong></p>
<p><strong>L2TP Retype password: </strong> Retype your L2TP password again. <strong></strong></p>
<p><strong>Auto-reconnect: </strong> Enables <em>Always-on </em>, <em>Manual </em> or <em>connect on demand </em> function. Connect on demand enables the router to initiate a connection with your <a href="http://192.168.10.1/glossary.asp#def_ISP">ISP </a> when an Internet request is made to the router. When enabled, the router automatically connects to the Internet when you open your default browser. <strong></strong></p>
<p><strong>Idle Time Out: </strong>Specify the time that will elapse before the router drops connection. <strong></strong></p>
<p><strong>MTU: </strong>Type the <a href="http://192.168.10.1/glossary.asp#def_MTU">MTU </a> value in the text box. <strong></strong></p>
<p><A HREF="help_main.asp">back to top</A></p></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br> <a name="main_password"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">Password</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>This screen enables you to set administrative and user passwords.
These passwords are used to gain access to the router interface.</P>
<P> <SPAN STYLE="font-weight : bold;">Administrator:</SPAN><A NAME="password_administrator"></A> Type the password the <A HREF="glossary.asp#def_administrator">Administrator</A> will use to log in to the system. The password must be typed again
for confirmation.</P>
<P> <SPAN STYLE="font-weight : bold;">User:</SPAN><A NAME="password_user"></A> Users can type a password to be used for logging in to the system.
The password must be typed again for confirmation.</P>
<P CLASS="Note"> <SPAN STYLE="font-weight : bold;">Note:</SPAN> Users do not have
permission to configure router functions.</P>
<p><A HREF="help_main.asp">back to top</A></P></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br> <a name="main_time"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">Time</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>This screen enables you to set the time and date for the router's
realtime clock, select your time zone, specify an <A HREF="glossary.asp#def_NTP">NTP</A> server, and enable or disable daylight saving.</P>
<P> <SPAN STYLE="font-weight : bold;">Local Time:</SPAN><A NAME="time_local_time"></A> Displays the local time and date.</P>
<P> <SPAN STYLE="font-weight : bold;">Time Zone:</SPAN><A NAME="time_time_zone"></A> Select your time zone from the drop-down list.</P>
<P><strong>Synchronize the clock with: </strong>Select the clock adjustment method form the drop-down list. </P>
<p><strong> &#8231;&nbsp;Automatic:</strong> Automatically adjust the system time from NTP Server. </p>
<p><strong> &#8231;&nbsp;Manual:</strong> Manually adjust the system time when you press the Set Time button. </p>
<P> <SPAN STYLE="font-weight : bold;">Default NTP Server:</SPAN><A NAME="time_default_ntp_server"></A> Type the <A HREF="glossary.asp#def_NTP">NTP</A> server address in the
text box to enable the router to automatically set the time from the
Internet NTP server.</P>
<P> <SPAN STYLE="font-weight : bold;">Set the Time:</SPAN><SPAN STYLE="font-style : normal;"><A NAME="time_set_the_time"></A> Select the date and time from the drop-down lists, and click </SPAN><SPAN STYLE="font-style : italic;font-weight : normal;">Set
Time</SPAN><SPAN STYLE="font-style : normal;"> to set the router's
internal clock to the correct date and time.</SPAN></P>
<P> <SPAN STYLE="font-weight : bold;">Daylight Saving:</SPAN><A NAME="time_daylight_saving"></A> Enables you to enable or disable daylight saving time. When enabled,
select the start and end date for daylight saving time.</P>
<P> <A HREF="help_main.asp">back to top</A></P></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br> <a name="main_ddns"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">Dynamic DNS</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><p>Dynamic DNS (Domain Name Service) is a method of keeping a domain name linked
to a changing (dynamic) IP address. With most Cable and DSL connections, you
are assigned a dynamic IP address and that address is used only for the duration
of that specific connection. You can setup your DDNS service and the router
will automatically update your DDNS server every time it receives a different
IP address.
First, you need to register your preferred DNS with the DDNS provider. Then, please select the DDNS address in the Server Address and fill the related information in the below fields: Host
Name, User Name and Password.
</p>
<p><a href="help_main.asp">back to top</a></p></td>
</tr>
</table></td>
</tr>
</table>
<p> <a name="tools_setup_wizard"></a> </p>
<br>
<br></td>
</tr>
</table></td>
<td background="bg1_r.gif">&nbsp;</td>
</tr>
<tr>
<td><img src="c1_bl.gif" width="21" height="20" /></td>
<td align="right" background="bg1_b.gif"><img src="copyright.gif" width="264" height="20" /></td>
<td><img src="c1_br.gif" width="21" height="20" /></td>
</tr>
</table>
</BODY>
</HTML>