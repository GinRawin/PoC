<html>
<head>
<title>TRENDNET | TEW-673GRU | Wizard</title>
<meta http-equiv="Content-Type" content="text/html;">
<link rel="stylesheet" href="style.css" type="text/css">
<script language="JavaScript" src="public_msg.js"></script>
<script language="JavaScript" src="public.js"></script>
<SCRIPT LANGUAGE="JavaScript">
function loadSettings(){
set_checked("<% CmoGetCfg("asp_temp_43","none"); %>", get_by_name("asp_temp_43"));
}
function send_request(){
var ip = get_by_id("asp_temp_41").value;
var mask = get_by_id("asp_temp_42").value;
var dhcp = get_by_name("asp_temp_43");
var start_ip = get_by_id("asp_temp_44").value;
var end_ip = get_by_id("asp_temp_45").value;
var ip_addr_msg = replace_msg(all_ip_addr_msg,"IP address");
var start_ip_addr_msg = replace_msg(all_ip_addr_msg,"Start IP address");
var end_ip_addr_msg = replace_msg(all_ip_addr_msg,"End IP address");
var temp_ip_obj = new addr_obj(ip.split("."), ip_addr_msg, false, false);
var temp_mask_obj = new addr_obj(mask.split("."), subnet_mask_msg, false, false);
var temp_start_ip_obj = new addr_obj(start_ip.split("."), start_ip_addr_msg, false, false);
var temp_end_ip_obj = new addr_obj(end_ip.split("."), end_ip_addr_msg, false, false);
if (!check_address(temp_ip_obj) || !check_mask(temp_mask_obj)){	
return false;	
}
if (dhcp[0].checked){
if (!check_address(temp_start_ip_obj) || !check_address(temp_end_ip_obj)){
return false;
}
if (!check_domain(temp_ip_obj, temp_mask_obj, temp_start_ip_obj)){
alert(addstr(msg[MSG2],"Start IP address"));
return false;
}
if (!check_domain(temp_ip_obj, temp_mask_obj, temp_end_ip_obj)){
alert(addstr(msg[MSG2],"End IP address"));
return false;
}
if (!check_ip_order(temp_start_ip_obj, temp_end_ip_obj)){
alert(msg[MSG4]);
return false;
}
}
send_submit("form1");
}
function check_dhcp_range(){
var lan_ip = get_by_id("asp_temp_41").value.split(".");
var start_ip3 = get_by_id("asp_temp_44").value.split(".");
var end_ip3 = get_by_id("asp_temp_45").value.split(".");
var enrty_IP = lan_ip[2];	
get_by_id("asp_temp_44").value = lan_ip[0] +"."+lan_ip[1]+"." + enrty_IP +"." + start_ip3[3];
get_by_id("asp_temp_45").value = lan_ip[0] +"."+lan_ip[1]+"." + enrty_IP +"." + end_ip3[3];
}
</script>
</head>
<body onLoad="loadSettings();">
<table width="450" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="21"><img src="c1_tl.gif" width="21" height="21" /></td>
<td width="708" background="bg1_t.gif"><img src="top_1.gif" width="390" height="21" /></td>
<td width="21"><img src="c1_tr.gif" width="21" height="21" /></td>
</tr>
<tr>
<td valign="top" background="bg1_l.gif"><img src="top_2.gif" width="21" height="69" /></td>
<td background="bg.gif"><table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="78%" valign="top"><table width="98%" border="0" cellpadding="0" cellspacing="0" class="tabBigTitle">
<tr>
<td class="headerbg2">Set LAN &amp; DHCP Server</td>
</tr>
<tr>
<td valign="top"><TABLE width="98%" height=200 border="0" align=center cellpadding="3" cellspacing="1">
<TBODY>
<TR>
<TD align="center" valign="top" bgcolor="#DDDDDD"><TABLE width="100%" align=center border=0>
<TBODY>
<TR>
<TD><form name="form1" id="form1" method="post" action="apply.cgi">
<input type="hidden" id="html_response_page" name="html_response_page" value="wizard5.asp">
<input type="hidden" id="html_response_return_page" name="html_response_return_page" value="wizard3.asp">
<input type="hidden" id="reboot_type" name="reboot_type" value="none">
<table width="100%" border="0" cellpadding="3" cellspacing="1">
<tr>
<td width="144" class="wizleft" >LAN IP Address</td>
<td width="235" class="wizright"><font face="Arial" color="#000000">
<input type="text" id="asp_temp_41" name="asp_temp_41" size="16" maxlength="15" onChange="check_dhcp_range()" value="<% CmoGetCfg("asp_temp_41","none"); %>">
</font></td>
</tr>
<tr>
<td class="wizleft" >LAN Subnet Mask</td>
<td class="wizright"><font face="Arial" color="#000000">
<input type="text" id="asp_temp_42" name="asp_temp_42" size="16" maxlength="15" value="<% CmoGetCfg("asp_temp_42","none"); %>">
</font></td>
</tr>
<tr>
<td class="wizleft" >DHCP Server</td>
<td class="wizright"><font face="Arial" color="#000000">
<input type="radio" name="asp_temp_43" value="1" onClick='disable_dhcp(get_by_name("asp_temp_43")[1].checked, get_by_id("asp_temp_44"), get_by_id("asp_temp_45"));'>
Enable
<input type="radio" name="asp_temp_43" value="0" onClick='disable_dhcp(get_by_name("asp_temp_43")[1].checked, get_by_id("asp_temp_44"), get_by_id("asp_temp_45"));'">
Disable</font></td>
</tr>
<tr>
<td class="wizleft" >Range Start</td>
<td class="wizright"><font face="Arial" color="#000000">
<input type="text" id="asp_temp_44" name="asp_temp_44" size="16" maxlength="15" value="<% CmoGetCfg("asp_temp_44","none"); %>">
</font></td>
</tr>
<tr>
<td class="wizleft" >Range End</td>
<td class="wizright"><font face="Arial" color="#000000">
<input type="text" id="asp_temp_45" name="asp_temp_45" size="16" maxlength="15" value="<% CmoGetCfg("asp_temp_45","none"); %>">
</font></td>
</tr>
</table>
<br>
<table border="0" align="center" cellpadding="2" cellspacing="2">
<tr>
<td align="center"><input name="back" type="button" class="ButtonSmall" id="back" onClick="window.location='wizard2.asp'" value="&lt; Back">
<input name="next" type="button" class="ButtonSmall" id="next" onClick="send_request()" value="Next &gt;">
<input name="exit" type="button" class="ButtonSmall" id="exit" onClick="exit_wizard()" value="Exit"></td>
</tr>
</table>
</form></TD>
</TR>
<TR>
<TD>&nbsp;</TD>
</TR>
</TBODY>
</TABLE></TD>
</TR>
</TBODY>
</TABLE>
<br>
</td>
</tr>
</table></td>
</tr>
</table></td>
<td background="bg1_r.gif">&nbsp;</td>
</tr>
<tr>
<td><img src="c1_bl.gif" width="21" height="20" /></td>
<td height="20" background="bg1_b.gif">&nbsp;</td>
<td><img src="c1_br.gif" width="21" height="20" /></td>
</tr>
</table>
</body>
</html>
