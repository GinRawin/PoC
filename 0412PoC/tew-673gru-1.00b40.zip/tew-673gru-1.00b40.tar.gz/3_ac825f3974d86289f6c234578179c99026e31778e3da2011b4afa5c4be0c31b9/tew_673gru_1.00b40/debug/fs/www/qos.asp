<html>
<head>
<meta http-equiv="Content-Type" content="text/html;">
<title>TRENDNET | TEW-673GRU | Access | QoS</title>
<link rel="stylesheet" href="style.css" type="text/css">
<script language="JavaScript" src="public_msg.js"></script>
<script language="JavaScript" src="public.js"></script>
<SCRIPT LANGUAGE="JavaScript">
var submit_button_flag = 0;
var rule_max_num = 10;
function loadSettings(){
set_checked(get_by_id("traffic_shaping").value, get_by_id("qos_traffic_shaping"));

set_checked(get_by_id("qos_enable").value, get_by_id("qos_engine_enabled"));
set_checked(get_by_id("auto_classification").value, get_by_id("qos_auto_classification"));
set_checked(get_by_id("qos_dyn_fragmentation").value, get_by_id("qos_dyn_frag"));
for (var i = 0; i < rule_max_num; i++){
var temp_qos;
if (i > 9){
temp_qos = get_by_id("qos_rule_" + i).value;
}else{
temp_qos = get_by_id("qos_rule_0" + i).value;	
}
if(temp_qos ==""){
if (i > 9){
get_by_id("qos_rule_" + i).value = "0//1/0/0/6/0.0.0.0/255.255.255.255/0/65535/0.0.0.0/255.255.255.255/0/65535";
}else{
get_by_id("qos_rule_0" + i).value = "0//1/0/0/6/0.0.0.0/255.255.255.255/0/65535/0.0.0.0/255.255.255.255/0/65535";
}
}

}
qos_traffic_shaping_click(get_by_id("qos_traffic_shaping").checked);
set_qos_rule();
}
function set_qos_rule(){
for (var i = 0; i < rule_max_num; i++){
var temp_qos;
if (i > 9){
temp_qos = (get_by_id("qos_rule_" + i).value).split("/");
}else{
temp_qos = (get_by_id("qos_rule_0" + i).value).split("/");	
}
if (temp_qos.length > 1){
if (temp_qos[0] == "1"){
get_by_id("qos_rule_enabled" + i).checked = true;
}
get_by_id("name" + i).value = temp_qos[1];
get_by_id("priority" + i).value = temp_qos[2];
set_protocol(i, temp_qos[5], get_by_id("protocol_select" + i));
get_by_id("local_start_ip" + i).value = temp_qos[6];
get_by_id("local_end_ip" + i).value = temp_qos[7];
get_by_id("local_start_port" + i).value = temp_qos[8];
get_by_id("local_end_port" + i).value = temp_qos[9];
get_by_id("remote_start_ip" + i).value = temp_qos[10];
get_by_id("remote_end_ip" + i).value = temp_qos[11];
get_by_id("remote_start_port" + i).value = temp_qos[12];
get_by_id("remote_end_port" + i).value = temp_qos[13];
if( get_by_id("qos_traffic_shaping").checked && get_by_id("qos_engine_enabled").checked){
detect_protocol_change_port(get_by_id("protocol_select"+i).selectedIndex,i);
}
}
}
}
function set_protocol(i, which_value, obj){
set_selectIndex(which_value,obj);
get_by_id("protocol"+i).disabled=true;
if(which_value != obj.options[obj.selectedIndex].value){
get_by_id("protocol"+i).disabled=false;
get_by_id("protocol_select"+i).selectedIndex = 5;
}
get_by_id("protocol"+i).value=which_value;
}
function qos_max_trans_rate_selector(value){
get_by_id("qos_uplink").value = value;

get_by_id("qos_max_trans_rate_select").value = 0;	
}
function qos_traffic_shaping_click(obj_chk){
var is_disabled = !obj_chk;

get_by_id("qos_uplink").disabled = is_disabled;
get_by_id("qos_max_trans_rate_select").disabled = is_disabled;



get_by_id("qos_engine_enabled").disabled = is_disabled;
qos_enable_click(get_by_id("qos_engine_enabled").checked);
}
function qos_auto_uplink_click(obj_chk){
var is_disabled = obj_chk;
get_by_id("qos_uplink").disabled = is_disabled;
get_by_id("qos_max_trans_rate_select").disabled = is_disabled;
}
function qos_enable_click(obj_chk){
var is_disabled = !(obj_chk && get_by_id("qos_traffic_shaping").checked);
get_by_id("qos_auto_classification").disabled = is_disabled;
get_by_id("qos_dyn_frag").disabled = is_disabled;
for(var i=0;i<rule_max_num;i++){
get_by_id("qos_rule_enabled"+i).disabled = is_disabled;
get_by_id("name"+i).disabled = is_disabled;
get_by_id("priority"+i).disabled = is_disabled;
get_by_id("protocol"+i).disabled = is_disabled;
get_by_id("protocol_select"+i).disabled = is_disabled;
get_by_id("local_start_ip"+i).disabled = is_disabled;
get_by_id("local_end_ip"+i).disabled = is_disabled;
get_by_id("local_start_port"+i).disabled = is_disabled;
get_by_id("local_end_port"+i).disabled = is_disabled;
get_by_id("remote_start_ip"+i).disabled = is_disabled;
get_by_id("remote_end_ip"+i).disabled = is_disabled;
get_by_id("remote_start_port"+i).disabled = is_disabled;
get_by_id("remote_end_port"+i).disabled = is_disabled;
}
}	
function protocol_change(i){
var obj_name = get_by_id("protocol_select"+i);
if(obj_name.selectedIndex < 5){ 
get_by_id("protocol"+i).disabled=true;
get_by_id("protocol"+i).value=obj_name.options[obj_name.selectedIndex].value;
}else if(get_by_id("protocol_select"+i).selectedIndex == 5){ 
get_by_id("protocol"+i).disabled=false;
get_by_id("protocol"+i).value="";
}
}
function detect_protocol_change_port(proto,i){

if((proto == 0)||(proto == 4)||(proto == 5)){
get_by_id("local_start_port"+i).disabled=true;
get_by_id("local_end_port"+i).disabled=true;
get_by_id("remote_start_port"+i).disabled=true;
get_by_id("remote_end_port"+i).disabled=true;
}else{
get_by_id("local_start_port"+i).disabled=false;
get_by_id("local_end_port"+i).disabled=false;
get_by_id("remote_start_port"+i).disabled=false;
get_by_id("remote_end_port"+i).disabled=false;
}
}	
function send_request(){
get_by_id("traffic_shaping").value = get_checked_value(get_by_id("qos_traffic_shaping"));

get_by_id("qos_enable").value = get_checked_value(get_by_id("qos_engine_enabled"));
get_by_id("auto_classification").value = get_checked_value(get_by_id("qos_auto_classification"));
get_by_id("qos_dyn_fragmentation").value = get_checked_value(get_by_id("qos_dyn_frag"));

if(get_by_id("qos_traffic_shaping").checked){
var qos_uplink = parseInt(get_by_id("qos_uplink").value);	
if(qos_uplink > 102400 || 20 > qos_uplink ){
alert("Max transmission rate should be between 8 kbps and 100 Mbps, inclusive.");
return false;
}	
}

var count = 0;
for (var i = 0; i < rule_max_num; i++){	
var local_start_ip = get_by_id("local_start_ip" + i).value;
var local_end_ip = get_by_id("local_end_ip" + i).value;
var remote_start_ip = get_by_id("remote_start_ip" + i).value;
var remote_end_ip = get_by_id("remote_end_ip" + i).value;
var local_start_port = parseInt(get_by_id("local_start_port" + i).value);
var local_end_port = parseInt(get_by_id("local_end_port" + i).value);
var remote_start_port = parseInt(get_by_id("remote_start_port" + i).value);
var remote_end_port = parseInt(get_by_id("remote_end_port" + i).value);	
var ip_addr_msg = replace_msg(all_ip_addr_msg,"IP address");
var remote_ip_addr_msg = replace_msg(all_ip_addr_msg,"Remote IP address");
var temp_local_start_ip_obj = new addr_obj(local_start_ip.split("."), ip_addr_msg, false, false);
var temp_local_end_ip_obj = new addr_obj(local_end_ip.split("."), ip_addr_msg, false, false);
var temp_remote_start_ip_obj = new addr_obj(remote_start_ip.split("."), remote_ip_addr_msg, false, false);
var temp_remote_end_ip_obj = new addr_obj(remote_end_ip.split("."), remote_ip_addr_msg, false, false);
var temp_qos;
var check_name = "";
if (i > 9){
get_by_id("qos_rule_" + i).value = "";
}else{
get_by_id("qos_rule_0" + i).value = "";
}

if(get_by_id("protocol_select" + i).selectedIndex == 5){
temp_obj = get_by_id("protocol" + i);
var protocol_msg = replace_msg(check_num_msg, "protocol", 0, 255);
obj = new varible_obj(temp_obj.value, protocol_msg, 0, 255, false);
if(!check_varible(obj)){
return false;
}	
}
if(get_by_id("name" + i).value != ""){

check_name = get_by_id("name" + i).value;
if(Find_word(check_name,"'") || Find_word(check_name,'"') || Find_word(check_name,"/")){
alert("Rules name"+" "+ i +" "+"invalid. Illegal character ',/,''");
get_by_id("name"+i).focus();
get_by_id("name"+i).select();
return false;
}	

temp_obj = get_by_id("priority" + i);
var priority_msg = replace_msg(check_num_msg, "Priority", 1, 8);
pro_obj = new varible_obj(temp_obj.value, priority_msg, 1, 8, false);

var priority_value = get_by_id("priority" + i).value;
var str=new String(parseFloat(priority_value));
if(!check_varible(pro_obj)){
return false;
} 

if(local_start_ip != "0.0.0.0" && !check_address(temp_local_start_ip_obj)){
return false;
}
if(local_end_ip != "255.255.255.255" && !check_address(temp_local_end_ip_obj)){
return false;
}
if(remote_start_ip != "0.0.0.0" && !check_address(temp_remote_start_ip_obj)){
return false;
}
if(remote_end_ip != "255.255.255.255" && !check_address(temp_remote_end_ip_obj)){
return false;
}

if((get_by_id("protocol_select"+i).selectedIndex ==1) || (get_by_id("protocol_select"+i).selectedIndex ==2) || (get_by_id("protocol_select"+i).selectedIndex ==3)){
if(local_start_port < 0 || local_start_port > 65535){
alert("Local start port should be between 0 and 65535 inclusive.");
get_by_id("local_start_port"+i).focus();
get_by_id("local_start_port"+i).select();
return false;
}else if(local_end_port < 0 || local_end_port > 65535){
alert("Local end port should be between 0 and 65535 inclusive.");
get_by_id("local_end_port"+i).focus();
get_by_id("local_end_port"+i).select();
return false;
}else if(local_start_port > local_end_port){	
alert("Local start port must be smaller than Local end port.");
get_by_id("local_start_port"+i).focus();
get_by_id("local_start_port"+i).select();
return false;
}	
if(remote_start_port < 0 || remote_start_port > 65535){
alert("Remote start port should be between 0 and 65535 inclusive.");
get_by_id("remote_start_port"+i).focus();
get_by_id("remote_start_port"+i).select();
return false;
}else if(remote_end_port < 0 || remote_end_port > 65535){
alert("Remote end port should be between 0 and 65535 inclusive.");
get_by_id("remote_end_port"+i).focus();
get_by_id("remote_end_port"+i).select();
return false;
}else if(remote_start_port > remote_end_port){
alert("Remote start port must be smaller than Remote end port.");
get_by_id("remote_start_port"+i).focus();
get_by_id("remote_start_port"+i).select();
return false;
}
}
}
else{
if(get_by_id("qos_rule_enabled" + i).checked == true){
alert("A name is required for rule number"+" "+i+".");
return false;
}	
}	
if (count > 9){
temp_qos = get_by_id("qos_rule_" + count);
}else{
temp_qos = get_by_id("qos_rule_0" + count);
}

temp_qos.value = get_checked_value(get_by_id("qos_rule_enabled" + i)) + "/" + get_by_id("name" + i).value + "/" + get_by_id("priority" + i).value	+ "/" 
+ "0/0/" 
+ get_by_id("protocol" + i).value + "/" 
+ get_by_id("local_start_ip" + i).value + "/" + get_by_id("local_end_ip" + i).value + "/" + get_by_id("local_start_port" + i).value + "/" 
+ get_by_id("local_end_port" + i).value+ "/" + get_by_id("remote_start_ip" + i).value + "/" 
+ get_by_id("remote_end_ip" + i).value + "/" + get_by_id("remote_start_port" + i).value + "/" + get_by_id("remote_end_port" + i).value;
count++;
}

for (var i = 0; i < rule_max_num; i++){	
var local_start_ip = get_by_id("local_start_ip" + i).value;
var local_end_ip = get_by_id("local_end_ip" + i).value;
var remote_start_ip = get_by_id("remote_start_ip" + i).value;
var remote_end_ip = get_by_id("remote_end_ip" + i).value;
var local_start_port = parseInt(get_by_id("local_start_port" + i).value);
var local_end_port = parseInt(get_by_id("local_end_port" + i).value);
var remote_start_port = parseInt(get_by_id("remote_start_port" + i).value);
var remote_end_port = parseInt(get_by_id("remote_end_port" + i).value);	
var rule_protocol = get_by_id("protocol_select"+i).selectedIndex;


for (var j = 0; j < rule_max_num; j++){

if(j!=i){
var local_start_ip_chk = get_by_id("local_start_ip" + j).value;
var local_end_ip_chk = get_by_id("local_end_ip" + j).value;
var remote_start_ip_chk = get_by_id("remote_start_ip" + j).value;
var remote_end_ip_chk = get_by_id("remote_end_ip" + j).value;
var local_start_port_chk = parseInt(get_by_id("local_start_port" + j).value);
var local_end_port_chk = parseInt(get_by_id("local_end_port" + j).value);
var remote_start_port_chk = parseInt(get_by_id("remote_start_port" + j).value);
var remote_end_port_chk = parseInt(get_by_id("remote_end_port" + j).value);	
var rule_protocol_chk = get_by_id("protocol_select"+j).selectedIndex;


if(get_by_id("qos_rule_enabled" + i).checked != true){

continue;	
}

if(get_by_id("qos_rule_enabled" + j).checked != true){

continue;	
}

if(rule_protocol_chk != rule_protocol){


continue;	
}

if(local_start_ip_chk != local_start_ip){


continue;	
}
if(local_end_ip_chk != local_end_ip){


continue;	
}
if(remote_start_ip_chk != remote_start_ip){


continue;
}
if(remote_end_ip_chk != remote_end_ip){


continue;
}

if( (rule_protocol ==1) || (rule_protocol ==2) || (rule_protocol ==3)){
if(local_start_port_chk != local_start_port){


continue;
}else if(local_end_port_chk != local_end_port){


continue;
}
if(remote_start_port_chk != remote_start_port){


continue;
}else if(remote_end_port_chk != remote_end_port){


continue;	
}

alert("Rules"+" "+i+" "+"is seting same as Rules"+" "+j+".");
return false;	
}	
}	
}	
}
if(submit_button_flag == 0){
submit_button_flag = 1;
return true;
}else{
return false;
}
} 
function MM_openBrWindow(theURL,winName,features) { 
window.open(theURL,winName,features);
}
</SCRIPT>
</head>
<body onLoad="MM_preloadImages('but_wizard_1.gif','but_status_1.gif','but_tools_1.gif','but_main_1.gif','but_wireless_1.gif','but_routing_1.gif','but_access_1.gif','but_management_1.gif');loadSettings()">
<table width="750" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="21"><img src="c1_tl.gif" width="21" height="21" /></td>
<td width="708" background="bg1_t.gif"><img src="top_1.gif" width="390" height="21" /></td>
<td width="21"><img src="c1_tr.gif" width="21" height="21" /></td>
</tr>
<tr>
<td valign="top" background="bg1_l.gif"><img src="top_2.gif" width="21" height="69" /></td>
<td background="bg.gif"><table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="13%"><img src="logo.gif" width="270" height="69" /></td>
<td width="87%" align="right"><img src="description.gif" /></td>
</tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="20%" height="429" valign="top"><table width="56%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td><a href="lan.asp"><img src="but_main_0.gif" name="Image91" border="0" id="Image91" onMouseOver="MM_swapImage('Image91','','but_main_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="wireless_basic.asp"><img src="but_wireless_0.gif" name="Image101" border="0" id="Image101" onMouseOver="MM_swapImage('Image101','','but_wireless_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a><a href="w_basic.asp"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="status.asp"><img src="but_status_0.gif" name="Image111" border="0" id="Image111" onMouseOver="MM_swapImage('Image111','','but_status_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="static_routing.asp"><img src="but_routing_0.gif" name="Image121" border="0" id="Image121" onMouseOver="MM_swapImage('Image121','','but_routing_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="filters.asp"><img src="but_access_1.gif" name="Image131" border="0" id="Image131" onMouseOver="MM_swapImage('Image131','','but_access_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="2" class="submenubg">
<tr>
<td width="13%" align="right"><font color="#FFFFFF">&bull;</font></td>
<td width="87%"><a href="filters.asp" class="submenus"><b>Filter </b></a></td>
</tr>
<!--<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="inbound_filter.asp" class="submenus"><b>Inbound Filter </b></a></td>
</tr>-->
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="virtual_server.asp" class="submenus"><b>Virtual Server </b></a></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="special_ap.asp" class="submenus"><b>Special AP </b></a></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="dmz.asp" class="submenus"><b><u>DMZ</u></b></a></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="firewall_setting.asp" class="submenus"><b>Firewall Settings</b></a></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="qos.asp" class="submenus"><b>QoS</b></a></td>
</tr> 
</table></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="remote_management.asp"><img src="but_management_0.gif" border="0" id="Image14" onMouseOver="MM_swapImage('Image14','','but_management_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="restart.asp"><img src="but_tools_0.gif" border="0" id="Image15" onMouseOver="MM_swapImage('Image15','','but_tools_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="#" onClick="show_wizard('wizard.asp')"><img src="but_wizard_0.gif" name="Image161" border="0" id="Image161" onMouseOver="MM_swapImage('Image161','','but_wizard_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="15" height="15"></td>
</tr>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p></td>
<td width="2%"><img src="spacer.gif" width="15" height="15" />
</td>
<td width="78%" valign="top">
<table width="98%" border="0" cellpadding="0" cellspacing="0" class="tabBigTitle">
<tr>
<td class="headerbg2">
<table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr> 
<td width="79%"><font color="#FFFFFF" class="textheader" style="margin-left:0; padding-left:0">QoS</font></td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="MM_openBrWindow('help_access.asp#access_QoS','','scrollbars=yes,resizable=yes,width=800,height=550')" value=" Help " />
</span>
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td valign="top">
<form id="form1" name="form1" method="post" action="apply.cgi">
<input type="hidden" id="html_response_page" name="html_response_page" value="back.asp">
<input type="hidden" id="html_response_message" name="html_response_message" value="Settings Saved."> 
<input type="hidden" id="html_response_return_page" name="html_response_return_page" value="qos.asp">
<input type="hidden" id="reboot_type" name="reboot_type" value="qos">
<input type="hidden" id="qos_rule_00" name="qos_rule_00" value="<% CmoGetCfg("qos_rule_00","none"); %>">
<input type="hidden" id="qos_rule_01" name="qos_rule_01" value="<% CmoGetCfg("qos_rule_01","none"); %>">
<input type="hidden" id="qos_rule_02" name="qos_rule_02" value="<% CmoGetCfg("qos_rule_02","none"); %>">
<input type="hidden" id="qos_rule_03" name="qos_rule_03" value="<% CmoGetCfg("qos_rule_03","none"); %>">
<input type="hidden" id="qos_rule_04" name="qos_rule_04" value="<% CmoGetCfg("qos_rule_04","none"); %>">
<input type="hidden" id="qos_rule_05" name="qos_rule_05" value="<% CmoGetCfg("qos_rule_05","none"); %>">
<input type="hidden" id="qos_rule_06" name="qos_rule_06" value="<% CmoGetCfg("qos_rule_06","none"); %>">
<input type="hidden" id="qos_rule_07" name="qos_rule_07" value="<% CmoGetCfg("qos_rule_07","none"); %>">
<input type="hidden" id="qos_rule_08" name="qos_rule_08" value="<% CmoGetCfg("qos_rule_08","none"); %>">
<input type="hidden" id="qos_rule_09" name="qos_rule_09" value="<% CmoGetCfg("qos_rule_09","none"); %>">
<!--div class=box-->
<h2>WAN Traffic Shaping</h2>
<table bordercolor=#ffffff width="98%" border="1" align="center" bgcolor=#dfdfdf>	
<tr> 
<td width="33%" align=right class="bgblue">Enable Traffic Shaping :</td> 
<td width="65%" class="bggrey">&nbsp;
<input type="checkbox" id="qos_traffic_shaping" name="qos_traffic_shaping" value="1" onClick="qos_traffic_shaping_click(this.checked);">
<input type="hidden" id="traffic_shaping" name="traffic_shaping" value="<% CmoGetCfg("traffic_shaping","none"); %>">
</td>
</tr>
<!--tr>
<td align=right class="bgblue">Automatic Uplink Speed :</td>
<td class="bggrey">&nbsp;
<input type="checkbox" id="qos_auto_uplink" name="qos_auto_uplink" value="1" onClick="qos_auto_uplink_click(this.checked);">
<input type="hidden" id="auto_uplink" name="auto_uplink" value="<% CmoGetCfg("auto_uplink","none"); %>">
</td>
</tr-->
<!--tr>
<td align=right class="bgblue">Measured Uplink Speed</script> :</td>
<td class="bggrey">&nbsp;
<% CmoGetStatus("measured_uplink_speed"); %>
</td>
</tr-->
<tr>
<td align=right class="bgblue">Manual Uplink Speed :</td>
<td class="bggrey">&nbsp;
<input type="text" id="qos_uplink" name="qos_uplink" maxlength="6" size="6" value="<% CmoGetCfg("qos_uplink","none"); %>">&nbsp;kbps
<span>&nbsp;&lt;&lt;&nbsp;</span>
<select id="qos_max_trans_rate_select" name="qos_max_trans_rate_select" onchange="qos_max_trans_rate_selector(this.value);">
<option value="0">Select Transmission Rate</option>
<option value="128">128 kbps</option>
<option value="256">256 kbps</option>
<option value="384">384 kbps</option>
<option value="512">512 kbps</option>
<option value="1024">1024 kbps</option>
<option value="2048">2048 kbps</option>
</select>
</td>
</tr>
<!--tr>
<td align=right class="bgblue">Connection Type :</td>
<td class="bggrey">&nbsp;
<select id="qos_connection_type_select" onchange="qos_connection_type_selector(this.value);">
<option value="0">Auto-detect</option>
<option value="1">xDSL Or Other Frame Relay Network</option>
<option value="2">Cable Or Other Broadband Network</option>
</select>
</td>
</tr>
<tr>
<td align=right class="bgblue">Detected xDSL or Other Frame Relay Network :</td>
<td class="bggrey">&nbsp;
<% CmoGetCfg("auto_uplink","none"); %>
</td>
</tr-->
</table>
<!--/div-->
<!--div class=box id="qos_engine" style="display:yes"-->
<h2>QoS Engine Setup</h2> 
<table bordercolor=#ffffff width="98%" border="1" align="center" bgcolor=#dfdfdf>	
<tr>
<td width="33%" align=right class="bgblue">Enable QoS Engine :</td>
<td width="65%" class="bggrey">&nbsp;
<input type="checkbox" id="qos_engine_enabled" name="qos_engine_enabled" value="1" onClick="qos_enable_click(this.checked)">
<input type="hidden" id="qos_enable" name="qos_enable" value="<% CmoGetCfg("qos_enable","none"); %>">
</td>
</tr> 
<tr>
<td align=right class="bgblue">Automatic Classification :</td>
<td class="bggrey">&nbsp;
<input type="checkbox" id="qos_auto_classification" name="qos_auto_classification" value="1">
<input type="hidden" id="auto_classification" name="auto_classification" value="<% CmoGetCfg("auto_classification","none"); %>">
</td>
</tr>
<tr>
<td align=right class="bgblue">Dynamic Fragmentation :</td>
<td class="bggrey">&nbsp;
<input type="checkbox" id="qos_dyn_frag" name="qos_dyn_frag" value="1">
<input type="hidden" id="qos_dyn_fragmentation" name="qos_dyn_fragmentation" value="<% CmoGetCfg("qos_dyn_fragmentation","none"); %>">
</td>
</tr>
</table>
<!--/div-->
<!-- div class=box-->
<h2>10 -- QoS Engine Rules</h2> 
<table bordercolor=#ffffff width="98%" border="1" align="center" cellspacing="1" cellpadding="2" bgcolor=#dfdfdf >
<script>
for(var i=0; i <rule_max_num ; i++){
document.write("<tr>");
document.write("<td rowspan=3 width=10%><input type=checkbox id=\"qos_rule_enabled"+ i + "\" name=\"qos_rule_enabled"+ i + "\" value=\"1\"></td>");
document.write('<td>'+"Name"+'<br><input id=name' + i + ' name=name' + i +' type=text size=16 maxlength=31></td>');
document.write('<td> '+"Priority"+'<br><input id=priority' + i + ' name=priority' + i +' type=text size=16 maxlength=31>(1..8)</td>');
document.write('<td>'+"Protocol"+'<br>');
document.write("<input id=\"protocol"+ i + "\" name=\"protocol"+ i + "\" maxlength=3 size=2 type=text>");
document.write(" << ");
document.write("<select id=\"protocol_select"+ i + "\" name=\"protocol_select"+ i + "\" onChange=\"protocol_change(" + i + ");detect_protocol_change_port(this.selectedIndex,'" + i + "');\">");
document.write('<option value=256>'+"Any"+'</option>');
document.write('<option value=6>'+"TCP"+'</option>');
document.write('<option value=17>'+"UDP"+'</option>');
document.write('<option value=257>'+"Both"+'</option>');
document.write('<option value=1>'+"ICMP"+'</option>');
document.write('<option value=-1>'+"Other"+'</option>');
document.write("</select></td>");
document.write("</tr>");
document.write("<tr>");
document.write('<td colspan=2 width=60%>'+"Local IP Range"+'<br>');
document.write('<input id=local_start_ip'+ i + ' name=local_start_ip'+ i + ' type=text size=14 maxlength=15>'+"to"+'<input id=local_end_ip'+ i + ' name=local_end_ip'+ i + ' type=text size=14 maxlength=15>');
document.write("</td>");
document.write('<td>'+"Local Port Range"+'<br>');
document.write('<input id=local_start_port'+ i + ' name=local_start_port'+ i + ' type=text size=4 maxlength=5>'+"to"+'<input id=local_end_port'+ i + ' name=local_end_port'+ i + ' type=text size=4 maxlength=5>');
document.write("</td>");
document.write("</tr>");
document.write("<tr>");
document.write('<td colspan=2 width=60%>'+"Remote IP Range"+'<br>');
document.write('<input id=remote_start_ip'+ i + ' name=remote_start_ip'+ i + ' type=text size=14 maxlength=15>'+"to"+'<input id=remote_end_ip'+ i + ' name=remote_end_ip'+ i + ' type=text size=14 maxlength=15>');
document.write("</td>");
document.write('<td>'+"Remote Port Range"+'<br>');
document.write('<input id=remote_start_port'+ i + ' name=remote_start_port'+ i + ' type=text size=4 maxlength=5 >'+"to"+'<input id=remote_end_port'+ i + ' name=remote_end_port'+ i + ' type=text size=4 maxlength=5>');
document.write("</td>");
document.write("</tr>");
}
</script>	
</table>
<!--/div-->
<table width="98%" border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#333333">
<tr>
<td align="right" class="bgblue">&nbsp;</td>
<td class="bggrey2"><input name="apply" type="submit" class="ButtonSmall" onClick="return send_request()" value="Apply">
<input name="cancel" type="button" class="ButtonSmall" onClick="window.location='qos.asp'" value="Cancel"></td>
</tr>
</table>
</form>
<br>
</td>
</tr>
</table>
</td>
</tr>
</table></td>
<td background="bg1_r.gif">&nbsp;</td>
</tr>
<tr>
<td><img src="c1_bl.gif" width="21" height="20" /></td>
<td align="right" background="bg1_b.gif"><img src="copyright.gif" width="264" height="20" /></td>
<td><img src="c1_br.gif" width="21" height="20" /></td>
</tr>
</table>
</body>
</html>
