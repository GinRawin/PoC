<html>
<head>
<title>TRENDNET | TEW-634GRU | Wizard</title>
<meta http-equiv="Content-Type" content="text/html;">
<link rel="stylesheet" href="style.css" type="text/css">
<script language="JavaScript" src="public_msg.js"></script>
<script language="JavaScript" src="public.js"></script>
<script language="JavaScript">
function send_request(){
var user_name = get_by_id("asp_temp_12").value;
if (!check_pwd("asp_temp_13", "pwd2")){
return false;
}
if (user_name == ""){
alert(msg[MSG51]);
return false;
}
if (get_by_id("asp_temp_13").value == "" || get_by_id("pwd2").value == ""){
alert("A PPPoE password MUST be specified");
return false;
}
send_submit("form1");
}
</script>
</head>
<body >
<table width="450" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="21"><img src="c1_tl.gif" width="21" height="21" /></td>
<td width="708" background="bg1_t.gif"><img src="top_1.gif" width="390" height="21" /></td>
<td width="21"><img src="c1_tr.gif" width="21" height="21" /></td>
</tr>
<tr>
<td valign="top" background="bg1_l.gif"><img src="top_2.gif" width="21" height="69" /></td>
<td background="bg.gif"><table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="78%" valign="top"><table width="98%" border="0" cellpadding="0" cellspacing="0" class="tabBigTitle">
<tr>
<td class="headerbg2">Set PPPoE to
obtain IP automatically</td>
</tr>
<tr>
<td valign="top"><TABLE width="98%" height=200 border="0" align=center cellpadding="3" cellspacing="1">
<TBODY>
<TR>
<TD align="center" valign="top" bgcolor="#DDDDDD"><TABLE width="100%" align=center border=0>
<TBODY>
<TR>
<TD><form id="form1" name="form1" method="post" action="apply.cgi">
<input type="hidden" id="html_response_page" name="html_response_page" value="wizard6.asp">
<input type="hidden" id="html_response_return_page" name="html_response_return_page" value="<% CmoGetCfg("html_response_return_page","none"); %>">
<input type="hidden" id="reboot_type" name="reboot_type" value="none">
<input type="hidden" id="asp_temp_02" name="asp_temp_02" value="pppoe">
<input type="hidden" id="asp_temp_11" name="asp_temp_11" value="1">
<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1">
<tr>
<td width="140" class="wizleft"><font face="Arial">User Name</font></td>
<td width="231" class="wizright"><font face="Arial" color="#000000">
<input type="text" id="asp_temp_12" name="asp_temp_12" size="30" maxlength="63" value="<% CmoGetCfg("asp_temp_12","none"); %>">
</font></td>
</tr>
<tr>
<td class="wizleft"><font face="Arial">Password</font></td>
<td class="wizright"><font face="Arial" color="#000000">
<input type="password" id="asp_temp_13" name="asp_temp_13" size="30" maxlength="63" value="WDB8WvbXdHtZyM8Ms2RENgHlacJghQyG">
</font></td>
</tr>
<tr>
<td class="wizleft"><font face="Arial">Verify Password</font></td>
<td class="wizright"><font face="Arial" color="#000000">
<input type="password" id="pwd2" name="pwd2" size="30" maxlength="63" value="WDB8WvbXdHtZyM8Ms2RENgHlacJghQyG">
</font></td>
</tr>
</table>
<br>
<table border="0" align="center" cellpadding="2" cellspacing="2">
<tr>
<td align="center" nowrap><input name="back" type="button" class="ButtonSmall" onClick="window.location='<% CmoGetCfg("html_response_return_page","none"); %>'" value="&lt; Back">
<input name="next" type="button" class="ButtonSmall" onClick="send_request()" value="Next &gt;">
<input name="exit" type="button" class="ButtonSmall" onClick="exit_wizard()" value="Exit"></td>
</tr>
</table>
</form></TD>
</TR>
<TR>
<TD>&nbsp;</TD>
</TR>
</TBODY>
</TABLE></TD>
</TR>
</TBODY>
</TABLE>
<br>
</td>
</tr>
</table></td>
</tr>
</table></td>
<td background="bg1_r.gif">&nbsp;</td>
</tr>
<tr>
<td><img src="c1_bl.gif" width="21" height="20" /></td>
<td height="20" background="bg1_b.gif">&nbsp;</td>
<td><img src="c1_br.gif" width="21" height="20" /></td>
</tr>
</table>
</body>
</html>
