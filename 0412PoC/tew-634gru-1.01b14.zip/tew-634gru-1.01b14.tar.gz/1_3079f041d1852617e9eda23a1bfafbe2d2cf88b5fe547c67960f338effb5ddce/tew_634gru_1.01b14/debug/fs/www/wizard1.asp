<html>
<head>
<title>TRENDNET | TEW-634GRU | Wizard</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="style.css" type="text/css">
<script language="JavaScript" src="public_msg.js"></script>
<script language="JavaScript" src="public.js"></script>
<script type="text/JavaScript">
var submit_button_flag = 0;
function send_request(){
if (check_pwd("pwd1", "pwd2")){
get_by_id("asp_temp_00").value = get_by_id("pwd1").value;
send_submit("form1");
if(submit_button_flag == 0){
submit_button_flag = 1;
return true;
}else{
return false;
}
}
}
</script>
</head>
<body>
<table width="450" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="21"><img src="c1_tl.gif" width="21" height="21" /></td>
<td width="708" background="bg1_t.gif"><img src="top_1.gif" width="390" height="21" /></td>
<td width="21"><img src="c1_tr.gif" width="21" height="21" /></td>
</tr>
<tr>
<td valign="top" background="bg1_l.gif"><img src="top_2.gif" width="21" height="69" /></td>
<td background="bg.gif"><table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="78%" valign="top"><table width="98%" border="0" cellpadding="0" cellspacing="0" class="tabBigTitle">
<tr>
<td class="headerbg2">Set Password</td>
</tr>
<tr>
<td valign="top"><TABLE width="98%" height=200 border="0" align=center cellpadding="3" cellspacing="1">
<TBODY>
<TR>
<TD align="center" valign="top" bgcolor="#DDDDDD"><TABLE width="100%" align=center border=0>
<TBODY>
<TR>
<TD><form id="form1" name="form1" method="post" action="apply.cgi">
<input type="hidden" id="html_response_page" name="html_response_page" value="wizard2.asp">
<input type="hidden" id="html_response_return_page" name="html_response_return_page" value="wizard.asp">
<input type="hidden" id="reboot_type" name="reboot_type" value="none">
<input type="hidden" id="asp_temp_00" name="asp_temp_00">
<table width="100%" border="0" cellpadding="3" cellspacing="1">
<tr>
<td width="144" class="wizleft"><b>Password</b></td>
<td width="235" class="wizright"><font>
<input type="password" id="pwd1" name="pwd1" size="20" maxlength="15" value="WDB8WvbXdHtZyM8Ms2RENgHlacJghQyG">
</font></td>
</tr>
<tr>
<td width="144" class="wizleft"><b>Verify Password</b></td>
<td width="235" class="wizright"><font>
<input type="password" id="pwd2" name="pwd2" size="20" maxlength="15" value="WDB8WvbXdHtZyM8Ms2RENgHlacJghQyG">
</font></td>
</tr>
</table>
<br>
<table border="0" align="center" cellpadding="2" cellspacing="2">
<tr>
<td align="center"><input name="back" type="button" class="ButtonSmall" onClick="window.location='wizard.asp'" value="&lt; Back">
<input name="next" type="button" class="ButtonSmall" onClick="send_request()" value="Next &gt;">
<input name="exit" type="button" class="ButtonSmall" onClick="exit_wizard()" value="Exit"></td>
</tr>
</table>
</form></TD>
</TR>
<TR>
<TD>&nbsp;</TD>
</TR>
</TBODY>
</TABLE>
</TD>
</TR>
</TBODY>
</TABLE>
<br>
</td>
</tr>
</table></td>
</tr>
</table></td>
<td background="bg1_r.gif">&nbsp;</td>
</tr>
<tr>
<td><img src="c1_bl.gif" width="21" height="20" /></td>
<td height="20" background="bg1_b.gif">&nbsp;</td>
<td><img src="c1_br.gif" width="21" height="20" /></td>
</tr>
</table>
</body>
</html>
