<html>
<head>
<title>TRENDNET | TEW-634GRU | Wizard</title>
<meta http-equiv="Content-Type" content="text/html;">
<link rel="stylesheet" href="style.css" type="text/css">
<script language="JavaScript" src="public_msg.js"></script>
<script language="JavaScript" src="public.js"></script>
<script language="JavaScript">
function set_static_ip(){
set_checked(get_by_id("asp_temp_11").value, get_by_name("pppoe_type"));
}
function show_static_ip(){
var pppoe_type = get_by_name("pppoe_type");	
get_by_id("asp_temp_15").disabled = pppoe_type[0].checked;
}	
function send_request(){	
var ip = get_by_id("asp_temp_15").value;
var pppoe_type = get_by_name("pppoe_type");
var user_name = get_by_id("asp_temp_12").value;
if (pppoe_type[1].checked){	
var ip_addr_msg = replace_msg(all_ip_addr_msg,"IP address");
var temp_ip_obj = new addr_obj(ip.split("."), ip_addr_msg, false, false);
if (!check_pwd("asp_temp_13", "pwd2")){
return false;
}
if (!check_address(temp_ip_obj)){
return false;
}
if (user_name == ""){
alert(msg[MSG51]);
return false;
}
if (get_by_id("asp_temp_13").value == "" || get_by_id("pwd2").value == ""){
alert("A PPPoE password MUST be specified");
return false;
}
}
if (pppoe_type[1].checked){
get_by_id("asp_temp_11").value = "0";
}else{
get_by_id("asp_temp_11").value = "1";
}
get_by_id("asp_temp_47").value = "1";	
send_submit("form1");
}
</script>
<style type="text/css">
<!--
.style3 {font-size: 11px}
.style5 {font-size: 12px}
-->
</style>
</head>
<body >
<table width="450" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="21"><img src="c1_tl.gif" width="21" height="21" /></td>
<td width="708" background="bg1_t.gif"><img src="top_1.gif" width="390" height="21" /></td>
<td width="21"><img src="c1_tr.gif" width="21" height="21" /></td>
</tr>
<tr>
<td valign="top" background="bg1_l.gif"><img src="top_2.gif" width="21" height="69" /></td>
<td background="bg.gif"><table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="78%" valign="top"><table width="98%" border="0" cellpadding="0" cellspacing="0" class="tabBigTitle">
<tr>
<td class="headerbg2">Set Russia PPPoe</td>
</tr>
<tr>
<td valign="top"><TABLE width="98%" height=200 border="0" align=center cellpadding="3" cellspacing="1">
<TBODY>
<TR>
<TD align="center" valign="top" bgcolor="#DDDDDD"><TABLE width="100%" align=center border=0>
<TBODY>
<TR>
<TD><form id="form1" name="form1" method="post" action="apply.cgi">
<input type="hidden" id="html_response_page" name="html_response_page" value="wizard6.asp">
<input type="hidden" id="html_response_return_page" name="html_response_return_page" value="<% CmoGetCfg("html_response_return_page","none"); %>">
<input type="hidden" id="reboot_type" name="reboot_type" value="none">
<input type="hidden" id="asp_temp_02" name="asp_temp_02" value="pppoe">
<input type="hidden" id="asp_temp_11" name="asp_temp_11" value="<% CmoGetCfg("asp_temp_11","none"); %>">
<input type="hidden" id="asp_temp_46" name="asp_temp_46" value="255.255.255.0">
<input type="hidden" id="asp_temp_47" name="asp_temp_47" value="<% CmoGetCfg("asp_temp_47","none"); %>">
<table width="98%" border="0" align="center" cellpadding="3" cellspacing="1">
<tr>
<td class="wizleft">&nbsp;</td>
<td class="wizright"><span class="style3">
<input name="pppoe_type" type="radio" value="1" onClick="show_static_ip()">
<span class="style5"> Dynamic IP</span>&nbsp;&nbsp;
<input name="pppoe_type" type="radio" value="0" onClick="show_static_ip()">
<span class="style5"> Static IP </span></span></td>
</tr>
<tr>
<td width="140" class="wizleft"><font face="Arial">User Name</font></td>
<td width="231" class="wizright"><font face="Arial">
<input type="text" id="asp_temp_12" name="asp_temp_12" size="30" maxlength="63" value="<% CmoGetCfg("asp_temp_12","none"); %>">
</font></td>
</tr>
<tr>
<td class="wizleft"><font face="Arial">Passward</font></td>
<td class="wizright"><font face="Arial">
<input type="password" id="asp_temp_13" name="asp_temp_13" size="30" maxlength="63" value="WDB8WvbXdHtZyM8Ms2RENgHlacJghQyG">
</font></td>
</tr>
<tr>
<td class="wizleft"><font face="Arial">Verify Password</font></td>
<td class="wizright"><font face="Arial"> <font face="Arial">
<input type="password" id="pwd2" name="pwd2" size="30" maxlength="63" value="WDB8WvbXdHtZyM8Ms2RENgHlacJghQyG">
</font> </font></td>
</tr>
<tr>
<td class="wizleft"><font face="Arial">IP Address</font></td>
<td class="wizright"><input type="text" id="asp_temp_15" name="asp_temp_15" size="16" maxlength="15" value="<% CmoGetCfg("asp_temp_15","none"); %>"></td>
</tr>
</table>
<br>
<table border="0" align="center" cellpadding="2" cellspacing="2">
<tr>
<td align="center" nowrap><input name="back" type="button" class="ButtonSmall" onClick="window.location='<% CmoGetCfg("html_response_return_page","none"); %>'" value="&lt; Back">
<input name="next" type="button" class="ButtonSmall" onClick="send_request()" value="Next &gt;">
<input name="exit" type="button" class="ButtonSmall" onClick="exit_wizard()" value="Exit"></td>
</tr>
</table>
</form></TD>
</TR>
<TR>
<TD>&nbsp;</TD>
</TR>
</TBODY>
</TABLE></TD>
</TR>
</TBODY>
</TABLE>
<br>
</td>
</tr>
</table></td>
</tr>
</table></td>
<td background="bg1_r.gif">&nbsp;</td>
</tr>
<tr>
<td><img src="c1_bl.gif" width="21" height="20" /></td>
<td height="20" background="bg1_b.gif">&nbsp;</td>
<td><img src="c1_br.gif" width="21" height="20" /></td>
</tr>
</table>
</body>
<script>
set_static_ip();
show_static_ip();
</script>
</html>
