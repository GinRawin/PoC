<HTML>
<HEAD>
<!-- $MVD$:app("RoboHELP HTML Edition by Blue Sky Software, portions by MicroVision Dev. Inc.","769") -->
<!-- $MVD$:template("","0","0") -->
<!-- $MVD$:fontset("Arial","Arial") -->
<!-- $MVD$:fontset("Times New Roman","Times New Roman") -->
<!-- $MVD$:fontset("Arial Narrow","Arial Narrow") -->
<TITLE></TITLE>
<link rel="stylesheet" href="style.css" type="text/css">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script type="text/javascript">
<!--
function MM_preloadImages() { //v3.0
var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
function MM_swapImgRestore() { 
var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_findObj(n, d) { 
var p,i,x; if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
if(!x && d.getElementById) x=d.getElementById(n); return x;
}
function MM_swapImage() { 
var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
-->
</script>
</HEAD>
<BODY onLoad="MM_preloadImages('but_help_access_1.gif','but_help_main_1.gif','but_help_management_1.gif','but_help_routing_1.gif','but_help_status_1.gif','but_help_tools_1.gif','but_help_wireless_1.gif')">
<table width="750" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="21"><img src="c1_tl.gif" width="21" height="21" /></td>
<td width="708" background="bg1_t.gif"><img src="top_1.gif" width="390" height="21" /></td>
<td width="21"><img src="c1_tr.gif" width="21" height="21" /></td>
</tr>
<tr>
<td valign="top" background="bg1_l.gif"><img src="top_2.gif" width="21" height="69" /></td>
<td background="bg.gif"><table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="13%"><img src="logo.gif" width="270" height="69" /></td>
<td width="87%" align="right"><img src="description.gif" /></td>
</tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="20%" height="429" valign="top"><table width="100%" border="0" align="center" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><b>Help</b></td>
</tr>
<tr>
<td bgcolor="#000000" ><table width="56%" border="0" cellpadding="0" cellspacing="0" bgcolor="#1D1D1D">
<tr>
<td><a href="help_main.asp"><img src="but_help_main_0.gif" name="Image2" width="155" height="27" border="0" id="Image2" onmouseover="MM_swapImage('Image2','','but_help_main_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_wlan.asp"><img src="but_help_wireless_1.gif" name="Image31" width="155" height="27" border="0" id="Image31" onmouseover="MM_swapImage('Image31','','but_help_wireless_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="2" >
<tr>
<td width="13%" align="right"><font color="#FFFFFF">&bull;</font></td>
<td width="87%"><b><a href="help_wlan.asp#wireless_basic" class="submenus">Basic</a><a href="help_access.asp#access_user_group" class="submenus"></a></b></td>
</tr>
<!--<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="inbound_filter.asp" class="submenus"><b>Inbound Filter </b></a></td>
</tr>-->
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><b><a href="help_wlan.asp#wireless_WEP" class="submenus">Security</a><a href="help_access.asp#access_url_group" class="submenus"></a></b></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td> <b><a href="help_wlan.asp#wireless_advanced" class="submenus">Advanced</a></b><b><a href="help_access.asp#access_ip_filter" class="submenus"></a></b></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><b><a href="help_wlan.asp#wireless_wps" class="submenus">Wi-Fi Protected Setup </a><a href="help_access.asp#access_domain_filter" class="submenus"></a></b></td>
</tr>
</table></td>	
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_status.asp"><img src="but_help_status_0.gif" name="Image23" width="155" height="27" border="0" id="Image23" onmouseover="MM_swapImage('Image23','','but_help_status_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_routing.asp"><img src="but_help_routing_0.gif" name="Image30" width="155" height="27" border="0" id="Image22" onmouseover="MM_swapImage('Image30','','but_help_routing_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_access.asp"><img src="but_help_access_0.gif" name="Image24" width="155" height="27" border="0" id="Image24" onmouseover="MM_swapImage('Image24','','but_help_access_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_manage.asp"><img src="but_help_management_0.gif" name="Image21" width="155" height="27" border="0" id="Image21" onmouseover="MM_swapImage('Image21','','but_help_management_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_tools.asp"><img src="but_help_tools_0.gif" name="Image1" width="155" height="27" border="0" id="Image1" onmouseover="MM_swapImage('Image1','','but_help_tools_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
</table></td>
</tr>
</table>
<p></p>
<p>&nbsp;</p></td>
<td width="2%"><img src="spacer.gif" width="10" height="15" /></td>
<td width="78%" valign="top"><table width="550" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">Wireless</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table></td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>This page enables you to set wireless communications parameters for
the router's <A HREF="glossary.asp#def_wireless_lan">wireless LAN</A> feature.</P>
<P> Click the items below for more information:</P>
<UL>
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet"> <b><A HREF="#wireless_basic">Basic</A></b></P>
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet"> <b><A HREF="#wireless_WEP">Security</A></b></P>
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet"> <b><A HREF="#wireless_advanced">Advanced</A></b></P>
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet"> <b><A HREF="#wireless_wps">Wi-Fi Protected Setup </A></b></P>
</UL></td>
</tr>
</table></td>
</tr>
</table>
<br>
<a name="wireless_basic"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">Basic</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>This page enables you to enable and disable the <A HREF="glossary.asp#def_wireless_lan">wireless
LAN</A> function, enter a <A HREF="glossary.asp#def_ssid">SSID</A>,
and set the channel for wireless communications.</P>
<P> <SPAN STYLE="font-weight : bold;">Enable/Disable:</SPAN><A NAME="Wireless_enable_disable"></A> Enables and disables <A HREF="glossary.asp#def_wireless_lan">wireless LAN</A> via the router.</P>
<P> <SPAN STYLE="font-weight : bold;">SSID:</SPAN><A NAME="wireless_SSID"></A> Type an <A HREF="glossary.asp#def_ssid">SSID</A> in the text box. The
SSID of any wireless device must match the SSID typed here in order
for the wireless device to access the LAN and WAN via the router.</P>
<P> <SPAN STYLE="font-weight : bold;">Channel:</SPAN><A NAME="wireless_channel"></A> Select a transmission channel for wireless communications. The
channel of any wireless device must match the channel selected here
in order for the wireless device to access the <A HREF="glossary.asp#def_LAN">LAN</A> and <A HREF="glossary.asp#def_WAN">WAN</A> via the router.</P>
<P> <strong>802.11 Mode:</strong><A NAME="wireless_802.11mode"></A> If all of the wireless devices you want to connect with this router can connect in the same transmission mode, you can improve performance slightly by choosing the appropriate "Only" mode. If you have some devices that use a different transmission mode, choose the appropriate "Mixed" mode. </P>
<P> <strong>Channel Width:</strong><A NAME="wireless_channel_width"></A> The "Auto 20/40 MHz" option is usually best. The other options are available for special circumstances. </P>
<P> <strong>SSID Broadcast: </strong>Select Disabled if you would not like the SSID of your wireless network to be broadcasted by the TEW-634GRU. If this option is Disabled, the SSID of the TEW-634GRU will not be seen by Site Survey utilities so your wireless clients will have to know the SSID of your TEW-634GRU in order to connect to it. </P>
<P><strong>WMM: </strong>Enable the Wi-Fi Multi-Media will offer Wi-Fi networks stable that improve the user experience for audio, video, and voice applications by prioritizing data traffic. </P>
<P> <A HREF="help_wlan.asp">back to top</A></P></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br>
<a name="wireless_WEP"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">Security</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>This screen enables you to set <A HREF="glossary.asp#def_WEP">WEP| </A>WPA | WPA2 | WPA-Auto parameters for secure wireless communications.</P>
<P>To protect your privacy you can configure wireless security features. This device supports two wireless security modes including: WPA-Personal (PSK), and WPA-Enterprise (RADIUS). WPA provides a higher level of security. WPA-Personal does not require an authentication server. The WPA-Enterprise option requires an external RADIUS server. </P>
<p><strong>Authentication Type: </strong>Select the <a href="http://192.168.10.1/glossary.asp#def_Authentication">authentication </a> type. Open System allows public access to the router via wireless communications. </p>
<p><strong>WEP: </strong>WEP is the wireless encryption standard. To use it you must enter the same key(s) into the router and the wireless stations. For 64 bit keys you must enter 10 hex digits into each key box. For 128 bit keys you must enter 26 hex digits into each key box. A hex digit is either a number from 0 to 9 or a letter from A to F. For the most secure use of WEP set the authentication type to &quot;Shared Key&quot; when WEP is enabled. </p>
<p>You may also enter any text string into a WEP key box, in which case it will be converted into a hexadecimal key using the ASCII values of the characters. A maximum of 5 text characters can be entered for 64 bit keys, and a maximum of 13 characters for 128 bit keys. </p>
<p><em>If you choose the WEP security option this device will ONLY operate in Legacy Wireless mode (802.11B/G) . This means you will NOT get 11N performance due to the fact that WEP is not supported by 11N specification. </em></p>
<P> <SPAN STYLE="font-weight : bold;">Mode:</SPAN><A NAME="WEP_mode"></A> Select the level of encryption you want from the drop-down list. The
router supports, 64-, 128--bit encryption.</P>
<P> <SPAN STYLE="font-weight : bold;">Key 1 ~ Key 4:</SPAN><A NAME="WEP_key1to4"></A> Enables you to create an encryption scheme for Wireless LAN
transmissions. Manually enter a set of values for each key. Select
the which key you want to use by clicking the radio button next to
the key. Click <SPAN STYLE="font-style : italic;">Clear</SPAN> to
erase key values.</P>
<P CLASS="Note"> <SPAN STYLE="font-weight : bold;">Note:</SPAN> 128-bit
encryption require more system resources than 64-bit encryption. Use
64-bit encryption for better performance.</P>
<p><strong>WPA/WPA2/WPA-Auto Security: </strong></p>
<p>If WPA, WPA2 or WPA-Auto EAP is selected, the above screen is shown. Please set the length of the encryption key and the parameters for the RADIUS server. </p>
WPA requires stations to use high grade encryption and authentication. For legacy compatibility, use WPA or WPA2 mode. This mode uses WPA for legacy clients while maintaining higher security with stations that are WPA2 capable. The strongest cipher that
the client supports will be used. For best security, use WPA2 Only mode. In this mode, legacy stations are not allowed access with WPA security. The AES cipher will be used across the wireless network to ensure best security. 
<p><strong>RADIUS Server: </strong></p>
<p>1.Enter the IP address, Port used and Shared Secret by the Primary Radius Server. </p>
<p>2.Enter the IP address, Port used and Shared Secret by the Secondary Radius Server. (optional) </p>
<p><strong>WPA-PSK/WPA2-PSK Security: </strong></p>
<p>If WPA, WPA2 or WPA-Auto PSK is selected, each user must enter a pass phrase to access the network. </p>
<p><strong>Cipher Type:</strong> Select the cipher type for TKIP or AES encryption, Selected Auto for auto detects the cipher type. </p>
<p><strong>Passphrase:</strong> The length should be between 8 and 63 ASCII characters or 64 Hex characters. </p> <P CLASS="Note">&nbsp;</P>
<P> <A HREF="help_wlan.asp">back to top</A></P></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br>
<a name="wireless_advanced"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">Advanced</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>This screen enables you to configure advanced wireless functions.</P>
<P> <SPAN STYLE="font-weight : bold;">Beacon Interval:</SPAN><A NAME="advanced_beacon_interval"></A> Type the<A HREF="glossary.asp#def_beacon_interval"> beacon interval</A> in the text box. You can specify a value from 25 to 1000. The default
beacon interval is 100.</P>
<P> <SPAN STYLE="font-weight : bold;">RTS Threshold:</SPAN><A NAME="advanced_rts_threshold"></A> Type the <A HREF="glossary.asp#def_RTS">RTS</A> (Request-To-Send) threshold
in the text box. This value stabilizes data flow. If data flow is irregular,
choose values between 256 and 2346 until data flow is normalized.</P>
<P> <SPAN STYLE="font-weight : bold;">Fragmentation Threshold:</SPAN><A NAME="advanced_fragmentation_threshold"></A> Type the <A HREF="glossary.asp#def_fragmentation">fragmentation</A> threshold
in the text box. If packet transfer error rates are high, choose values between
1500 and 2346 until packet transfer rates are minimized.</P>
<P CLASS="Note"> <SPAN STYLE="font-weight : bold;">Note:</SPAN> Setting the
fragmentation threshold value may diminish system performance.</P>
<P> <SPAN STYLE="font-weight : bold;">DTIM Interval:</SPAN><A NAME="advanced_dtim_interval"></A> Type a <A HREF="glossary.asp#def_DTIM">DTIM</A> (Delivery Traffic
Indication Message) interval in the text box. You can specify a value
between 1 and 255. The default value is 1.</P>
<P> <A HREF="help_wlan.asp">back to top</A></P></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br>
<a name="wireless_adv_802_1x"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">802.1X</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>The IEEE 802.1X is a standard for user authentication on networks. The ROUTER
supports EAP (Extensible Authentication Protocol) as specified by 802.1X. EAP
provides wireless LAN with strong, mutual authentication between a client and
an authentication server. The ROUTER can serve as a 802.1X Authenticator
between 802.1X wireless clients and the Authentication Server typically installed
on a RADIUS server. Please keep in mind that enabling 802.1X requires a RADIUS
server for user authentication to the network. </P>
<p></p>
<p><SPAN STYLE="font-weight : bold;">Encryption Key:</SPAN> The encryption key
length can be either 64bits or 128bits, when used with the AirPlus
products. The encryption key has a lifetime which can be specified from 5 minutes
to 1 day. </p>
<p><SPAN STYLE="font-weight : bold;">RADIUS Server:</SPAN> The encryption key
RADIUS (Remote Access Dial-In User Service) Server is used for user authentication.
You will need to enter the IP Address of the RADIUS Server and the port number
for authentication. For most RADIUS Servers, port 1812 is used for this purpose.
Key-in a Shared Secret can be entered as an additional security protection for
communication between the RADIUS server and the ROUTER. A second RADIUS
Server can be entered as an option. Consult your RADIUS providers or the manual
of your RADIUS Server for more details</p>
<p></p>
<p><a href="help_wlan.asp">back to top</a></p></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br>
<a name="wireless_wps"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">Wi-Fi Protected Setup (WPS) </td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>This screen enables you to set <a href="glossary.asp#def_WPS">Wi-Fi Protected Setup (WPS) </a> parameters for easy install wireless communications. </P>
<strong>WPS:</strong> Enable/Disable <a href="glossary.asp#def_WPS">Wi-Fi Protected Setup </a> function.
<p align="left"><strong>Status:</strong> Display the state ( <a href="glossary.asp#def_Uncfg">Un-configured State </a>/ <a href="glossary.asp#def_cfg">Configured State </a>) information of <a href="glossary.asp#def_WPS">WPS </a>. </p>
<p align="left"><strong>Self-PIN Number:</strong> Display the default <a href="glossary.asp#def_PIN">PIN number </a> of AP. </p>
<p align="left"><strong>Client PIN Number: </strong>Type Client <a href="glossary.asp#def_PIN">PIN number </a> the client uses to negotiate with AP via <a href="#wireless_wps">WPS </a>protocol. It is only used when users want their station to join AP's network. </p>
<p align="left"><strong>Push Button Configuration:</strong> Clicking this button will invoke the <a href="glossary.asp#def_PBC">PushButton Configuration (PBC) </a> method of <a href="glossary.asp#def_WPS">WPS </a>. It is only used when AP acts as a Registrar . </p>
<p><a href="help_wlan.asp">back to top</a></p></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br></td>
</tr>
</table></td>
<td background="bg1_r.gif">&nbsp;</td>
</tr>
<tr>
<td><img src="c1_bl.gif" width="21" height="20" /></td>
<td align="right" background="bg1_b.gif"><img src="copyright.gif" width="264" height="20" /></td>
<td><img src="c1_br.gif" width="21" height="20" /></td>
</tr>
</table>
</BODY>
</HTML>
