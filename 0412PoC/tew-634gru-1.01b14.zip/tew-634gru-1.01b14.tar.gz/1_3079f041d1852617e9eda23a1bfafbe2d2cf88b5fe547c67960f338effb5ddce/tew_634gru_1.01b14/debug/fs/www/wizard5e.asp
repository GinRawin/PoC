<html>
<head>
<title>TRENDNET | TEW-634GRU | Wizard</title>
<meta http-equiv="Content-Type" content="text/html;">
<link rel="stylesheet" href="style.css" type="text/css">
<script language="JavaScript" src="public_msg.js"></script>
<script language="JavaScript" src="public.js"></script>
<script language="JavaScript">
function loadSettings(){
var dat = get_by_id("wan_curr_ipaddr").value.split("/");
if(dat[0] !="0.0.0.0" && get_by_id("asp_temp_19").value == "0.0.0.0"){
get_by_id("asp_temp_19").value = dat[0];
}
if(dat[1] !="0.0.0.0" && get_by_id("asp_temp_20").value == "0.0.0.0"){
get_by_id("asp_temp_20").value = dat[1];
}
set_checked("<% CmoGetCfg("wan_pptp_dynamic","none"); %>",get_by_name("pptp_enable"));
disable_dhcp_static_address(get_by_name("pptp_enable"), get_by_id("asp_temp_19"), get_by_id("asp_temp_20"), get_by_id("asp_temp_21"));
}
function send_request(){	
var ip = get_by_id("asp_temp_19").value;	
var mask = get_by_id("asp_temp_20").value;
var gateway = get_by_id("asp_temp_21").value;
var ip_addr_msg = replace_msg(all_ip_addr_msg,"IP address");
var gateway_msg = replace_msg(all_ip_addr_msg,"Gateway address");
var temp_ip_obj = new addr_obj(ip.split("."), ip_addr_msg, false, false);
var temp_mask_obj = new addr_obj(mask.split("."), subnet_mask_msg, false, false);
var temp_gateway_obj = new addr_obj(gateway.split("."), gateway_msg, false, false);
var user_name = get_by_id("asp_temp_17").value;
if (get_by_name("pptp_enable")[1].checked){	
if (!check_lan_setting(temp_ip_obj, temp_mask_obj, temp_gateway_obj)){
return false;
}
}
if(get_by_id("asp_temp_22").value == ""){
alert(msg[MSG40]);
return false;
}
if (get_by_name("pptp_enable")[1].checked){
get_by_id("asp_temp_16").value = "0";
}else{
get_by_id("asp_temp_16").value = "1";
}
if (!check_pwd("asp_temp_18", "pwd2")){
return false;
}
if (user_name == ""){
alert(msg[MSG51]);
return false;
}
if (get_by_id("asp_temp_18").value == "" || get_by_id("pwd2").value == ""){
alert("A PPTP password MUST be specified");
return false;
}
send_submit("form1");
}
</script>
</head>
<body onLoad="loadSettings();">
<table width="450" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="21"><img src="c1_tl.gif" width="21" height="21" /></td>
<td width="708" background="bg1_t.gif"><img src="top_1.gif" width="390" height="21" /></td>
<td width="21"><img src="c1_tr.gif" width="21" height="21" /></td>
</tr>
<tr>
<td valign="top" background="bg1_l.gif"><img src="top_2.gif" width="21" height="69" /></td>
<td background="bg.gif"><table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="78%" valign="top"><table width="98%" border="0" cellpadding="0" cellspacing="0" class="tabBigTitle">
<tr>
<td class="headerbg2">Set PPTP Client</td>
</tr>
<tr>
<td valign="top"><TABLE width="98%" height=200 border="0" align=center cellpadding="3" cellspacing="1">
<TBODY>
<TR>
<TD align="center" valign="top" bgcolor="#DDDDDD"><TABLE width="100%" align=center border=0>
<TBODY>
<TR>
<TD><form id="form1" name="form1" method="post" action="apply.cgi">
<input type="hidden" id="html_response_page" name="html_response_page" value="wizard6.asp">
<input type="hidden" id="html_response_return_page" name="html_response_return_page" value="<% CmoGetCfg("html_response_return_page","none"); %>">
<input type="hidden" id="wan_curr_ipaddr" name="wan_curr_ipaddr" value="<% CmoGetStatus("wan_current_ipaddr_00"); %>">
<input type="hidden" id="reboot_type" name="reboot_type" value="none">
<input type="hidden" id="asp_temp_02" name="asp_temp_02" value="pptp">
<input type="hidden" id="asp_temp_16" name="asp_temp_16" value="<% CmoGetStatus("asp_temp_16"); %>">
<input type="hidden" id="wan_pptp_dynamic" name="wan_pptp_dynamic" value="<% CmoGetCfg("wan_pptp_dynamic","none"); %>">
<table width="100%" border="0" cellpadding="3" cellspacing="1" >
<tr>
<td class="wizleft">&nbsp;</td>
<td class="wizright"><font face="Arial">
<input type="radio" name="pptp_enable" value="1" onClick='disable_dhcp_static_address(get_by_name("pptp_enable"), get_by_id("asp_temp_19"), get_by_id("asp_temp_20"), get_by_id("asp_temp_21"))'>
</font>Dynamic IP&nbsp;<font face="Arial">
<input type="radio" name="pptp_enable" value="0" onClick='disable_dhcp_static_address(get_by_name("pptp_enable"), get_by_id("asp_temp_19"), get_by_id("asp_temp_20"), get_by_id("asp_temp_21"))'>
</font>Static IP</td>
</tr>
<tr>
<td class="wizleft"><font face="Arial">My IP</font></td>
<td width="235" class="wizright"><input type="text" id="asp_temp_19" name="asp_temp_19" size=16 maxlength=15 value="<% CmoGetCfg("asp_temp_19","none"); %>"></td>
</tr>
<tr>
<td class="wizleft"><font face="Arial">Subnet Mask</font></td>
<td class="wizright"><input type="text" id="asp_temp_20" name="asp_temp_20" size=16 maxlength=15 value="<% CmoGetCfg("asp_temp_20","none"); %>"></td>
</tr>
<tr>
<td class="wizleft"><font face="Arial">GateWay</font></td>
<td class="wizright"><input type="text" id="asp_temp_21" name="asp_temp_21" size="16" maxlength="15" value="<% CmoGetCfg("asp_temp_21","none"); %>"></td>
</tr>
<tr>
<td class="wizleft"><font face="Arial">Server IP</font></td>
<td class="wizright"><input type="text" id="asp_temp_22" name="asp_temp_22" size=30 maxlength=63 value="<% CmoGetCfg("asp_temp_22","none"); %>"></td>
</tr>
<tr>
<td class="wizleft"><font face="Arial">PPTP Account</font></td>
<td class="wizright"><input type="text" id="asp_temp_17" name="asp_temp_17" size="30" maxlength="63" value="<% CmoGetCfg("asp_temp_17","none"); %>"></td>
</tr>
<tr>
<td class="wizleft">PPTP Password</td>
<td class="wizright"><input type="password" id="asp_temp_18" name="asp_temp_18" size="30" maxlength="63" value="WDB8WvbXdHtZyM8Ms2RENgHlacJghQyG"></td>
</tr>
<tr>
<td class="wizleft">Retype Password</td>
<td class="wizright"><input type="password" id="pwd2" name="pwd2" size="30" maxlength="63" value="WDB8WvbXdHtZyM8Ms2RENgHlacJghQyG"></td>
</tr>
</table>
<table width="100%" border="0" cellpadding="2" cellspacing="2">
<tr>
<td align="center"><br>
<table border="0" align="center" cellpadding="2" cellspacing="2">
<tr>
<td align="center" nowrap><input name="back" type="button" class="ButtonSmall" onClick="window.location='<% CmoGetCfg("html_response_return_page","none"); %>'" value="&lt; Back">
<input name="next" type="button" class="ButtonSmall" onClick="send_request()" value="Next &gt;">
<input name="exit" type="button" class="ButtonSmall" onClick="exit_wizard()" value="Exit"></td>
</tr>
</table>
</td></tr>
</table>
</form></TD>
</TR>
<TR>
<TD>&nbsp;</TD>
</TR>
</TBODY>
</TABLE></TD>
</TR>
</TBODY>
</TABLE>
<br>
</td>
</tr>
</table></td>
</tr>
</table></td>
<td background="bg1_r.gif">&nbsp;</td>
</tr>
<tr>
<td><img src="c1_bl.gif" width="21" height="20" /></td>
<td height="20" background="bg1_b.gif">&nbsp;</td>
<td><img src="c1_br.gif" width="21" height="20" /></td>
</tr>
</table>
</body>
</html>
