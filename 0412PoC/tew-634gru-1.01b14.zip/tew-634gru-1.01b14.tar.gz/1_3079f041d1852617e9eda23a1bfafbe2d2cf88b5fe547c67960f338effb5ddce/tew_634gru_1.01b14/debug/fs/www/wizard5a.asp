<html>
<head>
<title>TRENDNET | TEW-634GRU | Wizard</title>
<meta http-equiv="Content-Type" content="text/html;">
<link rel="stylesheet" href="style.css" type="text/css">
<script language="JavaScript" src="public_msg.js"></script>
<script language="JavaScript" src="public.js"></script>
<script language="JavaScript">
function loadSettings(){
set_mac(get_by_id("asp_temp_03").value, ":");
}
function send_request(){
var mac = "";
for (var i = 1; i < 7; i++){
mac += get_by_id("mac" + i).value;
if (i < 6){
mac += ":";
}
}
if ((mac != "00:00:00:00:00:00") && (mac != ":::::")){
if (!check_mac(mac)){
alert(msg[MSG5]);
return false;
}
}
get_by_id("asp_temp_03").value= mac;
send_submit("form1");
}
function clone_mac_action(){
set_mac(get_by_id("mac_clone_addr").value, ":");
}
</script>
</head>
<body onLoad="loadSettings();">
<table width="450" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="21"><img src="c1_tl.gif" width="21" height="21" /></td>
<td width="708" background="bg1_t.gif"><img src="top_1.gif" width="390" height="21" /></td>
<td width="21"><img src="c1_tr.gif" width="21" height="21" /></td>
</tr>
<tr>
<td valign="top" background="bg1_l.gif"><img src="top_2.gif" width="21" height="69" /></td>
<td background="bg.gif"><table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="78%" valign="top"><table width="98%" border="0" cellpadding="0" cellspacing="0" class="tabBigTitle">
<tr>
<td class="headerbg2">Set Dynamic IP Address</td>
</tr>
<tr>
<td valign="top"><TABLE width="98%" height=200 border="0" align=center cellpadding="3" cellspacing="1">
<TBODY>
<TR>
<TD align="center" valign="top" bgcolor="#DDDDDD"><TABLE width="100%" align=center border=0>
<TBODY>
<TR>
<TD><form id="form1" name="form1" method="post" action="apply.cgi">
<input type="hidden" id="html_response_page" name="html_response_page" value="wizard6.asp">
<input type="hidden" id="html_response_return_page" name="html_response_return_page" value="<% CmoGetCfg("html_response_return_page","none"); %>">
<input type="hidden" id="reboot_type" name="reboot_type" value="none">
<input type="hidden" id="asp_temp_02" name="asp_temp_02" value="dhcpc">
<input type="hidden" id="mac_clone_addr" name="mac_clone_addr" value="<% CmoGetStatus("mac_clone_addr"); %>">
<input type="hidden" id="asp_temp_03" name="asp_temp_03" value="<% CmoGetCfg("asp_temp_03","none"); %>">
<table width=100% border=0 cellpadding=3 cellspacing="1">
<tr>
<td width=76 height=19 valign="top" nowrap class="wizleft">Host
Name</td>
<td width=100 height=19 class="wizright">
<input type="text" id="asp_temp_04" name="asp_temp_04" size="40" maxlength="39" value="<% CmoGetCfg("asp_temp_04","none"); %>">
(optional)</td>
</tr>
<tr>
<td height=29 valign=top class="wizleft">MAC</td>
<td width=100 height=29 class="wizright"><font face=Arial size=2>
<input type=text id="mac1" name="mac1" size="2" maxlength="2">
-
<input type=text id="mac2" name="mac2" size="2" maxlength="2">
-
<input type=text id="mac3" name="mac3" size="2" maxlength="2">
-
<input type=text id="mac4" name="mac4" size="2" maxlength="2">
-
<input type=text id="mac5" name="mac5" size="2" maxlength="2">
-
<input type=text id="mac6" name="mac6" size="2" maxlength="2">
(optional)</font><font face="Arial, Helvetica, sans-serif" size=2><br>
</font>
<input type="button" value="Clone MAC Address" name="clone" onClick="clone_mac_action();">
</td>
</tr>
</table>
<br>
<table border="0" align="center" cellpadding="2" cellspacing="2">
<tr>
<td align="center"><input name="back" type="button" class="ButtonSmall" onClick="window.location='<% CmoGetCfg("html_response_return_page","none"); %>'" value="&lt; Back">
<input name="next" type="button" class="ButtonSmall" onClick="send_request();" value="Next &gt;">
<input name="exit" type="button" class="ButtonSmall" onClick=exit_wizard() value="Exit"></td>
</tr>
</table>
</form></TD>
</TR>
<TR>
<TD>&nbsp;</TD>
</TR>
</TBODY>
</TABLE></TD>
</TR>
</TBODY>
</TABLE>
<br>
</td>
</tr>
</table></td>
</tr>
</table></td>
<td background="bg1_r.gif">&nbsp;</td>
</tr>
<tr>
<td><img src="c1_bl.gif" width="21" height="20" /></td>
<td height="20" background="bg1_b.gif">&nbsp;</td>
<td><img src="c1_br.gif" width="21" height="20" /></td>
</tr>
</table>
</body>
</html>
