<html>
<head>
<title>TRENDNET | TEW-634GRU | Wizard</title>
<meta http-equiv="Content-Type" content="text/html;">
<link rel="stylesheet" href="style.css" type="text/css">
<script language="JavaScript" src="public_msg.js"></script>
<script language="JavaScript" src="public.js"></script>
<script language="JavaScript">
function loadSettings(){
var dat = get_by_id("wan_curr_ipaddr").value.split("/");
if(dat[0] !="0.0.0.0" && get_by_id("asp_temp_26").value == "0.0.0.0"){
get_by_id("asp_temp_26").value = dat[0];
}
if(dat[1] !="0.0.0.0" && get_by_id("asp_temp_27").value == "0.0.0.0"){
get_by_id("asp_temp_27").value = dat[1];
}
set_checked("<% CmoGetCfg("wan_l2tp_dynamic","none"); %>",get_by_name("l2tp_enable"));
disable_dhcp_static_address(get_by_name("l2tp_enable"), get_by_id("asp_temp_26"), get_by_id("asp_temp_27"), get_by_id("asp_temp_28"));
}
function send_request(){	
var ip = get_by_id("asp_temp_26").value;	
var mask = get_by_id("asp_temp_27").value;
var gateway = get_by_id("asp_temp_28").value;
var ip_addr_msg = replace_msg(all_ip_addr_msg,"IP address");
var gateway_msg = replace_msg(all_ip_addr_msg,"Gateway address");
var temp_ip_obj = new addr_obj(ip.split("."), ip_addr_msg, false, false);
var temp_mask_obj = new addr_obj(mask.split("."), subnet_mask_msg, false, false);
var temp_gateway_obj = new addr_obj(gateway.split("."), gateway_msg, false, false);
var user_name = get_by_id("asp_temp_24").value;
if (get_by_name("l2tp_enable")[1].checked){	
if (!check_lan_setting(temp_ip_obj, temp_mask_obj, temp_gateway_obj)){
return false;
}
}
if(get_by_id("asp_temp_29").value == ""){
alert(msg[MSG40]);
return false;
}
if (get_by_name("l2tp_enable")[1].checked){
get_by_id("asp_temp_23").value = "0";
}else{
get_by_id("asp_temp_23").value = "1";
}
if (!check_pwd("asp_temp_25", "pwd2")){
return false;
}
if (user_name == ""){
alert(msg[MSG51]);
return false;
}
if (get_by_id("asp_temp_25").value == "" || get_by_id("pwd2").value == ""){
alert("A L2TP password MUST be specified");
return false;
}
get_by_id("asp_temp_49").value = "1";
send_submit("form1");
}
</script>
</head>
<body onLoad="loadSettings();">
<table width="450" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="21"><img src="c1_tl.gif" width="21" height="21" /></td>
<td width="708" background="bg1_t.gif"><img src="top_1.gif" width="390" height="21" /></td>
<td width="21"><img src="c1_tr.gif" width="21" height="21" /></td>
</tr>
<tr>
<td valign="top" background="bg1_l.gif"><img src="top_2.gif" width="21" height="69" /></td>
<td background="bg.gif"><table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="78%" valign="top"><table width="98%" border="0" cellpadding="0" cellspacing="0" class="tabBigTitle">
<tr>
<td class="headerbg2">Set Russia L2TP Client</td>
</tr>
<tr>
<td valign="top"><TABLE width="98%" height=200 border="0" align=center cellpadding="3" cellspacing="1">
<TBODY>
<TR>
<TD align="center" valign="top" bgcolor="#DDDDDD"><TABLE width="100%" align=center border=0>
<TBODY>
<TR>
<TD><form id="form1" name="form1" method="post" action="apply.cgi">
<input type="hidden" id="html_response_page" name="html_response_page" value="wizard6.asp">
<input type="hidden" id="html_response_return_page" name="html_response_return_page" value="<% CmoGetCfg("html_response_return_page","none"); %>">
<input type="hidden" id="wan_curr_ipaddr" name="wan_curr_ipaddr" value="<% CmoGetStatus("wan_current_ipaddr_00"); %>">
<input type="hidden" id="reboot_type" name="reboot_type" value="none">
<input type="hidden" id="asp_temp_02" name="asp_temp_02" value="l2tp">
<input type="hidden" id="asp_temp_49" name="asp_temp_49" value="<% CmoGetStatus("asp_temp_49"); %>">
<input type="hidden" id="asp_temp_23" name="asp_temp_23" value="<% CmoGetStatus("asp_temp_23"); %>">
<input type="hidden" id="wan_l2tp_dynamic00" name="wan_l2tp_dynamic00" value="<% CmoGetCfg("wan_l2tp_dynamic","none"); %>">
<table width="100%" border="0" cellpadding="3" cellspacing="1" >
<tr>
<td class="wizleft">&nbsp;</td>
<td class="wizright"><font face="Arial">
<input type="radio" name="l2tp_enable" value="1" onClick='disable_dhcp_static_address(get_by_name("l2tp_enable"), get_by_id("asp_temp_26"), get_by_id("asp_temp_27"), get_by_id("asp_temp_28"))'>
</font>Dynamic IP&nbsp;<font face="Arial">
<input type="radio" name="l2tp_enable" value="0" onClick='disable_dhcp_static_address(get_by_name("l2tp_enable"), get_by_id("asp_temp_26"), get_by_id("asp_temp_27"), get_by_id("asp_temp_28"))'>
</font>Static IP</td>
</tr>
<tr>
<td width="144" class="wizleft"><font face="Arial">My IP</font></td>
<td width="235" class="wizright"><input type="text" id="asp_temp_26" name="asp_temp_26" size=16 maxlength=15 value="<% CmoGetCfg("asp_temp_26","none"); %>"></td>
</tr>
<tr>
<td class="wizleft"><font face="Arial">Subnet Mask</font></td>
<td class="wizright"><input type="text" id="asp_temp_27" name="asp_temp_27" size=16 maxlength=15 value="<% CmoGetCfg("asp_temp_27","none"); %>"></td>
</tr>
<tr>
<td class="wizleft"><font face="Arial">GateWay</font></td>
<td class="wizright"><input type="text" id="asp_temp_28" name="asp_temp_28" size="16" maxlength="15" value="<% CmoGetCfg("asp_temp_28","none"); %>"></td>
</tr>
<tr>
<td class="wizleft"><font face="Arial">Server IP</font></td>
<td class="wizright"><input type="text" id="asp_temp_29" name="asp_temp_29" size=30 maxlength=63 value="<% CmoGetCfg("asp_temp_29","none"); %>"></td>
</tr>
<tr>
<td class="wizleft"><font face="Arial">L2TP Account</font></td>
<td class="wizright"><input type="text" id="asp_temp_24" name="asp_temp_24" size="30" maxlength="63" value="<% CmoGetCfg("asp_temp_24","none"); %>"></td>
</tr>
<tr>
<td class="wizleft">L2TP Password</td>
<td class="wizright"><input type="password" id="asp_temp_25" name="asp_temp_25" size="30" maxlength="63" value="WDB8WvbXdHtZyM8Ms2RENgHlacJghQyG"></td>
</tr>
<tr>
<td class="wizleft">Retype Password</td>
<td class="wizright"><input type="password" id="pwd2" name="pwd2" size="30" maxlength="63" value="WDB8WvbXdHtZyM8Ms2RENgHlacJghQyG"></td>
</tr>
</table>
<br>
<table border="0" align="center" cellpadding="2" cellspacing="2">
<tr>
<td align="center" nowrap><input name="back" type="button" class="ButtonSmall" onClick="window.location='<% CmoGetCfg("html_response_return_page","none"); %>'" value="&lt; Back">
<input name="next" type="button" class="ButtonSmall" onClick="send_request()" value="Next &gt;">
<input name="exit" type="button" class="ButtonSmall" onClick="exit_wizard()" value="Exit"></td>
</tr>
</table>
</form></TD>
</TR>
<TR>
<TD>&nbsp;</TD>
</TR>
</TBODY>
</TABLE></TD>
</TR>
</TBODY>
</TABLE>
<br>
</td>
</tr>
</table></td>
</tr>
</table></td>
<td background="bg1_r.gif">&nbsp;</td>
</tr>
<tr>
<td><img src="c1_bl.gif" width="21" height="20" /></td>
<td height="20" background="bg1_b.gif">&nbsp;</td>
<td><img src="c1_br.gif" width="21" height="20" /></td>
</tr>
</table>
</body>
</html>
