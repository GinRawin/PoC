<html>
<head>
<meta http-equiv="Content-Type" content="text/html;">
<title>TRENDNET | TEW-634GRU | Tools | Settings</title>
<link rel="stylesheet" href="style.css" type="text/css">
<script language="JavaScript" src="public_msg.js"></script>
<script language="JavaScript" src="public.js"></script>
<SCRIPT LANGUAGE="JavaScript">
function check_load_settings(){
var login_who="<% CmoGetStatus("get_current_user"); %>"; 
if(login_who== "user"){
window.location.href ="back.asp";
}else{
if(confirm(msg[MSG17])){
if (get_by_id("file").value == ''){
alert(msg[MSG33]);
}else{
send_submit("form1");
}	
}
}
}
function check_restore_default(){	
var login_who="<% CmoGetStatus("get_current_user"); %>";
if(login_who== "user"){
window.location.href ="back.asp";
}else{
if(confirm(msg[MSG34])){
send_submit("form2");
}
}
}
function save_conf(){
send_submit("form3");
}
</SCRIPT>
</head>
<body onLoad="MM_preloadImages('but_wizard_1.gif','but_status_1.gif','but_tools_1.gif','but_main_1.gif','but_wireless_1.gif','but_routing_1.gif','but_access_1.gif','but_management_1.gif')">
<table width="750" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="21"><img src="c1_tl.gif" width="21" height="21" /></td>
<td width="708" background="bg1_t.gif"><img src="top_1.gif" width="390" height="21" /></td>
<td width="21"><img src="c1_tr.gif" width="21" height="21" /></td>
</tr>
<tr>
<td valign="top" background="bg1_l.gif"><img src="top_2.gif" width="21" height="69" /></td>
<td background="bg.gif"><table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="13%"><img src="logo.gif" width="270" height="69" /></td>
<td width="87%" align="right"><img src="description.gif" /></td>
</tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="20%" height="429" valign="top"><table width="56%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td><a href="lan.asp"><img src="but_main_0.gif" name="Image2" border="0" id="Image2" onMouseOver="MM_swapImage('Image2','','but_main_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="wireless_basic.asp"><img src="but_wireless_0.gif" name="Image3" border="0" id="Image3" onMouseOver="MM_swapImage('Image3','','but_wireless_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="status.asp"><img src="but_status_0.gif" name="Image1" border="0" id="Image1" onMouseOver="MM_swapImage('Image1','','but_status_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="static_routing.asp"><img src="but_routing_0.gif" name="Image4" border="0" id="Image4" onMouseOver="MM_swapImage('Image4','','but_routing_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="filters.asp"><img src="but_access_0.gif" name="Image5" border="0" id="Image5" onMouseOver="MM_swapImage('Image5','','but_access_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="remote_management.asp"><img src="but_management_0.gif" border="0" id="Image6" onMouseOver="MM_swapImage('Image6','','but_management_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="restart.asp"><img src="but_tools_1.gif" border="0" id="Image7" onMouseOver="MM_swapImage('Image7','','but_tools_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="2" class="submenubg">
<tr>
<td width="13%" align="right"><font color="#FFFFFF">&bull;</font></td>
<td width="87%"><a href="restart.asp" class="submenus"><b>Restart</b></a></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="settings.asp" class="submenus"><b><u>Settings</u></b></a></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="firmware.asp" class="submenus"><b>Firmware</b></a></td>
</tr>
<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="ping_test.asp" class="submenus"><b>Ping Test </b></a></td>
</tr>
<!--tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="usb_setting.asp" class="submenus"><b>USB Settings </b></a></td>
</tr-->
</table></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8"></td>
</tr>
<tr>
<td><a href="#" onClick="show_wizard('wizard.asp')"><img src="but_wizard_0.gif" name="Image71" border="0" id="Image71" onMouseOver="MM_swapImage('Image71','','but_wizard_1.gif',1)" onMouseOut="MM_swapImgRestore()"></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="15" height="15"></td>
</tr>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p></td>
<td width="2%"><img src="spacer.gif" width="15" height="15" /></td>
<td width="78%" valign="top"><table width="98%" border="0" cellpadding="0" cellspacing="0" class="tabBigTitle">
<tr>
<td class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%"><font color="#FFFFFF" class="textheader" style="margin-left:0; padding-left:0">Settings</font></td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="MM_openBrWindow('help_tools.asp#tools_settings','','scrollbars=yes,resizable=yes,width=800,height=550')" value=" Help " />
</td>
</tr>
</table></td>
</tr>
<tr>
<td valign="top"><form id="form3" name="form3" method=POST action="save_configuration.cgi" enctype=multipart/form-data>
<input type="hidden" id="html_response_page" name="html_response_page" value="back.asp">
<input type="hidden" id="html_response_return_page" name="html_response_return_page" value="settings.asp">
<table width="98%" border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#333333">
<tr>
<td colspan="2" class="greybluebg">Save configuration settings</td>
</tr>
<tr>
<td align="right" class="bgblue">Save
Settings</td>
<td class="bggrey"><input name="save" type="button" class="ButtonSmall" onClick="save_conf()" value="Save"></td>
</tr>
</table>
</form>
<br>
<form id="form1" name="form1" method="post" action="upload_configuration.cgi" enctype="multipart/form-data">
<input type="hidden" id="html_response_page" name="html_response_page" value="count_down.asp">
<input type="hidden" id="html_response_return_page" name="html_response_return_page" value="settings.asp">
<table width="98%" border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#333333">
<tr>
<td colspan="2" class="greybluebg">Restore configuration settings</td>
</tr>
<tr>
<td width="150" align="right" class="bgblue">Load
Settings</td>
<td class="bggrey"><input type="file" id="file" name="file" size="20">
<input name="load" type="button" class="ButtonSmall" onClick="return check_load_settings()" value="Load"></td>
</tr>
</table>
</form>
<br>
<form id="form2" name="form2" method="post" action="restore_default.cgi">
<input type="hidden" id="html_response_page" name="html_response_page" value="count_down.asp">
<input type="hidden" id="html_response_return_page" name="html_response_return_page" value="settings.asp">
<table width="98%" border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#333333">
<tr>
<td colspan="2" class="greybluebg">Restore factory default settings</td>
</tr>
<tr>
<td align="right" class="bgblue">Restore</td>
<td class="bggrey"><input name="restore" type="button" class="ButtonSmall" onClick="return check_restore_default()" value="Restore"></td>
</tr>
</table> 
</form>
<br>
</td>
</tr>
</table></td>
</tr>
</table></td>
<td background="bg1_r.gif">&nbsp;</td>
</tr>
<tr>
<td><img src="c1_bl.gif" width="21" height="20" /></td>
<td align="right" background="bg1_b.gif"><img src="copyright.gif" width="264" height="20" /></td>
<td><img src="c1_br.gif" width="21" height="20" /></td>
</tr>
</table>
</body>
</html>
