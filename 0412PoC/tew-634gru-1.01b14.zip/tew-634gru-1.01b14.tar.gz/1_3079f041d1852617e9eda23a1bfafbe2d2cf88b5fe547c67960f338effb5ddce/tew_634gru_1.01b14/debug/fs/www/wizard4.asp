<html>
<head>
<title>TRENDNET | TEW-634GRU | Wizard</title>
<meta http-equiv="Content-Type" content="text/html;">
<link rel="stylesheet" href="style.css" type="text/css">
<script language="JavaScript" src="public_msg.js"></script>
<script language="JavaScript" src="public.js"></script>
<script language="JavaScript">
<!--
var maxchars = 10;
var delay_time = 1600; 
var charcount = 0;
function loadSettings(){
if(charcount < maxchars){
charcount++;
setTimeout("loadSettings()",delay_time);
}else{
window.location.href="wizard4_detwan.asp";
}
}

</script>
</head>
<body onLoad="loadSettings();">
<table width="450" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="21"><img src="c1_tl.gif" width="21" height="21" /></td>
<td width="708" background="bg1_t.gif"><img src="top_1.gif" width="390" height="21" /></td>
<td width="21"><img src="c1_tr.gif" width="21" height="21" /></td>
</tr>
<tr>
<td valign="top" background="bg1_l.gif"><img src="top_2.gif" width="21" height="69" /></td>
<td background="bg.gif"><table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="78%" valign="top"><table width="98%" border="0" cellpadding="0" cellspacing="0" class="tabBigTitle">
<tr>
<td class="headerbg2">Auto Detecting WAN</td>
</tr>
<tr>
<td valign="top"><TABLE width="98%" height=200 border="0" align=center cellpadding="3" cellspacing="1">
<TBODY>
<TR>
<TD align="center" valign="top" bgcolor="#DDDDDD"><TABLE width="100%" align=center border=0>
<TBODY>
<TR>
<TD><form id="form1" name="form1" method="post" action="apply.cgi">
<input type="hidden" id="html_response_page" name="html_response_page" value="wizard5.asp">
<input type="hidden" id="html_response_return_page" name="html_response_return_page" value="wizard4.asp">
<input type="hidden" id="reboot_type" name="reboot_type" value="none">
<table width="100%" border="0" cellpadding="3" cellspacing="1">
<tr>
<td height="40">Please wait. Detecting WAN connection type now
... </td>
</tr>
</table>
</form></TD>
</TR>
<TR>
<TD>&nbsp;</TD>
</TR>
</TBODY>
</TABLE></TD>
</TR>
</TBODY>
</TABLE>
<br>
</td>
</tr>
</table></td>
</tr>
</table></td>
<td background="bg1_r.gif">&nbsp;</td>
</tr>
<tr>
<td><img src="c1_bl.gif" width="21" height="20" /></td>
<td height="20" background="bg1_b.gif">&nbsp;</td>
<td><img src="c1_br.gif" width="21" height="20" /></td>
</tr>
</table>
</body>
</html>
