<html>
<head>
<title>TRENDNET | TEW-634GRU | Wizard</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="style.css" type="text/css">
<script language="JavaScript" src="public.js"></script>
</head>
<script language="JavaScript">
var submit_button_flag = 0;
function set_time_zone(){

get_by_id("time_zone_wizard").selectedIndex = get_by_id("time_zone_area").value;
}
function send_request(){
get_by_id("asp_temp_55").value = document.getElementById("time_zone_wizard").selectedIndex;
get_by_id("asp_temp_01").value = get_select_value(get_by_id("time_zone_wizard"));
if(submit_button_flag == 0){
submit_button_flag = 1;
return true;
}else{
return false;
}
}
</script>
<body>
<table width="450" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="21"><img src="c1_tl.gif" width="21" height="21" /></td>
<td width="708" background="bg1_t.gif"><img src="top_1.gif" width="390" height="21" /></td>
<td width="21"><img src="c1_tr.gif" width="21" height="21" /></td>
</tr>
<tr>
<td valign="top" background="bg1_l.gif"><img src="top_2.gif" width="21" height="69" /></td>
<td background="bg.gif"><table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="78%" valign="top"><table width="98%" border="0" cellpadding="0" cellspacing="0" class="tabBigTitle">
<tr>
<td class="headerbg2">Choose Time Zone</td>
</tr>
<tr>
<td valign="top"><TABLE width="98%" height=200 border="0" align=center cellpadding="3" cellspacing="1">
<TBODY>
<TR>
<TD align="center" valign="top" bgcolor="#DDDDDD"><TABLE width="100%" align=center border=0>
<TBODY>
<TR>
<TD><DIV id=box_header>
<form id="form1" name="form1" method="post" action="apply.cgi">
<input type="hidden" id="time_zone_area" name="time_zone_area" value="<% CmoGetCfg("time_zone_area","none"); %>">
<input type="hidden" id="html_response_page" name="html_response_page" value="wizard3.asp">
<input type="hidden" id="html_response_return_page" name="html_response_return_page" value="wizard2.asp">
<input type="hidden" id="reboot_type" name="reboot_type" value="none">
<input type="hidden" id="asp_temp_55" name="asp_temp_55" value="<% CmoGetCfg("asp_temp_55","none"); %>">
<input type="hidden" id="asp_temp_01" name="asp_temp_01" value="<% CmoGetCfg("asp_temp_01","none"); %>">	
<table width="100%" border="0" cellpadding="3" cellspacing="1">
<tr>
<td><font>
<select id="time_zone_wizard" name="time_zone_wizard" size="1">
<option value="-192">(GMT-12:00) Eniwetok, Kwajalein</option>
<option value="-176">(GMT-11:00) Midway Island, Samoa</option>
<option value="-160">(GMT-10:00) Hawaii</option>
<option value="-144">(GMT-09:00) Alaska</option>
<option value="-128">(GMT-08:00) Pacific Time (US/Canada), Tijuana</option>
<option value="-112">(GMT-07:00) Arizona</option>
<option value="-112">(GMT-07:00) Mountain Time (US/Canada)</option>
<option value="-96">(GMT-06:00) Central America</option>
<option value="-96">(GMT-06:00) Central Time (US/Canada)</option>
<option value="-96">(GMT-06:00) Mexico City</option>
<option value="-96">(GMT-06:00) Saskatchewan</option>
<option value="-80">(GMT-05:00) Bogota, Lima, Quito</option>
<option value="-80">(GMT-05:00) Eastern Time (US/Canada)</option>
<option value="-80">(GMT-05:00) Indiana (East)</option>
<option value="-64">(GMT-04:30) Caracas, Venezuela</option>
<option value="-64">(GMT-04:00) Atlantic Time (Canada)</option>
<option value="-64">(GMT-04:00) La Paz</option>
<option value="-64">(GMT-04:00) Santiago</option>
<option value="-48">(GMT-03:00) Newfoundland</option>
<option value="-48">(GMT-03:00) Brazilia</option>
<option value="-48">(GMT-03:00) Buenos Aires, Georgetown</option>
<option value="-48">(GMT-03:00) Greenland</option>
<option value="-32">(GMT-02:00) Mid-Atlantic</option>
<option value="-16">(GMT-01:00) Azores</option>
<option value="-16">(GMT-01:00) Cape Verde Is.</option>
<option value="0">(GMT) Casablanca, Monrovia</option>
<option value="0">(GMT) Greenwich Time: Dublin, Edinburgh, Lisbon, London</option>
<option value="16">(GMT+01:00) Amsterdam, Berlin, Bern, Rome, Stockholm</option>
<option value="16">(GMT+01:00) Belgrade, Brastislava, Ljubljana</option>
<option value="16">(GMT+01:00) Brussels, Copenhagen, Madrid, Paris</option>
<option value="16">(GMT+01:00) Sarajevo, Skopje, Sofija, Vilnus, Zagreb</option>
<option value="16">(GMT+01:00) Budapest, Vienna, Prague, Warsaw</option>
<option value="16">(GMT+01:00) West Central Africa</option>
<option value="32">(GMT+02:00) Athens, Istanbul, Minsk</option>
<option value="32">(GMT+02:00) Bucharest</option>
<option value="32">(GMT+02:00) Cairo</option>
<option value="32">(GMT+02:00) Harare, Pretoria</option>
<option value="32">(GMT+02:00) Helsinki, Riga, Tallinn</option>
<option value="32">(GMT+02:00) Jerusalem</option>
<option value="48">(GMT+03:00) Baghdad</option>
<option value="48">(GMT+03:00) Kuwait, Riyadh</option>
<option value="48">(GMT+03:00) Moscow, St. Petersburg, Volgograd</option>
<option value="48">(GMT+03:00) Nairobi</option>
<option value="48">(GMT+03:00) Tehran</option>
<option value="64">(GMT+04:00) Abu Dhabi, Muscat</option>
<option value="64">(GMT+04:00) Baku, Tbilisi, Yerevan</option>
<option value="72">(GMT+04:30) Kabul</option>
<option value="80">(GMT+05:00) Ekaterinburg</option>
<option value="80">(GMT+05:00) Islamabad, Karachi, Tashkent</option>
<option value="88">(GMT+05:30) Calcutta, Chennai, Mumbai, New Delhi</option>
<option value="92">(GMT+05:45) Kathmandu</option>
<option value="96">(GMT+06:00) Almaty, Novosibirsk</option>
<option value="96">(GMT+06:00) Astana, Dhaka</option>
<option value="96">(GMT+06:00) Sri Jayawardenepura</option>
<option value="104">(GMT+06:30) Rangoon</option>
<option value="112">(GMT+07:00) Bangkok, Hanoi, Jakarta</option>
<option value="112">(GMT+07:00) Krasnoyarsk</option>
<option value="128">(GMT+08:00) Beijing, Chongqing, Hong Kong, Urumqi</option>
<option value="128">(GMT+08:00) Irkutsk, Ulaan Bataar</option>
<option value="128">(GMT+08:00) Kuala Lumpur, Singapore</option>
<option value="128">(GMT+08:00) Perth</option>
<option value="128">(GMT+08:00) Taipei</option>
<option value="144">(GMT+09:00) Osaka, Sapporo, Tokyo</option>
<option value="144">(GMT+09:00) Seoul</option>
<option value="144">(GMT+09:00) Yakutsk</option>
<option value="152">(GMT+09:30) Adelaide</option>
<option value="152">(GMT+09:30) Darwin</option>
<option value="160">(GMT+10:00) Brisbane</option>
<option value="160">(GMT+10:00) Canberra, Melbourne, Sydney</option>
<option value="160">(GMT+10:00) Guam, Port Moresby</option>
<option value="160">(GMT+10:00) Hobart</option>
<option value="160">(GMT+10:00) Vladivostok</option>
<option value="176">(GMT+11:00) Magadan, Solomon Is., New Caledonia</option>
<option value="192">(GMT+12:00) Auckland, Wellington</option>
<option value="192">(GMT+12:00) Fiji, Kamchatka, Marshall Is.</option>
<option value="208">(GMT+13:00) Nuku'alofa, Tonga</option>
</select>
</font> <br>
<table border="0" align="center" cellpadding="2" cellspacing="2">
<tr>
<td align="center"><input name="back" type="button" class="ButtonSmall" onClick="window.location='wizard1.asp'" value="&lt; Back">
<input name="next" type="submit" class="ButtonSmall" onClick="send_request()" value="Next &gt;">
<input name="exit" type="button" class="ButtonSmall" onClick="exit_wizard()" value="Exit"></td>
</tr>
</table>
<font>&nbsp; </font></td>
</tr>
</table>
</form>
</DIV></TD>
</TR>
<TR>
<TD align="center"><br></TD>
</TR>
</TBODY>
</TABLE>
</TD>
</TR>
</TBODY>
</TABLE>
<br>
</td>
</tr>
</table></td>
</tr>
</table></td>
<td background="bg1_r.gif">&nbsp;</td>
</tr>
<tr>
<td><img src="c1_bl.gif" width="21" height="20" /></td>
<td height="20" background="bg1_b.gif">&nbsp;</td>
<td><img src="c1_br.gif" width="21" height="20" /></td>
</tr>
</table>
</body>
<script>set_time_zone();</script>
</html>
