<html>
<head>
<title>TRENDNET | TEW-634GRU | Wizard</title>
<meta http-equiv="Content-Type" content="text/html;">
<link rel="stylesheet" href="style.css" type="text/css">
<script language="JavaScript" src="public_msg.js"></script>
<script language="JavaScript" src="public.js"></script>
</head>
<script>
function PageLoad(){
set_checked(get_by_id("blank_status").value, get_by_name("start_wizard"));
}
function send_request(){
get_by_id("blank_status").value = get_checked_value(get_by_name("start_wizard"));
get_by_id("html_response_page").value = "wizard.asp";
send_submit("form1");
}
</script>
<body onLoad="PageLoad();">
<table width="450" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="21"><img src="c1_tl.gif" width="21" height="21" /></td>
<td width="708" background="bg1_t.gif"><img src="top_1.gif" width="390" height="21" /></td>
<td width="21"><img src="c1_tr.gif" width="21" height="21" /></td>
</tr>
<tr>
<td valign="top" background="bg1_l.gif"><img src="top_2.gif" width="21" height="69" /></td>
<td background="bg.gif"><table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="78%" valign="top"><table width="98%" border="0" cellpadding="0" cellspacing="0" class="tabBigTitle">
<tr>
<td class="headerbg2">TEW-634GRU Setup Wizard</td>
</tr>
<tr>
<td valign="top"><TABLE width="98%" height=200 border="0" align=center cellpadding="3" cellspacing="1">
<TBODY>
<TR>
<TD align="center" valign="top" bgcolor="#DDDDDD"><TABLE width="100%" align=center border=0>
<TBODY>
<TR>
<TD><form id="form1" name="form1" method="POST" action="apply.cgi">
<input type="hidden" id="html_response_page" name="html_response_page" value="wizard_redirect.asp">
<input type="hidden" id="html_response_return_page" name="html_response_return_page" value="wizard.asp">
<input type="hidden" id="reboot_type" name="reboot_type" value="none">
<input type="hidden" id="blank_status" name="blank_status" value="<% CmoGetCfg("blank_status","none"); %>">
<table width="100%" border="0" cellpadding="3" cellspacing="1">
<tr>
<td><b>Step 1. </b><span>Set your new password </span></td>
</tr>
<tr>
<td><b>Step 2. </b><span>Choose your time zone </span></td>
</tr>
<tr>
<td><b>Step 3</b>. <span>Set LAN connection and DHCP Server </span></td>
</tr>
<tr>
<td><b>Step 4.</b> <span>Set Internet connection</span></td>
</tr>
<tr>
<td><b>Step 5. </b><span>Set wireless LAN connection</span></td>
</tr>
<tr>
<td><b>Step 6.</b> <span>Restart</span></td>
</tr>
<tr>
<td nowrap><br>
<p align="center">
<input name="next" type="submit" class="ButtonSmall" value="Next &gt;">
<input name="exit" type="button" class="ButtonSmall" onClick="exit_wizard()" value="Exit">
<br>
</p>
<p><font face="Arial"><b>Display wizard next time?</b></font><font face="Arial" size="2pt">&nbsp;
<input type="radio" name="start_wizard" value="0">
&nbsp;Yes&nbsp;
<input type="radio" name="start_wizard" value="1">
&nbsp;No &nbsp;</font>
<input name="update " type="button" class="ButtonSmall" onClick="send_request();" value="update">
</p></td>
</tr>
</table>
</form></TD>
</TR>
<TR>
<TD>&nbsp;</TD>
</TR>
</TBODY>
</TABLE></TD>
</TR>
</TBODY>
</TABLE>
<br>
</td>
</tr>
</table></td>
</tr>
</table></td>
<td background="bg1_r.gif">&nbsp;</td>
</tr>
<tr>
<td><img src="c1_bl.gif" width="21" height="20" /></td>
<td height="20" background="bg1_b.gif">&nbsp;</td>
<td><img src="c1_br.gif" width="21" height="20" /></td>
</tr>
</table>
</body>
</html>
