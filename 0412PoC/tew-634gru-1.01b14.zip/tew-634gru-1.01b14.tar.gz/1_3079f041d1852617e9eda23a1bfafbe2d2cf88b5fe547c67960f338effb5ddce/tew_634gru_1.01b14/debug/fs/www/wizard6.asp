<html>
<head>
<title>TRENDNET | TEW-634GRU | Wizard</title>
<meta http-equiv="Content-Type" content="text/html;">
<link rel="stylesheet" href="style.css" type="text/css">
<script language="JavaScript" src="public_msg.js"></script>
<script language="JavaScript" src="public.js"></script>
<script language="JavaScript">
function loadSettings(){
set_checked("<% CmoGetCfg("asp_temp_34","none"); %>", get_by_name("asp_temp_34"));
get_by_id("show_ssid").value = get_by_id("wlan0_ssid").value;
}
function set_channel(){
var channel_list = "<% CmoGetStatus("wlan0_channel_list"); %>";
var current_channel = "<% CmoGetCfg("asp_temp_36","none"); %>";
var ch = channel_list.split(",");
var obj = get_by_id("asp_temp_36");
var count = 0;
for (var i = 0; i < ch.length; i++){	
var oOption = document.createElement("OPTION");	
oOption.text = ch[i];
oOption.value = ch[i];	
obj.options[count++] = oOption;
if (ch[i] == current_channel){
oOption.selected = true;
} 
}
}
function send_request(){
if (check_ssid("show_ssid")){
get_by_id("asp_temp_35").value = get_by_id("show_ssid").value;
send_submit("form1");
}
}
</script>
</head>
<body >
<table width="450" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="21"><img src="c1_tl.gif" width="21" height="21" /></td>
<td width="708" background="bg1_t.gif"><img src="top_1.gif" width="390" height="21" /></td>
<td width="21"><img src="c1_tr.gif" width="21" height="21" /></td>
</tr>
<tr>
<td valign="top" background="bg1_l.gif"><img src="top_2.gif" width="21" height="69" /></td>
<td background="bg.gif"><table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="78%" valign="top"><table width="98%" border="0" cellpadding="0" cellspacing="0" class="tabBigTitle">
<tr>
<td class="headerbg2">Set Wireless LAN Connection</td>
</tr>
<tr>
<td valign="top"><TABLE width="98%" height=200 border="0" align=center cellpadding="3" cellspacing="1">
<TBODY>
<TR>
<TD align="center" valign="top" bgcolor="#DDDDDD"><TABLE width="100%" align=center border=0>
<TBODY>
<TR>
<TD><form name="form1" id="form1" method="post" action="apply.cgi">
<input type="hidden" id="html_response_page" name="html_response_page" value="wizard7.asp">
<input type="hidden" id="html_response_return_page" name="html_response_return_page" value="wizard5.asp">
<input type="hidden" id="reboot_type" name="reboot_type" value="none">
<input type="hidden" id="asp_temp_35" name="asp_temp_35" value="<% CmoGetCfg("asp_temp_35","none"); %>">
<input type="hidden" id="wlan0_ssid" name="wlan0_ssid" value="<% CmoGetCfg("wlan0_ssid","none"); %>">
<table width="100%" border="0" cellpadding="3" cellspacing="1" >
<tr>
<td width="144" nowrap class="wizleft">Wireless LAN</td>
<td width="235" class="wizright">
<input type="radio" name="asp_temp_34" value="1">
Enable
<input type="radio" name="asp_temp_34" value="0">
Disable</td>
</tr>
<tr>
<td class="wizleft">SSID</td>
<td class="wizright"><input type="text" id="show_ssid" name="show_ssid" size="20" maxlength="32"></td>
</tr>
<tr>
<td class="wizleft">Channel </td>
<td class="wizright"><select size="1" id="asp_temp_36" name="asp_temp_36">
</select></td>
</tr>
</table>
<br>
<table border="0" align="center" cellpadding="2" cellspacing="2">
<tr>
<td align="center" nowrap><input name="back" type="button" class="ButtonSmall" onClick="window.location='<% CmoGetCfg("asp_temp_59","none"); %>'" value="&lt; Back">
<input name="next" type="button" class="ButtonSmall" onClick="send_request()" value="Next &gt;">
<input name="exit" type="button" class="ButtonSmall" onClick="exit_wizard()" value="Exit"></td>
</tr>
</table>
</form></TD>
</TR>
<TR>
<TD>&nbsp;</TD>
</TR>
</TBODY>
</TABLE></TD>
</TR>
</TBODY>
</TABLE>
<br>
</td>
</tr>
</table></td>
</tr>
</table></td>
<td background="bg1_r.gif">&nbsp;</td>
</tr>
<tr>
<td><img src="c1_bl.gif" width="21" height="20" /></td>
<td height="20" background="bg1_b.gif">&nbsp;</td>
<td><img src="c1_br.gif" width="21" height="20" /></td>
</tr>
</table>
</body>
<script>
loadSettings();
set_channel();
</script>
</html>
