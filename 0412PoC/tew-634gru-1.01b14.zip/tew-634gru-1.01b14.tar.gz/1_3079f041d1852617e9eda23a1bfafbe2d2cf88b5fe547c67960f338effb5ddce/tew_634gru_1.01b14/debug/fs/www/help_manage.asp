<HTML>
<HEAD>
<!-- $MVD$:app("RoboHELP HTML Edition by Blue Sky Software, portions by MicroVision Dev. Inc.","769") -->
<!-- $MVD$:template("","0","0") -->
<!-- $MVD$:fontset("Arial","Arial") -->
<!-- $MVD$:fontset("Times New Roman","Times New Roman") -->
<!-- $MVD$:fontset("Arial Narrow","Arial Narrow") -->
<TITLE>Management</TITLE>
<link rel="stylesheet" href="style.css" type="text/css">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script type="text/javascript">
<!--
function MM_preloadImages() { //v3.0
var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
function MM_swapImgRestore() { 
var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_findObj(n, d) { 
var p,i,x; if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
if(!x && d.getElementById) x=d.getElementById(n); return x;
}
function MM_swapImage() { 
var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
-->
</script>
</HEAD>
<BODY onLoad="MM_preloadImages('but_help_access_1.gif','but_help_main_1.gif','but_help_management_1.gif','but_help_routing_1.gif','but_help_status_1.gif','but_help_tools_1.gif','but_help_wireless_1.gif')">
<table width="750" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="21"><img src="c1_tl.gif" width="21" height="21" /></td>
<td width="708" background="bg1_t.gif"><img src="top_1.gif" width="390" height="21" /></td>
<td width="21"><img src="c1_tr.gif" width="21" height="21" /></td>
</tr>
<tr>
<td valign="top" background="bg1_l.gif"><img src="top_2.gif" width="21" height="69" /></td>
<td background="bg.gif"><table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="13%"><img src="logo.gif" width="270" height="69" /></td>
<td width="87%" align="right"><img src="description.gif" /></td>
</tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="20%" height="429" valign="top"><table width="100%" border="0" align="center" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><b>Help</b></td>
</tr>
<tr>
<td bgcolor="#000000" ><table width="56%" border="0" cellpadding="0" cellspacing="0" bgcolor="#1D1D1D">
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_main.asp"><img src="but_help_main_0.gif" name="Image2" width="155" height="27" border="0" id="Image2" onmouseover="MM_swapImage('Image2','','but_help_main_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr> 
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_wlan.asp"><img src="but_help_wireless_0.gif" name="Image31" width="155" height="27" border="0" id="Image31" onmouseover="MM_swapImage('Image31','','but_help_wireless_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_status.asp"><img src="but_help_status_0.gif" name="Image23" width="155" height="27" border="0" id="Image23" onmouseover="MM_swapImage('Image23','','but_help_status_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_routing.asp"><img src="but_help_routing_0.gif" name="Image30" width="155" height="27" border="0" id="Image22" onmouseover="MM_swapImage('Image30','','but_help_routing_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_access.asp"><img src="but_help_access_0.gif" name="Image24" width="155" height="27" border="0" id="Image24" onmouseover="MM_swapImage('Image24','','but_help_access_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr> 
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_manage.asp"><img src="but_help_management_1.gif" name="Image21" width="155" height="27" border="0" id="Image21" onmouseover="MM_swapImage('Image21','','but_help_management_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="2" >
<tr>
<td width="13%" align="right"><font color="#FFFFFF">&bull;</font></td>
<td width="87%"><b><a href="help_manage.asp#Management_RemMan" class="submenus">Remote Management</a></b>
<b><a href="help_access.asp#access_user_group" class="submenus"></a></b></td>
</tr>
<!--<tr>
<td align="right"><font color="#FFFFFF">&bull;</font></td>
<td><a href="inbound_filter.asp" class="submenus"><b>Inbound Filter </b></a></td>
</tr>-->
</table></td>
</tr>
<tr>
<td><img src="spacer.gif" width="8" height="8" /></td>
</tr>
<tr>
<td><a href="help_tools.asp"><img src="but_help_tools_0.gif" name="Image1" width="155" height="27" border="0" id="Image1" onmouseover="MM_swapImage('Image1','','but_help_tools_1.gif',1)" onmouseout="MM_swapImgRestore()" /></a></td>
</tr> 
</table></td>
</tr>
</table>
<p></p>
<p>&nbsp;</p>
<p></p>
<p>&nbsp;</p></td>
<td width="2%"><img src="spacer.gif" width="10" height="15" /></td>
<td width="78%" valign="top"><table width="550" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">Management</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>This screen enables you to set up remote management features.</P>
<P> Click the items below for more information.</P>
<UL>
<LI CLASS="mvd-P-Bullet">
<P CLASS="Bullet"> <b><A HREF="#Management_RemMan">Remote Management</A></b></P>
</UL></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br> <a name="Management_RemMan"></a><br>
<table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#000000">
<tr>
<td bgcolor="#C5CEDA" class="headerbg2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 10px 0 10px 0">
<tr>
<td width="79%" class="textheader">Remote Management</td>
<td width="21%"><input name="button" type="button" class="ButtonHelp" onclick="javascript:window.close();" value="Close" />
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td><table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td bgcolor="#F0F0F0"><P>This screen enables you to set up remote management. Using remote
management, the router can be configured through the <A HREF="glossary.asp#def_WAN">WAN</A> via a Web browser. A user name and password are required to perform
remote management.</P>
<P> <SPAN STYLE="font-weight : bold;">HTTP:</SPAN><A NAME="manage_remote_management_HTTP"></A> Enables you to set up <A HREF="glossary.asp#def_HTTP">HTTP</A> access
for remote management.</P>
<UL>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">Enable:</SPAN> Click to enable or disable <A HREF="glossary.asp#def_HTTP">HTTP</A> access for remote management.</P>
<LI CLASS="mvd-P">
<P> <SPAN STYLE="font-weight : bold;">Remote IP Range:</SPAN> Type the range
of <A HREF="glossary.asp#def_ip_address">IP addresses</A> that can be used
for remote access.</P>
</UL>
<P> <SPAN STYLE="font-weight : bold;">Allow to Ping WAN Port:</SPAN><A NAME="manage_remote_management_allow_to_ping"></A> Type a range of router <A HREF="glossary.asp#def_ip_address">IP addresses</A> that can be <A HREF="glossary.asp#def_Ping">pinged</A> from remote locations.</P>
<P><strong>UPNP Enable: </strong>UPnP is short for Universal Plug and Play which is a networking architecture that provides compatibility among networking equipment, software, and peripherals. The Router is a UPnP enabled router and will only work with other UPnP devices/softwares. If you do not want to use the UPnP functionality, it can be disabled by selecting &quot;Disabled&quot;. </P>
<p><strong>PPTP: </strong>Enables users to set up PPTP connection between LAN and WAN ( pass-through). </p>
<p><strong>L2TP: </strong>Enables users to set up L2TP connection between LAN and WAN ( pass-through). </p>
<p><strong>Multicast Stream: </strong>This option must be enabled if any applications on the LAN participate in a multicast group. If you have a multimedia LAN application that is not receiving content as expected, try enabling this option. </p>
<P> <A HREF="help_manage.asp">back to top</A></td>
</tr>
</table></td>
</tr>
</table>
<br>
<br>
<br></td>
</tr>
</table></td>
<td background="bg1_r.gif">&nbsp;</td>
</tr>
<tr>
<td><img src="c1_bl.gif" width="21" height="20" /></td>
<td align="right" background="bg1_b.gif"><img src="copyright.gif" width="264" height="20" /></td>
<td><img src="c1_br.gif" width="21" height="20" /></td>
</tr>
</table>
</BODY>
</HTML>