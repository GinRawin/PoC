cd /

/bin/lighttpd   -f /lighttpd.conf

