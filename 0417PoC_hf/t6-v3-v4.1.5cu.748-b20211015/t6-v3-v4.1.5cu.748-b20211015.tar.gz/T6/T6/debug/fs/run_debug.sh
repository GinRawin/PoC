#!/bin/sh
mkdir /fs/tb_log

chroot /fs /run_setup.sh

chroot fs /qemu-mipsel-static -d trace:exec_tb -strace -D /tb_log/%d_tb_log.txt  -hackbind -hackproc -hacksysinfo -execve "/qemu-mipsel-static -d trace:exec_tb -strace -D /tb_log/%d_tb_log.txt -hackbind -hackproc -hacksysinfo " -E LD_PRELOAD="libnvram-faker.so" /bin/sh /run_background.sh > /fs/GREENHOUSE_BGLOG 2>&1


chroot fs /qemu-mipsel-static -d trace:exec_tb -strace -D /tb_log/%d_tb_log.txt -hackbind -hackproc -hacksysinfo -execve "/qemu-mipsel-static -d trace:exec_tb -strace -D /tb_log/%d_tb_log.txt -hackbind -hackproc -hacksysinfo " -E LD_PRELOAD="libnvram-faker.so" /bin/sh /qemu_run.sh


while true; do sleep 10000; done